package com.livemine.compat;

import com.livemine.LiveMineMod;
import com.livemine.NPCSkills;
import com.livemine.entity.LiveNPCEntity;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Интеграция с магическими модами.
 *
 * Поддерживаемые:
 *   - Iron's Spells 'n Spellbooks
 *   - Ars Nouveau
 *
 * NPC изучает заклинания тир 1–3. Тир 4+ недоступен.
 *
 * Требования по тирам:
 *   - Тир 1: Magic ≥ 3
 *   - Тир 2: Magic ≥ 6
 *   - Тир 3: Magic ≥ 9
 */
public final class MagicIntegration {

    private static MagicIntegration INSTANCE;

    private boolean ironsSpellsLoaded = false;
    private boolean arsNouveauLoaded = false;

    // =========================================================================
    // Реестр заклинаний (id → тир)
    // =========================================================================
    private static final Map<String, Integer> SPELL_TIERS = new LinkedHashMap<>();

    static {
        // РўРёСЂ 1
        SPELL_TIERS.put("fireball", 1);
        SPELL_TIERS.put("heal", 1);
        SPELL_TIERS.put("ice_shard", 1);

        // РўРёСЂ 2
        SPELL_TIERS.put("shield", 2);
        SPELL_TIERS.put("lightning", 2);
        SPELL_TIERS.put("frost_nova", 2);

        // РўРёСЂ 3
        SPELL_TIERS.put("summon_guardian", 3);
        SPELL_TIERS.put("teleport", 3);
        SPELL_TIERS.put("meteor", 3);
    }

    private MagicIntegration() {
        ironsSpellsLoaded = isClassPresent("io.redspace.ironsspellbooks.IronsSpellbooks");
        arsNouveauLoaded = isClassPresent("com.hollingsworth.arsnouveau.ArsNouveau");

        if (ironsSpellsLoaded) LiveMineMod.LOGGER.info("Iron's Spells integration enabled");
        if (arsNouveauLoaded) LiveMineMod.LOGGER.info("Ars Nouveau integration enabled");
        if (!ironsSpellsLoaded && !arsNouveauLoaded) {
            LiveMineMod.LOGGER.info("No magic mod detected, integration disabled");
        }
    }

    public static synchronized MagicIntegration getInstance() {
        if (INSTANCE == null) INSTANCE = new MagicIntegration();
        return INSTANCE;
    }

    // =========================================================================
    // Проверки
    // =========================================================================

    private boolean isClassPresent(String className) {
        try {
            Class.forName(className);
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    public boolean isAnyMagicLoaded() {
        return ironsSpellsLoaded || arsNouveauLoaded;
    }

    public boolean isIronsSpellsLoaded() { return ironsSpellsLoaded; }
    public boolean isArsNouveauLoaded() { return arsNouveauLoaded; }

    // =========================================================================
    // Проверка доступа NPC
    // =========================================================================

    /**
     * Может ли NPC использовать заклинание.
     */
    public boolean canNPCCastSpell(LiveNPCEntity npc, String spellId) {
        if (!isAnyMagicLoaded()) return false;
        if (npc == null || npc.getSkills() == null) return false;

        Integer tier = SPELL_TIERS.get(spellId);
        if (tier == null) return false;

        double magicLevel = npc.getSkills().getLevel(NPCSkills.SkillType.MAGIC);
        double requiredLevel = switch (tier) {
            case 1 -> 3.0;
            case 2 -> 6.0;
            case 3 -> 9.0;
            default -> Double.MAX_VALUE;
        };

        return magicLevel >= requiredLevel;
    }

    public float getSpellPower(LiveNPCEntity npc, String spellId) {
        if (npc == null || npc.getSkills() == null) return 0f;

        float magicLevel = (float) npc.getSkills().getLevel(NPCSkills.SkillType.MAGIC);
        float intelligence = (float) npc.getSkills().getIntelligence();
        Integer tier = SPELL_TIERS.get(spellId);
        if (tier == null) return 0f;

        return magicLevel * intelligence * (1.0f + tier * 0.5f);
    }

    public float getSpellCooldown(LiveNPCEntity npc, String spellId) {
        if (npc == null || npc.getSkills() == null) return 600f;

        float magicLevel = (float) npc.getSkills().getLevel(NPCSkills.SkillType.MAGIC);
        Integer tier = SPELL_TIERS.get(spellId);
        if (tier == null) return 600f;

        float baseCooldown = 200f * tier;
        float reduction = Math.min(0.7f, magicLevel * 0.05f);
        return baseCooldown * (1.0f - reduction);
    }

    // =========================================================================
    // Реестр
    // =========================================================================

    public Set<String> getAvailableSpells() {
        return SPELL_TIERS.keySet();
    }

    public int getSpellTier(String spellId) {
        return SPELL_TIERS.getOrDefault(spellId, 0);
    }

    public List<String> getSpellsForNPC(LiveNPCEntity npc) {
        List<String> result = new ArrayList<>();
        for (Map.Entry<String, Integer> e : SPELL_TIERS.entrySet()) {
            if (canNPCCastSpell(npc, e.getKey())) {
                result.add(e.getKey());
            }
        }
        return result;
    }

    /**
     * Попытка каста — заглушка (лог + true если можно).
     */
    public boolean castSpell(LiveNPCEntity npc, String spellId) {
        if (!canNPCCastSpell(npc, spellId)) return false;

        LiveMineMod.LOGGER.debug("NPC {} casts {} (power: {:.1f})",
            npc.getCustomNameTag(), spellId, getSpellPower(npc, spellId));
        return true;
    }
}
