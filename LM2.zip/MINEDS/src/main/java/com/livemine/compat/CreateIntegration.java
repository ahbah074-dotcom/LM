package com.livemine.compat;

import com.livemine.LiveMineMod;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Интеграция с Create.
 *
 * Загружается условно. Если Create не установлен — интеграция отключена.
 *
 * 3 встроенные схемы (ТЗ 20.0 §14.1):
 *   - windmill    — ветряная мельница
 *   - water_wheel — водяное колесо
 *   - crusher     — дробилка
 *
 * NPC с Инженерией ≥ 5 может построить схему.
 */
public final class CreateIntegration {

    private static CreateIntegration INSTANCE;

    private boolean createLoaded = false;

    // =========================================================================
    // Schematic
    // =========================================================================
    public static final class Schematic {
        public final String name;
        public final int width, height, length;
        public final List<BlockPos> offsets = new ArrayList<>();
        public final List<BlockState> states = new ArrayList<>();

        public Schematic(String name, int w, int h, int l) {
            this.name = name;
            this.width = w;
            this.height = h;
            this.length = l;
        }

        public void add(int x, int y, int z, BlockState state) {
            offsets.add(new BlockPos(x, y, z));
            states.add(state);
        }

        public int size() { return offsets.size(); }
    }

    private final Map<String, Schematic> schematics = new HashMap<>();

    private CreateIntegration() {
        createLoaded = isCreatePresent();
        if (createLoaded) {
            initSchematics();
            LiveMineMod.LOGGER.info("Create integration enabled");
        } else {
            LiveMineMod.LOGGER.info("Create not detected, integration disabled");
        }
    }

    public static synchronized CreateIntegration getInstance() {
        if (INSTANCE == null) INSTANCE = new CreateIntegration();
        return INSTANCE;
    }

    // =========================================================================
    // Проверка наличия Create
    // =========================================================================

    private boolean isCreatePresent() {
        try {
            Class.forName("com.simibubi.create.Create");
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    public boolean isCreateLoaded() { return createLoaded; }

    // =========================================================================
    // Инициализация схем
    // =========================================================================

    private void initSchematics() {
        // Ветряная мельница (7×8×7)
        Schematic windmill = new Schematic("windmill", 7, 8, 7);
        windmill.add(0, 0, 0, Blocks.OAK_PLANKS.defaultBlockState());
        windmill.add(0, 1, 0, Blocks.OAK_LOG.defaultBlockState());
        windmill.add(0, 2, 0, Blocks.OAK_LOG.defaultBlockState());
        windmill.add(0, 3, 0, Blocks.OAK_PLANKS.defaultBlockState());
        windmill.add(1, 3, 0, Blocks.OAK_SLAB.defaultBlockState());
        windmill.add(-1, 3, 0, Blocks.OAK_SLAB.defaultBlockState());
        schematics.put("windmill", windmill);

        // Водяное колесо (5×5×3)
        Schematic wheel = new Schematic("water_wheel", 5, 5, 3);
        wheel.add(0, 0, 0, Blocks.OAK_PLANKS.defaultBlockState());
        wheel.add(1, 0, 0, Blocks.OAK_SLAB.defaultBlockState());
        wheel.add(-1, 0, 0, Blocks.OAK_SLAB.defaultBlockState());
        wheel.add(0, 1, 0, Blocks.OAK_LOG.defaultBlockState());
        schematics.put("water_wheel", wheel);

        // Дробилка (3×4×3)
        Schematic crusher = new Schematic("crusher", 3, 4, 3);
        crusher.add(0, 0, 0, Blocks.STONE_BRICKS.defaultBlockState());
        crusher.add(0, 1, 0, Blocks.IRON_BARS.defaultBlockState());
        crusher.add(0, 2, 0, Blocks.IRON_BLOCK.defaultBlockState());
        schematics.put("crusher", crusher);
    }

    // =========================================================================
    // API
    // =========================================================================

    public Schematic getSchematic(String name) {
        return schematics.get(name);
    }

    public Set<String> getSchematicNames() {
        return schematics.keySet();
    }

    public List<String> getAvailableSchematics() {
        return new ArrayList<>(schematics.keySet());
    }

    /**
     * Строит схему в указанной точке.
     * Возвращает false, если Create не загружен или схема не найдена.
     */
    public boolean build(Level level, BlockPos origin, String schematicName) {
        if (!createLoaded) return false;

        Schematic s = schematics.get(schematicName);
        if (s == null) return false;

        for (int i = 0; i < s.offsets.size(); i++) {
            BlockPos pos = origin.offset(s.offsets.get(i));
            level.setBlock(pos, s.states.get(i), 3);
        }

        LiveMineMod.LOGGER.info("Built Create schematic '{}' at {}", schematicName, origin);
        return true;
    }

    /**
     * Упрощённый вызов без уровня (только проверка).
     */
    public boolean canBuild(String schematicName) {
        return createLoaded && schematics.containsKey(schematicName);
    }
}
