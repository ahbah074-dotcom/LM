package com.livemine;

import net.minecraft.nbt.CompoundTag;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Менеджер репутации.
 *
 * v2.0: устранены unchecked warnings (полная параметризация типов).
 */
public final class ReputationManager {

    public static final int START_VALUE = 21;
    public static final int MIN_VALUE = -100;
    public static final int MAX_VALUE = 100;

    private final Map<UUID, Map<UUID, Integer>> villageToPlayer = new HashMap<>();
    private final Map<UUID, Map<UUID, Integer>> npcToPlayer = new HashMap<>();

    private static ReputationManager INSTANCE;

    private ReputationManager() {}

    public static synchronized ReputationManager getInstance() {
        if (INSTANCE == null) INSTANCE = new ReputationManager();
        return INSTANCE;
    }

    // =========================================================================
    // Уровни
    // =========================================================================

    public enum Level {
        LEGEND     ("Легенда",        100, 100, 0.49),
        HERO       ("Герой",          81,  99,  0.70),
        FRIEND     ("Друг",           61,  80,  0.80),
        NEUTRAL    ("Нейтрально",     41,  60,  1.00),
        GUEST      ("Гость",          21,  40,  1.50),
        UNWELCOME  ("Нежеланный",     1,   20,  0.00),
        RESET      ("Сброс",          0,   0,   0.00),
        SUSPECT    ("Подозреваемый",  -1,  -49, 0.00),
        ENEMY      ("Враг",           -50, -99, 0.00),
        OUTCAST    ("Изгнан",         -100,-100,0.00);

        public final String ruName;
        public final int min, max;
        public final double priceMultiplier;

        Level(String ru, int min, int max, double priceMult) {
            this.ruName = ru;
            this.min = min;
            this.max = max;
            this.priceMultiplier = priceMult;
        }

        public static Level fromValue(int value) {
            if (value >= 100) return LEGEND;
            if (value >= 81)  return HERO;
            if (value >= 61)  return FRIEND;
            if (value >= 41)  return NEUTRAL;
            if (value >= 21)  return GUEST;
            if (value >= 1)   return UNWELCOME;
            if (value == 0)   return RESET;
            if (value >= -49) return SUSPECT;
            if (value >= -99) return ENEMY;
            return OUTCAST;
        }
    }

    // =========================================================================
    // Репутация деревни к игроку
    // =========================================================================

    public int getVillageReputation(UUID villageId, UUID playerId) {
        if (villageId == null || playerId == null) return START_VALUE;
        Map<UUID, Integer> map = villageToPlayer.get(villageId);
        if (map == null) return START_VALUE;
        Integer val = map.get(playerId);
        return val != null ? val : START_VALUE;
    }

    public void addVillageReputation(UUID villageId, UUID playerId, int delta) {
        if (villageId == null || playerId == null) return;
        int current = getVillageReputation(villageId, playerId);
        int newVal = clamp(current + delta);
        villageToPlayer.computeIfAbsent(villageId, k -> new HashMap<>()).put(playerId, newVal);
    }

    public void setVillageReputation(UUID villageId, UUID playerId, int value) {
        if (villageId == null || playerId == null) return;
        villageToPlayer.computeIfAbsent(villageId, k -> new HashMap<>()).put(playerId, clamp(value));
    }

    // =========================================================================
    // Репутация NPC к игроку
    // =========================================================================

    public int getNpcReputation(UUID npcId, UUID playerId) {
        if (npcId == null || playerId == null) return START_VALUE;
        Map<UUID, Integer> map = npcToPlayer.get(npcId);
        if (map == null) return START_VALUE;
        Integer val = map.get(playerId);
        return val != null ? val : START_VALUE;
    }

    public void addNpcReputation(UUID npcId, UUID playerId, int delta) {
        if (npcId == null || playerId == null) return;
        int current = getNpcReputation(npcId, playerId);
        int newVal = clamp(current + delta);
        npcToPlayer.computeIfAbsent(npcId, k -> new HashMap<>()).put(playerId, newVal);
    }

    // =========================================================================
    // Комбинированные правила
    // =========================================================================

    public boolean canTrade(UUID villageId, UUID npcId, UUID playerId) {
        int v = getVillageReputation(villageId, playerId);
        int n = getNpcReputation(npcId, playerId);
        return v >= 1 || n >= 1;
    }

    public boolean canEnterHomes(UUID villageId, UUID playerId) {
        return getVillageReputation(villageId, playerId) >= 41;
    }

    public boolean shouldAttack(UUID villageId, UUID npcId, UUID playerId) {
        int v = getVillageReputation(villageId, playerId);
        int n = getNpcReputation(npcId, playerId);
        return Math.min(v, n) <= -50;
    }

    public int getWorstReputation(UUID villageId, UUID npcId, UUID playerId) {
        return Math.min(
            getVillageReputation(villageId, playerId),
            getNpcReputation(npcId, playerId)
        );
    }

    public void onPunishmentServed(UUID villageId, UUID playerId, int originalPenalty) {
        int refund = (int) Math.round(originalPenalty * 0.70);
        addVillageReputation(villageId, playerId, refund);
        LiveMineMod.LOGGER.info("Punishment served: refunded {} rep to player {}",
            refund, playerId);
    }

    // =========================================================================
    // Замеченные деяния
    // =========================================================================

    public enum Action {
        KILL_NPC                (-50),
        KILL_PET                (-25),
        ASSAULT                 (-30),
        PICKPOCKET              (-15),
        CHEST_THEFT             (-20),
        MAJOR_THEFT             (-40),
        LOCKPICK                (-25),
        DESTROY_1_BLOCK         (-2),
        DESTROY_10_BLOCKS       (-20),
        DESTROY_HOUSE           (-50),
        ARSON                   (-60),
        HELP_BANDITS            (-70),
        DEBT_REFUSAL            (-10);

        public final int penalty;
        Action(int penalty) { this.penalty = penalty; }
    }

    public void onWitnessedAction(UUID villageId, UUID playerId, Action action) {
        addVillageReputation(villageId, playerId, action.penalty);
        LiveMineMod.LOGGER.info("Player {} committed {} ({} rep)",
            playerId, action.name(), action.penalty);
    }

    // =========================================================================
    // NBT
    // =========================================================================

    public CompoundTag save() {
        CompoundTag root = new CompoundTag();

        CompoundTag vRoot = new CompoundTag();
        for (Map.Entry<UUID, Map<UUID, Integer>> e : villageToPlayer.entrySet()) {
            CompoundTag inner = new CompoundTag();
            for (Map.Entry<UUID, Integer> p : e.getValue().entrySet()) {
                inner.putInt(p.getKey().toString(), p.getValue());
            }
            vRoot.put(e.getKey().toString(), inner);
        }
        root.put("villageToPlayer", vRoot);

        CompoundTag nRoot = new CompoundTag();
        for (Map.Entry<UUID, Map<UUID, Integer>> e : npcToPlayer.entrySet()) {
            CompoundTag inner = new CompoundTag();
            for (Map.Entry<UUID, Integer> p : e.getValue().entrySet()) {
                inner.putInt(p.getKey().toString(), p.getValue());
            }
            nRoot.put(e.getKey().toString(), inner);
        }
        root.put("npcToPlayer", nRoot);

        return root;
    }

    public void load(CompoundTag root) {
        villageToPlayer.clear();
        npcToPlayer.clear();
        if (root == null) return;

        CompoundTag vRoot = root.getCompound("villageToPlayer");
        for (String vk : vRoot.getAllKeys()) {
            try {
                UUID villageId = UUID.fromString(vk);
                CompoundTag inner = vRoot.getCompound(vk);
                Map<UUID, Integer> map = new HashMap<>();
                for (String pk : inner.getAllKeys()) {
                    map.put(UUID.fromString(pk), inner.getInt(pk));
                }
                villageToPlayer.put(villageId, map);
            } catch (IllegalArgumentException ignored) {}
        }

        CompoundTag nRoot = root.getCompound("npcToPlayer");
        for (String nk : nRoot.getAllKeys()) {
            try {
                UUID npcId = UUID.fromString(nk);
                CompoundTag inner = nRoot.getCompound(nk);
                Map<UUID, Integer> map = new HashMap<>();
                for (String pk : inner.getAllKeys()) {
                    map.put(UUID.fromString(pk), inner.getInt(pk));
                }
                npcToPlayer.put(npcId, map);
            } catch (IllegalArgumentException ignored) {}
        }
    }

    public void clear() {
        villageToPlayer.clear();
        npcToPlayer.clear();
    }

    private static int clamp(int v) {
        return Math.max(MIN_VALUE, Math.min(MAX_VALUE, v));
    }
}