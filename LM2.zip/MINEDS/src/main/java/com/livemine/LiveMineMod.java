package com.livemine;

import com.livemine.network.NetworkHandler;
import com.livemine.registry.*;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * LiveMine — точка входа мода.
 *
 * Платформа: NeoForge 1.21.1
 * Java: 21
 *
 * 2.0: убраны ручные регистрации NetworkHandler и CommandRegistrationHandler
 * через addListener/NeoForge.EVENT_BUS.register — они подписаны через
 * @EventBusSubscriber и NeoForge сам их подхватывает. Двойная подписка
 * приводила к "Cannot register payload as it is already registered".
 */
@Mod(LiveMineMod.MOD_ID)
public class LiveMineMod {

    public static final String MOD_ID = "livemine";
    public static final Logger LOGGER = LoggerFactory.getLogger("LiveMine");

    public LiveMineMod(IEventBus modEventBus, ModContainer modContainer) {
        LOGGER.info("LiveMine: initializing on NeoForge {}", modContainer.getModInfo().getVersion());

        // === Конфигурация ===
        modContainer.registerConfig(ModConfig.Type.COMMON, LiveMineConfig.SPEC, "livemine-common.toml");
        modContainer.registerConfig(ModConfig.Type.CLIENT, LiveMineConfig.CLIENT_SPEC, "livemine-client.toml");

        // === Регистрация контента (DeferredRegister) ===
        ModEntities.ENTITY_TYPES.register(modEventBus);
        ModBlocks.BLOCKS.register(modEventBus);
        ModBlocks.ITEMS.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modEventBus);
        ModSounds.SOUNDS.register(modEventBus);
        ModCreativeTab.CREATIVE_MODE_TABS.register(modEventBus);

        // === Атрибуты NPC ===
        modEventBus.addListener(ModEntities::onAttributeCreation);

        // === Сетевые пакеты и команды ===
        // НЕ регистрируем вручную: NetworkHandler и CommandRegistrationHandler
        // уже подписаны через @EventBusSubscriber.

        // === Серверные события (тик симуляции) ===
        NeoForge.EVENT_BUS.register(com.livemine.ai.NPCSimulationTickHandler.class);

        // === Обработчик мира ===
        NeoForge.EVENT_BUS.register(com.livemine.util.ServerLifecycleHandler.class);

        LOGGER.info("LiveMine: initialization complete");
    }
}