package com.livemine;

import net.neoforged.fml.ModLoadingContext;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.event.config.ModConfigEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.bus.api.SubscribeEvent;

import java.util.HashMap;
import java.util.Map;

/**
 * Обёртка над LiveMineConfig для удобного доступа.
 *
 * Все значения читаются через геттеры LiveMineConfig.
 * Здесь — только горячая перезагрузка и кэш значений.
 *
 * ИЗМЕНЕНИЯ 20.1:
 *   - Hot reload применяется только к безопасным параметрам.
 *   - При изменении "жёстких" параметров (загрузчик, реестры, генерация) — предупреждение.
 */
public final class ConfigManager {

    private static final Map<String, Object> hotCache = new HashMap<>();

    private ConfigManager() {}

    public static void init() {
        // Регистрируем слушателя событий изменения конфига
        NeoForge.EVENT_BUS.register(ConfigManager.class);
        reload();
    }

    @SubscribeEvent
    public static void onConfigLoad(ModConfigEvent.Loading event) {
        if (event.getConfig().getType() == ModConfig.Type.COMMON) {
            reload();
        }
    }

    @SubscribeEvent
    public static void onConfigReload(ModConfigEvent.Reloading event) {
        if (event.getConfig().getType() == ModConfig.Type.COMMON) {
            reload();
            LiveMineMod.LOGGER.info("LiveMine: common config reloaded (hot)");
        }
    }

    /**
     * Перечитывает значения из LiveMineConfig в кэш.
     */
    public static void reload() {
        hotCache.clear();

        // NPC
        hotCache.put("maxTotalNpcs", LiveMineConfig.maxTotalNpcs());
        hotCache.put("maxNpcsPerVillage", LiveMineConfig.maxNpcsPerVillage());
        hotCache.put("maxActivePerPlayer", LiveMineConfig.maxActivePerPlayer());

        // Оптимизация
        hotCache.put("adaptiveTickRate", LiveMineConfig.adaptiveTickRate());
        hotCache.put("simulationInterval", LiveMineConfig.simulationInterval());
        hotCache.put("batchPerTick", LiveMineConfig.batchPerTick());
        hotCache.put("activeRadius", LiveMineConfig.activeRadius());
        hotCache.put("simulatedRadius", LiveMineConfig.simulatedRadius());
        hotCache.put("dormantRadius", LiveMineConfig.dormantRadius());

        // Геймплей
        hotCache.put("enableHolidays", LiveMineConfig.enableHolidays());
        hotCache.put("enableVoting", LiveMineConfig.enableVoting());
        hotCache.put("enableEconomy", LiveMineConfig.enableEconomy());

        // Применяем к подсистемам
        applyToSubsystems();
    }

    private static void applyToSubsystems() {
        // AdaptiveTickRate обновит свой tier на следующем тике
        // ThrottlingManager / NPCActivityManager читают LiveMineConfig напрямую
        // VillageManager читает конфиг напрямую
        // Изменения вступают в силу автоматически
    }

    public static boolean isHotReloadable(String field) {
        return switch (field) {
            case "maxTotalNpcs", "maxActivePerPlayer", "brainDebug",
                 "adaptiveTickRate", "simulationInterval", "batchPerTick",
                 "activeRadius", "simulatedRadius", "dormantRadius",
                 "resourceCacheTtl", "enableHolidays", "enableVoting",
                 "enableEconomy", "enableWeatherEffects", "enableDiseases",
                 "skillDecayPerDay" -> true;
            default -> false;
        };
    }

    public static Object get(String key) {
        return hotCache.get(key);
    }

    public static int getInt(String key, int def) {
        Object v = hotCache.get(key);
        return (v instanceof Number n) ? n.intValue() : def;
    }

    public static boolean getBoolean(String key, boolean def) {
        Object v = hotCache.get(key);
        return (v instanceof Boolean b) ? b : def;
    }
}
