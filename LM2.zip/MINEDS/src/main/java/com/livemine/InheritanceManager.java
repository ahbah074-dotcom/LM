package com.livemine;

import com.livemine.ai.NPCRegistry;
import com.livemine.entity.LiveNPCEntity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Менеджер наследования имущества.
 *
 * v2.1: пишет в Chronicle деревни при передаче наследства.
 */
public final class InheritanceManager {

    private static InheritanceManager INSTANCE;

    private InheritanceManager() {}

    public static synchronized InheritanceManager getInstance() {
        if (INSTANCE == null) INSTANCE = new InheritanceManager();
        return INSTANCE;
    }

    public void onNpcDeath(LiveNPCEntity deceased) {
        if (deceased == null) return;
        try {
            processInheritance(deceased);
        } catch (Exception e) {
            LiveMineMod.LOGGER.error("InheritanceManager failed for {}",
                deceased.getUUID(), e);
        }
    }

    public void processInheritance(LiveNPCEntity deceased) {
        if (deceased == null) return;
        if (!(deceased.level() instanceof ServerLevel level)) return;

        // Собираем инвентарь.
        List<ItemStack> items = new ArrayList<>();
        var inv = deceased.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (!stack.isEmpty()) {
                items.add(stack.copy());
                inv.setItem(i, ItemStack.EMPTY);
            }
        }

        long day = level.getDayTime() / 24000L;
        String rawId = deceased.getVillageRawId();

        if (items.isEmpty()) {
            logChronicle(rawId, level, day,
                "Смерть " + deceased.getCustomNameTag() + " (без имущества)");
            return;
        }

        // 1. Супруг
        LiveNPCEntity spouse = findSpouse(deceased);
        if (spouse != null && spouse.isAlive()) {
            transferItems(spouse, items);
            logChronicle(rawId, level, day,
                "Наследство " + deceased.getCustomNameTag()
                    + " перешло супругу " + spouse.getCustomNameTag());
            LiveMineMod.LOGGER.info("Inheritance: {} -> spouse {}",
                deceased.getCustomNameTag(), spouse.getCustomNameTag());
            return;
        }

        // 2. Дети
        List<LiveNPCEntity> children = findChildren(deceased, level);
        if (!children.isEmpty()) {
            distributeEqually(children, items);
            logChronicle(rawId, level, day,
                "Наследство " + deceased.getCustomNameTag()
                    + " поделено между " + children.size() + " детьми");
            LiveMineMod.LOGGER.info("Inheritance: {} -> {} children",
                deceased.getCustomNameTag(), children.size());
            return;
        }

        // 3. Родители
        List<LiveNPCEntity> parents = findParents(deceased, level);
        if (!parents.isEmpty()) {
            for (LiveNPCEntity p : parents) transferItems(p, items);
            logChronicle(rawId, level, day,
                "Наследство " + deceased.getCustomNameTag() + " перешло родителям");
            LiveMineMod.LOGGER.info("Inheritance: {} -> parents", deceased.getCustomNameTag());
            return;
        }

        // 4. Община
        logChronicle(rawId, level, day,
            "Наследство " + deceased.getCustomNameTag() + " перешло общине");
        distributeToVillage(deceased, level, items);
    }

    private void logChronicle(String rawId, ServerLevel level, long day, String description) {
        if (rawId == null || rawId.isEmpty()) return;
        try {
            VillageData vd = new VillageData(rawId, level);
            if (vd.exists()) {
                vd.addChronicleEntry(Chronicle.EntryType.DEATH, day, description);
            }
        } catch (Exception e) {
            LiveMineMod.LOGGER.error("Inheritance: chronicle write failed", e);
        }
    }

    private LiveNPCEntity findSpouse(LiveNPCEntity npc) {
        UUID spouseId = npc.getSpouseUUID();
        if (spouseId == null) return null;
        LiveNPCEntity s = NPCRegistry.getNPC(spouseId);
        return (s != null && s.isAlive()) ? s : null;
    }

    private List<LiveNPCEntity> findChildren(LiveNPCEntity npc, ServerLevel level) {
        List<LiveNPCEntity> result = new ArrayList<>();
        LiveMineSavedData data = LiveMineSavedData.get(level);

        for (var entry : data.getAllNpcData().entrySet()) {
            CompoundTag tag = entry.getValue();
            if (tag.getBoolean("dead")) continue;

            UUID parentA = tag.hasUUID("parent_a_uuid") ? tag.getUUID("parent_a_uuid") : null;
            UUID parentB = tag.hasUUID("parent_b_uuid") ? tag.getUUID("parent_b_uuid") : null;

            if (npc.getUUID().equals(parentA) || npc.getUUID().equals(parentB)) {
                LiveNPCEntity child = NPCRegistry.getNPC(entry.getKey());
                if (child != null && child.isAlive()) result.add(child);
            }
        }
        return result;
    }

    private List<LiveNPCEntity> findParents(LiveNPCEntity npc, ServerLevel level) {
        List<LiveNPCEntity> result = new ArrayList<>();
        CompoundTag tag = LiveMineSavedData.get(level).loadNPCData(npc.getUUID());

        if (tag.hasUUID("parent_a_uuid")) {
            LiveNPCEntity p = NPCRegistry.getNPC(tag.getUUID("parent_a_uuid"));
            if (p != null && p.isAlive()) result.add(p);
        }
        if (tag.hasUUID("parent_b_uuid")) {
            LiveNPCEntity p = NPCRegistry.getNPC(tag.getUUID("parent_b_uuid"));
            if (p != null && p.isAlive() && !result.contains(p)) result.add(p);
        }
        return result;
    }

    private void transferItems(LiveNPCEntity recipient, List<ItemStack> items) {
        for (ItemStack stack : items) {
            recipient.addItemToInventory(stack);
        }
    }

    private void distributeEqually(List<LiveNPCEntity> recipients, List<ItemStack> items) {
        int idx = 0;
        for (ItemStack stack : items) {
            LiveNPCEntity recipient = recipients.get(idx % recipients.size());
            recipient.addItemToInventory(stack);
            idx++;
        }
    }

    private void distributeToVillage(LiveNPCEntity deceased, ServerLevel level, List<ItemStack> items) {
        String rawId = deceased.getVillageRawId();
        if (rawId.isEmpty()) {
            dropItems(deceased, items);
            return;
        }

        VillageData vd = new VillageData(rawId, level);
        if (!vd.exists()) {
            dropItems(deceased, items);
            return;
        }

        var storages = vd.getStructures(com.livemine.blocks.StorageBlock.class);
        if (storages.isEmpty()) {
            dropItems(deceased, items);
            return;
        }

        var storagePos = storages.get(0);
        var be = level.getBlockEntity(storagePos);
        if (be instanceof com.livemine.blocks.StorageBlockEntity storage) {
            for (ItemStack stack : items) {
                ItemStack remaining = storage.insert(stack);
                if (!remaining.isEmpty()) dropItems(deceased, List.of(remaining));
            }
        } else {
            dropItems(deceased, items);
        }
    }

    private void dropItems(LiveNPCEntity npc, List<ItemStack> items) {
        for (ItemStack stack : items) {
            if (!stack.isEmpty()) {
                npc.spawnAtLocation(stack);
            }
        }
    }

    public boolean hasWill(LiveNPCEntity npc) {
        return npc.getSpouseUUID() != null;
    }
}
