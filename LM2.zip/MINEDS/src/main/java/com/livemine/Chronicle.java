package com.livemine;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 * Хроника событий деревни.
 *
 * Хранит историю: рождение, смерть, брак, постройки, выборы,
 * праздники, рейды, экспедиции, катастрофы, достижения.
 *
 * Использует ИГРОВОЕ время (дни), не System.currentTimeMillis.
 */
public class Chronicle {

    public static final int MAX_ENTRIES = 500;

    // =========================================================================
    // EntryType — типы событий
    // =========================================================================
    public enum EntryType {
        FOUNDING,       // основание деревни
        BIRTH,          // рождение
        DEATH,          // смерть
        MARRIAGE,       // брак
        MIGRATION,      // миграция / приход
        BUILDING,       // постройка
        DESTRUCTION,    // разрушение
        ELECTION,       // выборы лидера
        HOLIDAY,        // праздник
        RAID,           // рейд
        WAR,            // РІРѕР№РЅР°
        ALLIANCE,       // альянс
        TRADE,          // торговая сделка / караван
        EXPEDITION,     // экспедиция
        CATASTROPHE,    // катастрофа (пожар, лава)
        ACHIEVEMENT,    // достижение
        MASTER,         // достижение уровня 10
        LAW,            // принятие закона / суд
        PUNISHMENT,     // наказание
        OTHER
    }

    // =========================================================================
    // ChronicleEntry — одна запись
    // =========================================================================
    public static final class ChronicleEntry {
        public final long day;
        public final EntryType type;
        public final String description;
        public final String actor;    // имя действующего лица (может быть пусто)
        public final UUID actorUuid;  // UUID (может быть null)

        public ChronicleEntry(long day, EntryType type, String description, String actor, UUID actorUuid) {
            this.day = day;
            this.type = type;
            this.description = description;
            this.actor = actor == null ? "" : actor;
            this.actorUuid = actorUuid;
        }

        public CompoundTag save() {
            CompoundTag tag = new CompoundTag();
            tag.putLong("day", day);
            tag.putString("type", type.name());
            tag.putString("desc", description);
            tag.putString("actor", actor);
            if (actorUuid != null) tag.putUUID("actorUuid", actorUuid);
            return tag;
        }

        public static ChronicleEntry load(CompoundTag tag) {
            return new ChronicleEntry(
                tag.getLong("day"),
                EntryType.valueOf(tag.getString("type")),
                tag.getString("desc"),
                tag.getString("actor"),
                tag.hasUUID("actorUuid") ? tag.getUUID("actorUuid") : null
            );
        }
    }

    // =========================================================================
    // Поля
    // =========================================================================
    private final String villageId;
    private final List<ChronicleEntry> entries = new ArrayList<>();

    public Chronicle(String villageId) {
        this.villageId = villageId;
    }

    // =========================================================================
    // Запись событий
    // =========================================================================

    /**
     * Добавляет запись в хронику.
     *
     * @param type        Тип события
     * @param day         Игровой день
     * @param description Описание
     * @param actor       Имя действующего лица (или "")
     */
    public void addEntry(EntryType type, long day, String description, String actor) {
        entries.add(new ChronicleEntry(day, type, description, actor, null));
        trim();
    }

    /**
     * Добавляет запись с UUID.
     */
    public void addEntry(EntryType type, long day, String description, String actor, UUID actorUuid) {
        entries.add(new ChronicleEntry(day, type, description, actor, actorUuid));
        trim();
    }

    /**
     * Добавляет запись без действующего лица.
     */
    public void addEntry(EntryType type, long day, String description) {
        addEntry(type, day, description, "");
    }

    private void trim() {
        if (entries.size() > MAX_ENTRIES) {
            // Удаляем самые старые записи, кроме FOUNDING
            entries.sort((a, b) -> Long.compare(b.day, a.day));
            while (entries.size() > MAX_ENTRIES) {
                entries.remove(entries.size() - 1);
            }
        }
    }

    // =========================================================================
    // Чтение
    // =========================================================================

    public List<ChronicleEntry> getEntries() {
        return Collections.unmodifiableList(entries);
    }

    public List<ChronicleEntry> getRecentEntries(int count) {
        List<ChronicleEntry> sorted = new ArrayList<>(entries);
        sorted.sort((a, b) -> Long.compare(b.day, a.day));
        return sorted.subList(0, Math.min(count, sorted.size()));
    }

    public List<ChronicleEntry> getEntriesByType(EntryType type) {
        List<ChronicleEntry> result = new ArrayList<>();
        for (ChronicleEntry e : entries) {
            if (e.type == type) result.add(e);
        }
        return result;
    }

    public List<ChronicleEntry> getEntriesByActor(String actor) {
        List<ChronicleEntry> result = new ArrayList<>();
        for (ChronicleEntry e : entries) {
            if (e.actor.equals(actor)) result.add(e);
        }
        return result;
    }

    public int getEntryCount() { return entries.size(); }

    // =========================================================================
    // NBT
    // =========================================================================

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putString("villageId", villageId);

        ListTag list = new ListTag();
        for (ChronicleEntry e : entries) {
            list.add(e.save());
        }
        tag.put("entries", list);
        return tag;
    }

    public void load(CompoundTag tag) {
        entries.clear();
        ListTag list = tag.getList("entries", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            entries.add(ChronicleEntry.load(list.getCompound(i)));
        }
    }

    public static Chronicle fromNbt(String villageId, CompoundTag tag) {
        Chronicle c = new Chronicle(villageId);
        c.load(tag);
        return c;
    }
}
