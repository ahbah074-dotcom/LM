package com.livemine;

import com.livemine.achievement.AchievementManager;
import com.livemine.diplomacy.AllianceManager;
import com.livemine.diplomacy.DiplomacyManager;
import com.livemine.diplomacy.MailManager;
import com.livemine.diplomacy.WarManager;
import com.livemine.pet.PetManager;
import com.livemine.property.PropertyManager;
import com.livemine.quest.QuestManager;
import com.livemine.voting.VotingManager;
import com.livemine.world.CaravanManager;
import com.livemine.world.ScoutManager;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.level.LevelEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Центральный менеджер сохранения/загрузки.
 *
 * v3.3: сохранение всех singleton-менеджеров:
 *   - дипломатия, альянсы, войны, почта, караваны, разведка;
 *   - питомцы;
 *   - собственность;
 *   - квесты;
 *   - голосования;
 *   - репутация;
 *   - достижения.
 */
@EventBusSubscriber(modid = LiveMineMod.MOD_ID)
public final class PersistenceManager {

    private static final Map<ServerLevel, PersistenceManager> INSTANCES = new ConcurrentHashMap<>();

    private final ServerLevel level;
    private final Map<UUID, CompoundTag> npcCache = new ConcurrentHashMap<>();
    private final Map<String, CompoundTag> villageCache = new ConcurrentHashMap<>();

    private PersistenceManager(ServerLevel level) {
        this.level = level;
    }

    public static PersistenceManager get(ServerLevel level) {
        return INSTANCES.computeIfAbsent(level, PersistenceManager::new);
    }

    @SubscribeEvent
    public static void onLevelUnload(LevelEvent.Unload event) {
        if (!(event.getLevel() instanceof ServerLevel serverLevel)) return;

        PersistenceManager pm = INSTANCES.remove(serverLevel);
        if (pm != null) {
            pm.saveAll();
            LiveMineMod.LOGGER.debug("LiveMine: PersistenceManager flushed and removed for level {}",
                serverLevel.dimension().location());
        }
    }

    // =========================================================================
    // NPC
    // =========================================================================

    public CompoundTag loadNPCData(UUID uuid) {
        CompoundTag cached = npcCache.get(uuid);
        if (cached != null) return cached;

        CompoundTag fromData = LiveMineSavedData.get(level).loadNPCData(uuid);
        if (fromData != null && !fromData.isEmpty()) {
            npcCache.put(uuid, fromData);
            return fromData;
        }
        return new CompoundTag();
    }

    public void saveNPCData(UUID uuid, CompoundTag data) {
        npcCache.put(uuid, data);
    }

    public void removeNPCData(UUID uuid) {
        npcCache.remove(uuid);
        LiveMineSavedData.get(level).removeNPCData(uuid);
    }

    // =========================================================================
    // Деревни
    // =========================================================================

    public CompoundTag loadVillageData(String villageId) {
        CompoundTag cached = villageCache.get(villageId);
        if (cached != null) return cached;

        CompoundTag fromData = LiveMineSavedData.get(level).loadVillageData(villageId);
        if (fromData != null && !fromData.isEmpty()) {
            villageCache.put(villageId, fromData);
            return fromData;
        }
        return new CompoundTag();
    }

    public void saveVillageData(String villageId, CompoundTag data) {
        villageCache.put(villageId, data);
    }

    // =========================================================================
    // v3.3: Системы
    // =========================================================================

    private void saveSystems() {
        try {
            LiveMineSavedData savedData = LiveMineSavedData.get(level);
            CompoundTag global = savedData.getGlobalData();

            // Дипломатия и мир.
            global.put("diplomacy", DiplomacyManager.getInstance().save());
            global.put("alliance", AllianceManager.getInstance().save());
            global.put("war", WarManager.getInstance().save());
            global.put("mail", MailManager.getInstance().save());
            global.put("caravan", CaravanManager.getInstance().save());

            // Питомцы.
            global.put("pets", PetManager.getInstance().save());

            // Собственность.
            global.put("property", PropertyManager.getInstance().save());

            // Квесты.
            global.put("quests", QuestManager.getInstance().save());

            // Голосования.
            global.put("voting", VotingManager.getInstance().save());

            // Репутация.
            global.put("reputation", ReputationManager.getInstance().save());

            // Достижения.
            global.put("achievements", AchievementManager.getInstance().save());

            savedData.setGlobalData(global);
            savedData.setDirty();
        } catch (Exception e) {
            LiveMineMod.LOGGER.error("PersistenceManager.saveSystems failed", e);
        }
    }

    private void loadSystems() {
        try {
            LiveMineSavedData savedData = LiveMineSavedData.get(level);
            CompoundTag global = savedData.getGlobalData();

            if (global.contains("diplomacy")) {
                DiplomacyManager.getInstance().load(global.getCompound("diplomacy"));
            }
            if (global.contains("alliance")) {
                AllianceManager.getInstance().load(global.getCompound("alliance"));
            }
            if (global.contains("war")) {
                WarManager.getInstance().load(global.getCompound("war"));
            }
            if (global.contains("mail")) {
                MailManager.getInstance().load(global.getCompound("mail"));
            }
            if (global.contains("caravan")) {
                CaravanManager.getInstance().load(global.getCompound("caravan"));
            }
            if (global.contains("pets")) {
                PetManager.getInstance().load(global.getCompound("pets"));
            }
            if (global.contains("property")) {
                PropertyManager.getInstance().load(global.getCompound("property"));
            }
            if (global.contains("quests")) {
                QuestManager.getInstance().load(global.getCompound("quests"));
            }
            if (global.contains("voting")) {
                VotingManager.getInstance().load(global.getCompound("voting"));
            }
            if (global.contains("reputation")) {
                ReputationManager.getInstance().load(global.getCompound("reputation"));
            }
            if (global.contains("achievements")) {
                AchievementManager.getInstance().load(global.getCompound("achievements"));
            }

            LiveMineMod.LOGGER.info(
                "PersistenceManager: systems loaded (rel={}, alli={}, wars={}, mail={}, "
                    + "caravans={}, pets={}, props={}, quests={}, votes={})",
                DiplomacyManager.getInstance().size(),
                AllianceManager.getInstance().size(),
                WarManager.getInstance().size(),
                MailManager.getInstance().getInTransit().size(),
                CaravanManager.getInstance().getActiveCaravans().size(),
                PetManager.getInstance().size(),
                PropertyManager.getInstance().size(),
                QuestManager.getInstance().size(),
                VotingManager.getInstance().size()
            );
        } catch (Exception e) {
            LiveMineMod.LOGGER.error("PersistenceManager.loadSystems failed", e);
        }
    }

    // =========================================================================
    // Сброс на диск
    // =========================================================================

    public void flush() {
        LiveMineSavedData savedData = LiveMineSavedData.get(level);

        for (Map.Entry<UUID, CompoundTag> entry : npcCache.entrySet()) {
            savedData.saveNPCData(entry.getKey(), entry.getValue());
        }
        for (Map.Entry<String, CompoundTag> entry : villageCache.entrySet()) {
            savedData.saveVillageData(entry.getKey(), entry.getValue());
        }

        saveSystems();
        savedData.setDirty();
    }

    public void saveAll() {
        flush();
        LiveMineMod.LOGGER.debug("LiveMine: full save complete ({} NPCs, {} villages)",
            npcCache.size(), villageCache.size());
    }

    public void loadAll() {
        npcCache.clear();
        villageCache.clear();
        loadSystems();
        LiveMineMod.LOGGER.debug("LiveMine: caches cleared, data will be loaded lazily");
    }

    public static void clearAll() {
        INSTANCES.clear();
    }
}