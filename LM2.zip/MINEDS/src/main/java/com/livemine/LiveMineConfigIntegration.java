package com.livemine;

import com.livemine.ai.AdaptiveTickRate;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.event.config.ModConfigEvent;
import net.neoforged.neoforge.common.NeoForge;

/**
 * Интеграция конфигурации с подсистемами.
 *
 * При загрузке/изменении конфига:
 *   - Обновляет кэш ConfigManager
 *   - Перенастраивает AdaptiveTickRate
 *   - Перенастраивает другие подсистемы
 *
 * Регистрируется из LiveMineMod или ConfigManager.init().
 */
public final class LiveMineConfigIntegration {

    private LiveMineConfigIntegration() {}

    public static void init() {
        NeoForge.EVENT_BUS.register(LiveMineConfigIntegration.class);
    }

    @SubscribeEvent
    public static void onConfigLoad(ModConfigEvent.Loading event) {
        if (event.getConfig().getType() == net.neoforged.fml.config.ModConfig.Type.COMMON) {
            applyConfig();
        }
    }

    @SubscribeEvent
    public static void onConfigReload(ModConfigEvent.Reloading event) {
        if (event.getConfig().getType() == net.neoforged.fml.config.ModConfig.Type.COMMON) {
            applyConfig();
            LiveMineMod.LOGGER.info("LiveMine: config reloaded, subsystems updated");
        }
    }

    // =========================================================================
    // Применение
    // =========================================================================

    private static void applyConfig() {
        // Обновляем кэш ConfigManager
        ConfigManager.reload();

        // Пересчитываем AdaptiveTickRate
        AdaptiveTickRate.init();

        // Прочие подсистемы читают LiveMineConfig динамически,
        // так что им не нужно дополнительное обновление
    }
}
