package com.livemine;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;

import java.util.*;

/**
 * Менеджер кладбищ.
 *
 * Учёт умерших NPC, распределение могил, поиск свободных слотов.
 *
 * Кладбище создаётся при первой смерти в деревне.
 * Зона 10×10, плиты ставятся рядами.
 * Заполнение > 80% → расширение на 5 блоков.
 */
public final class CemeteryManager {

    public static final int BASE_SIZE = 10;
    public static final int EXPANSION_STEP = 5;
    public static final float EXPANSION_THRESHOLD = 0.8f;

    // =========================================================================
    // CemeterySlot — один слот могилы
    // =========================================================================
    public static final class CemeterySlot {
        public final int x, y, z;
        public final UUID graveUuid;
        public final String npcName;
        public final long deathDay;

        public CemeterySlot(int x, int y, int z, UUID graveUuid, String npcName, long deathDay) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.graveUuid = graveUuid;
            this.npcName = npcName;
            this.deathDay = deathDay;
        }

        public BlockPos pos() { return new BlockPos(x, y, z); }

        public CompoundTag save() {
            CompoundTag tag = new CompoundTag();
            tag.putInt("x", x);
            tag.putInt("y", y);
            tag.putInt("z", z);
            tag.putUUID("grave", graveUuid);
            tag.putString("npc", npcName);
            tag.putLong("day", deathDay);
            return tag;
        }

        public static CemeterySlot load(CompoundTag tag) {
            return new CemeterySlot(
                tag.getInt("x"),
                tag.getInt("y"),
                tag.getInt("z"),
                tag.getUUID("grave"),
                tag.getString("npc"),
                tag.getLong("day")
            );
        }
    }

    // =========================================================================
    // Cemetery — кладбище одной деревни
    // =========================================================================
    public static final class Cemetery {
        public final String villageId;
        public BlockPos center;
        public int currentSize;
        public final List<CemeterySlot> slots = new ArrayList<>();
        public final Set<UUID> recordedNpcIds = new HashSet<>();

        public Cemetery(String villageId) {
            this.villageId = villageId;
            this.currentSize = BASE_SIZE;
        }

        public void setCenter(BlockPos center) {
            this.center = center;
        }

        public int getCapacity() {
            return currentSize * currentSize;
        }

        public float getFillRatio() {
            int cap = getCapacity();
            return cap == 0 ? 0f : (float) slots.size() / cap;
        }

        public boolean needsExpansion() {
            return getFillRatio() > EXPANSION_THRESHOLD;
        }

        public void expand() {
            currentSize += EXPANSION_STEP;
        }

        public boolean alreadyHas(UUID npcId) {
            return recordedNpcIds.contains(npcId);
        }

        public CompoundTag save() {
            CompoundTag tag = new CompoundTag();
            tag.putString("villageId", villageId);
            if (center != null) {
                tag.putInt("cx", center.getX());
                tag.putInt("cy", center.getY());
                tag.putInt("cz", center.getZ());
            }
            tag.putInt("size", currentSize);

            ListTag slotList = new ListTag();
            for (CemeterySlot s : slots) slotList.add(s.save());
            tag.put("slots", slotList);

            ListTag idList = new ListTag();
            for (UUID id : recordedNpcIds) {
                CompoundTag idTag = new CompoundTag();
                idTag.putUUID("id", id);
                idList.add(idTag);
            }
            tag.put("recordedNpcIds", idList);
            return tag;
        }

        public static Cemetery load(CompoundTag tag) {
            Cemetery c = new Cemetery(tag.getString("villageId"));
            if (tag.contains("cx")) {
                c.setCenter(new BlockPos(tag.getInt("cx"), tag.getInt("cy"), tag.getInt("cz")));
            }
            c.currentSize = tag.getInt("size");

            ListTag slotList = tag.getList("slots", Tag.TAG_COMPOUND);
            for (int i = 0; i < slotList.size(); i++) {
                c.slots.add(CemeterySlot.load(slotList.getCompound(i)));
            }

            ListTag idList = tag.getList("recordedNpcIds", Tag.TAG_COMPOUND);
            for (int i = 0; i < idList.size(); i++) {
                c.recordedNpcIds.add(idList.getCompound(i).getUUID("id"));
            }
            return c;
        }
    }

    // =========================================================================
    // Поля
    // =========================================================================
    private static CemeteryManager INSTANCE;

    private final Map<String, Cemetery> cemeteries = new HashMap<>();

    private CemeteryManager() {}

    public static synchronized CemeteryManager getInstance() {
        if (INSTANCE == null) INSTANCE = new CemeteryManager();
        return INSTANCE;
    }

    // =========================================================================
    // Основные операции
    // =========================================================================

    /**
     * Назначает кладбище деревне.
     */
    public Cemetery designateCemetery(String villageId, int x, int y, int z) {
        Cemetery c = cemeteries.computeIfAbsent(villageId, Cemetery::new);
        c.setCenter(new BlockPos(x, y, z));
        return c;
    }

    /**
     * Записывает смерть NPC.
     */
    public void recordDeath(String villageId, UUID npcId, String npcName, String cause, long day) {
        Cemetery c = cemeteries.get(villageId);
        if (c == null) return;
        c.recordedNpcIds.add(npcId);
        LiveMineMod.LOGGER.info("Cemetery {}: recorded death of {} ({})", villageId, npcName, cause);
    }

    /**
     * Находит свободный слот на кладбище.
     * Возвращает null, если кладбище не назначено или места нет.
     */
    public CemeterySlot findFreeSlot(String villageId) {
        Cemetery c = cemeteries.get(villageId);
        if (c == null || c.center == null) return null;

        if (c.needsExpansion()) c.expand();

        int size = c.currentSize;
        int cx = c.center.getX();
        int cy = c.center.getY();
        int cz = c.center.getZ();

        // Ищем свободную позицию в спирали от центра
        Set<Long> occupied = new HashSet<>();
        for (CemeterySlot s : c.slots) {
            occupied.add(packPos(s.x, s.y, s.z));
        }

        for (int radius = 0; radius <= size / 2; radius++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (Math.abs(dx) != radius && Math.abs(dz) != radius) continue;
                    int x = cx + dx;
                    int z = cz + dz;
                    long key = packPos(x, cy, z);
                    if (!occupied.contains(key)) {
                        return new CemeterySlot(x, cy, z, null, "", 0);
                    }
                }
            }
        }
        return null;
    }

    /**
     * Занимает слот на кладбище.
     */
    public void occupySlot(String villageId, int x, int y, int z, UUID graveUuid, String npcName) {
        Cemetery c = cemeteries.get(villageId);
        if (c == null) return;
        c.slots.add(new CemeterySlot(x, y, z, graveUuid, npcName, 0));
        LiveMineMod.LOGGER.info("Cemetery {}: grave at ({},{},{}) for {}",
            villageId, x, y, z, npcName);
    }

    public Cemetery getCemetery(String villageId) {
        return cemeteries.get(villageId);
    }

    public Collection<Cemetery> getAllCemeteries() {
        return cemeteries.values();
    }

    public int getTotalDeaths() {
        int total = 0;
        for (Cemetery c : cemeteries.values()) total += c.recordedNpcIds.size();
        return total;
    }

    public void clear() {
        cemeteries.clear();
    }

    // =========================================================================
    // NBT
    // =========================================================================

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        int i = 0;
        for (Cemetery c : cemeteries.values()) {
            tag.put("cemetery_" + i, c.save());
            i++;
        }
        tag.putInt("count", i);
        return tag;
    }

    public void load(CompoundTag tag) {
        cemeteries.clear();
        int count = tag.getInt("count");
        for (int i = 0; i < count; i++) {
            if (tag.contains("cemetery_" + i)) {
                Cemetery c = Cemetery.load(tag.getCompound("cemetery_" + i));
                cemeteries.put(c.villageId, c);
            }
        }
    }

    // =========================================================================
    // Утилиты
    // =========================================================================

    private static long packPos(int x, int y, int z) {
        return ((long)(x & 0x3FFFFFF) << 38) | ((long)(z & 0x3FFFFFF) << 12) | (y & 0xFFF);
    }
}
