package com.livemine;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

import java.util.*;

/**
 * Коллективная память деревни.
 *
 * Правила (ТЗ 20.0 §9):
 *   - Пополняется только через рассказ взрослому в деревне.
 *   - Запрещено передавать: координаты тайников, содержимое личных контейнеров,
 *     ключи, частные переписки, завещания, медицинские подробности.
 *   - 22 публичные категории.
 *   - 14 триггеров.
 *
 * Хранит: Map<key, MemoryRecord>.
 */
public final class CollectiveMemory {

    public static final int MAX_MEMORIES = 200;

    // =========================================================================
    // 22 публичные категории (ТЗ 20.0 §9.2)
    // =========================================================================
    public enum Category {
        CARTOGRAPHY, THREATS, CONSTRUCTION, AGRICULTURE,
        REPUTATION, DECISIONS, ALLIANCES, PROFESSIONAL,
        PORTALS, TRADE, SANITARY, ARCHAEOLOGY,
        ENGINEERING, DIMENSIONS, OCEAN, GREENERY,
        GENEALOGY, HOLIDAYS, CONFLICTS, CHRONICLE,
        EXCHANGE, FINDS
    }

    // =========================================================================
    // 14 триггеров (ТЗ 20.0 §9.3)
    // =========================================================================
    public enum Trigger {
        RESOURCE_FOUND, STRUCTURE_FOUND, THREAT_FOUND, COMBAT_EXPERIENCE,
        ERROR_SURVIVED, SEASONAL_EXPERIENCE, TRADE_EXPERIENCE, CRAFT_EXPERIENCE,
        SCOUT_REPORT, LOCATION_EXPERIENCE, NPC_LOST, LANDSCAPE_CHANGE,
        PLAYER_EVENT, EMOTIONAL_STATE
    }

    // =========================================================================
    // MemoryRecord — одна запись
    // =========================================================================
    public static final class MemoryRecord {
        public final String key;
        public final String value;
        public final Category category;
        public final Trigger trigger;
        public final long timestamp;      // игровой день
        public final int importance;      // 1–10
        public final String source;       // кто рассказал
        public final float reliability;   // 0.0–1.0 (надёжность)

        public MemoryRecord(String key, String value, Category category, Trigger trigger,
                            long timestamp, int importance, String source, float reliability) {
            this.key = key;
            this.value = value;
            this.category = category;
            this.trigger = trigger;
            this.timestamp = timestamp;
            this.importance = Math.max(1, Math.min(10, importance));
            this.source = source == null ? "" : source;
            this.reliability = Math.max(0f, Math.min(1f, reliability));
        }

        public CompoundTag save() {
            CompoundTag tag = new CompoundTag();
            tag.putString("key", key);
            tag.putString("value", value);
            tag.putString("category", category.name());
            tag.putString("trigger", trigger.name());
            tag.putLong("timestamp", timestamp);
            tag.putInt("importance", importance);
            tag.putString("source", source);
            tag.putFloat("reliability", reliability);
            return tag;
        }

        public static MemoryRecord load(CompoundTag tag) {
            return new MemoryRecord(
                tag.getString("key"),
                tag.getString("value"),
                Category.valueOf(tag.getString("category")),
                Trigger.valueOf(tag.getString("trigger")),
                tag.getLong("timestamp"),
                tag.getInt("importance"),
                tag.getString("source"),
                tag.getFloat("reliability")
            );
        }
    }

    // =========================================================================
    // Поля
    // =========================================================================
    private final String villageId;
    private final Map<String, MemoryRecord> memories = new LinkedHashMap<>();

    public CollectiveMemory(String villageId) {
        this.villageId = villageId;
    }

    // =========================================================================
    // Запоминание
    // =========================================================================

    public void remember(String key, String value, Category category, Trigger trigger,
                          long day, int importance, String source, float reliability) {
        // Если памяти слишком много — удаляем наименее важные
        if (memories.size() >= MAX_MEMORIES && !memories.containsKey(key)) {
            evictLeastImportant();
        }
        memories.put(key, new MemoryRecord(key, value, category, trigger, day, importance, source, reliability));
    }

    /** Упрощённый вариант (важность 5, надёжность 1.0). */
    public void remember(String key, String value, Category category, long day, String source) {
        remember(key, value, category, Trigger.LOCATION_EXPERIENCE, day, 5, source, 1.0f);
    }

    private void evictLeastImportant() {
        String leastKey = null;
        int minImportance = Integer.MAX_VALUE;
        long oldestTime = Long.MAX_VALUE;

        for (Map.Entry<String, MemoryRecord> e : memories.entrySet()) {
            MemoryRecord r = e.getValue();
            if (r.importance < minImportance ||
                (r.importance == minImportance && r.timestamp < oldestTime)) {
                minImportance = r.importance;
                oldestTime = r.timestamp;
                leastKey = e.getKey();
            }
        }
        if (leastKey != null) memories.remove(leastKey);
    }

    // =========================================================================
    // Чтение
    // =========================================================================

    public String recall(String key) {
        MemoryRecord r = memories.get(key);
        return r != null ? r.value : null;
    }

    public MemoryRecord get(String key) {
        return memories.get(key);
    }

    public boolean knows(String key) {
        return memories.containsKey(key);
    }

    public void forget(String key) {
        memories.remove(key);
    }

    public Collection<MemoryRecord> getAllMemories() {
        return Collections.unmodifiableCollection(memories.values());
    }

    public List<MemoryRecord> getByCategory(Category category) {
        List<MemoryRecord> result = new ArrayList<>();
        for (MemoryRecord r : memories.values()) {
            if (r.category == category) result.add(r);
        }
        return result;
    }

    public List<MemoryRecord> getByTrigger(Trigger trigger) {
        List<MemoryRecord> result = new ArrayList<>();
        for (MemoryRecord r : memories.values()) {
            if (r.trigger == trigger) result.add(r);
        }
        return result;
    }

    public int size() { return memories.size(); }

    // =========================================================================
    // Очистка
    // =========================================================================

    /**
     * Удаляет устаревшие записи (старше N дней).
     * Важные (importance ≥ 8) не удаляются.
     */
    public void cleanup(long currentDay) {
        long maxAge = 365; // РіРѕРґ
        memories.entrySet().removeIf(e -> {
            MemoryRecord r = e.getValue();
            return r.importance < 8 && (currentDay - r.timestamp) > maxAge;
        });
    }

    // =========================================================================
    // NBT
    // =========================================================================

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putString("villageId", villageId);

        ListTag list = new ListTag();
        for (MemoryRecord r : memories.values()) {
            list.add(r.save());
        }
        tag.put("memories", list);
        return tag;
    }

    public void load(CompoundTag tag) {
        memories.clear();
        ListTag list = tag.getList("memories", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            MemoryRecord r = MemoryRecord.load(list.getCompound(i));
            memories.put(r.key, r);
        }
    }

    public static CollectiveMemory fromNbt(String villageId, CompoundTag tag) {
        CollectiveMemory m = new CollectiveMemory(villageId);
        m.load(tag);
        return m;
    }
}
