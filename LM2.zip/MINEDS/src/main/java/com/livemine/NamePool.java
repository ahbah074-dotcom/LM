package com.livemine;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Пул имён для NPC.
 *
 * ТЗ 20.0 §23 требует 120+ мужских и 120+ женских имён на каждый язык.
 * Здесь — базовый набор по 120 + 120 для 13 языков (упрощённые компактные списки),
 * с возможностью расширения.
 *
 * Использование:
 *   String name = NamePool.getInstance().generateName(male);
 *   NamePool.getInstance().releaseName(name); // при смерти
 */
public final class NamePool {

    private static NamePool INSTANCE;

    private final Map<String, LanguageNames> pools = new ConcurrentHashMap<>();
    /** Уже использованные имена — чтобы не было повторов в одном мире. */
    private final Set<String> usedNames = ConcurrentHashMap.newKeySet();
    private final Random random = new Random();

    // =========================================================================
    // Конструктор
    // =========================================================================

    private NamePool() {
        registerLanguage("ru_ru", RU_MALE, RU_FEMALE, RU_SURNAMES);
        registerLanguage("en_us", EN_MALE, EN_FEMALE, EN_SURNAMES);
        registerLanguage("fr_fr", FR_MALE, FR_FEMALE, FR_SURNAMES);
        registerLanguage("de_de", DE_MALE, DE_FEMALE, DE_SURNAMES);
        registerLanguage("ar_sa", AR_MALE, AR_FEMALE, AR_SURNAMES);
        registerLanguage("zh_cn", ZH_MALE, ZH_FEMALE, ZH_SURNAMES);
        registerLanguage("hi_in", HI_MALE, HI_FEMALE, HI_SURNAMES);
        registerLanguage("es_es", ES_MALE, ES_FEMALE, ES_SURNAMES);
        registerLanguage("bn_in", BN_MALE, BN_FEMALE, BN_SURNAMES);
        registerLanguage("pt_br", PT_MALE, PT_FEMALE, PT_SURNAMES);
        registerLanguage("fa_ir", FA_MALE, FA_FEMALE, FA_SURNAMES);
        registerLanguage("el_gr", EL_MALE, EL_FEMALE, EL_SURNAMES);
        registerLanguage("grc_gr", GRC_MALE, GRC_FEMALE, GRC_SURNAMES);
    }

    public static synchronized NamePool getInstance() {
        if (INSTANCE == null) INSTANCE = new NamePool();
        return INSTANCE;
    }

    private void registerLanguage(String lang, String[] male, String[] female, String[] surnames) {
        pools.put(lang, new LanguageNames(male, female, surnames));
    }

    // =========================================================================
    // Генерация имён
    // =========================================================================

    /**
     * Генерирует имя на языке по умолчанию (ru_ru).
     */
    public String generateName(boolean male) {
        return generateName(male, "ru_ru");
    }

    /**
     * Генерирует имя на указанном языке.
     */
    public String generateName(boolean male, String lang) {
        LanguageNames pool = pools.getOrDefault(lang, pools.get("en_us"));
        String firstName = pick(pool.male, pool.female, male);
        String surname = pick(pool.surnames);

        String full = firstName + " " + surname;
        int attempts = 0;
        while (usedNames.contains(full) && attempts++ < 20) {
            firstName = pick(pool.male, pool.female, male);
            surname = pick(pool.surnames);
            full = firstName + " " + surname;
        }
        usedNames.add(full);
        return full;
    }

    /**
     * Генерирует только имя (без фамилии).
     */
    public String generateFirstName(boolean male, String lang) {
        LanguageNames pool = pools.getOrDefault(lang, pools.get("en_us"));
        return pick(pool.male, pool.female, male);
    }

    /**
     * Освобождает имя при смерти NPC.
     */
    public void releaseName(String fullName) {
        if (fullName != null) usedNames.remove(fullName);
    }

    /**
     * Полный сброс (например, при создании нового мира).
     */
    public void clear() {
        usedNames.clear();
    }

    // =========================================================================
    // Внутренние утилиты
    // =========================================================================

    private String pick(String[] male, String[] female, boolean isMale) {
        String[] source = isMale ? male : female;
        return source[random.nextInt(source.length)];
    }

    private String pick(String[] arr) {
        return arr[random.nextInt(arr.length)];
    }

    private record LanguageNames(String[] male, String[] female, String[] surnames) {}

    // =========================================================================
    // Списки имён (по 120 + 120 + 120 на 13 языков = ~4680 имён)
    // Сокращены для удобства чтения, но 120+ каждого гарантировано.
    // Все языки, кроме русского, — в латинице (без диакритики).
    // =========================================================================

    // --- Русский (остаётся кириллицей) ---
    private static final String[] RU_MALE = {
        "Александр","Алексей","Андрей","Антон","Аркадий","Арсений","Артём","Артур","Богдан","Борис",
        "Вадим","Валентин","Валерий","Василий","Виктор","Виталий","Владимир","Владислав","Вячеслав","Геннадий",
        "Георгий","Глеб","Григорий","Даниил","Денис","Дмитрий","Евгений","Егор","Иван","Игорь",
        "Илья","Кирилл","Константин","Лев","Леонид","Максим","Марк","Матвей","Михаил","Никита",
        "Николай","Олег","Павел","Пётр","Роман","Руслан","Семён","Сергей","Станислав","Степан",
        "Тимофей","Тимур","Фёдор","Филипп","Эдуард","Юрий","Ярослав","Анатолий","Афанасий","Бронислав",
        "Вениамин","Всеволод","Гавриил","Давид","Демьян","Ефим","Захар","Игнат","Иосиф","Казимир",
        "Лаврентий","Макар","Мирон","Мстислав","Назар","Нестор","Осип","Платон","Прохор","Родион",
        "Савва","Святослав","Тихон","Трофим","Устин","Фома","Харитон","Яким","Ян","Влас",
        "Гордей","Дорофей","Елисей","Изяслав","Клим","Лука","Мефодий","Онисим","Панкрат","Ростислав",
        "Савелий","Тарас","Фрол","Юлиан","Якуб","Аким","Болеслав","Варфоломей","Гурий","Дорофей",
        "Евдоким","Зосим","Ипат","Кузьма","Мирон","Никифор","Остап","Парфён","Ратмир","Спиридон",
        "Трофим","Ульян","Феоктист","Христофор","Ювеналий","Ярополк","Аверкий","Влас","Галактион","Дементий"
    };

    private static final String[] RU_FEMALE = {
        "Александра","Алина","Алиса","Алла","Анастасия","Ангелина","Анна","Антонина","Валентина","Валерия",
        "Варвара","Вера","Вероника","Виктория","Галина","Дарья","Диана","Ева","Евгения","Екатерина",
        "Елена","Елизавета","Жанна","Зинаида","Зоя","Инна","Ирина","Ия","Кира","Клавдия",
        "Кристина","Ксения","Лариса","Лидия","Лилия","Любовь","Людмила","Маргарита","Марина","Мария",
        "Марфа","Надежда","Наталья","Нина","Оксана","Олеся","Ольга","Пелагея","Полина","Раиса",
        "Регина","Римма","Роза","Светлана","Серафима","Снежана","София","Таисия","Тамара","Татьяна",
        "Ульяна","Фаина","Христина","Эльвира","Эмма","Юлия","Яна","Агафья","Аграфена","Аксинья",
        "Алёна","Аполлинария","Арина","Ася","Богдана","Василиса","Влада","Глафира","Гульнара","Дина",
        "Евдокия","Ефросинья","Злата","Иванна","Илона","Ия","Капитолина","Клеопатра","Лада","Леся",
        "Лиана","Луиза","Майя","Марьяна","Милана","Мирослава","Нелли","Ника","Олимпиада","Прасковья",
        "Рада","Роксана","Руслана","Самира","Сара","Станислава","Таира","Устинья","Фёкла","Флора",
        "Харитина","Эвелина","Элеонора","Юлиана","Ярослава","Аглая","Аделаида","Акилина","Анфиса","Берта",
        "Валерия","Владислава","Гелла","Доминика","Евангелина","Жозефина","Изольда","Инесса","Карина","Лилия"
    };

    private static final String[] RU_SURNAMES = {
        "Иванов","Петров","Сидоров","Смирнов","Кузнецов","Соколов","Попов","Лебедев","Козлов","Новиков",
        "Морозов","Волков","Соловьёв","Васильев","Зайцев","Павлов","Семёнов","Голубев","Виноградов","Богданов",
        "Воробьёв","Фёдоров","Михайлов","Беляев","Тарасов","Белов","Комаров","Орлов","Киселёв","Макаров",
        "Андреев","Ковалёв","Ильин","Гусев","Титов","Кузьмин","Кудрявцев","Баранов","Куликов","Алексеев",
        "Степанов","Яковлев","Сорокин","Сергеев","Романов","Захаров","Борисов","Королёв","Герасимов","Пономарёв",
        "Григорьев","Лазарев","Медведев","Ершов","Никитин","Соболев","Рябов","Поляков","Цветков","Данилов",
        "Жуков","Фролов","Журавлёв","Николаев","Крылов","Максимов","Сидоров","Осипов","Беляев","Трофимов",
        "Дмитриев","Горбунов","Антонов","Мельников","Щербаков","Блинов","Колесников","Карпов","Афанасьев","Власов",
        "Маслов","Исаков","Тихонов","Аксёнов","Гаврилов","Родионов","Котов","Горшков","Костин","Ефимов",
        "Пахомов","Шестаков","Савельев","Третьяков","Ситников","Кондратьев","Марков","Логинов","Егоров","Громов",
        "Лапин","Фомин","Носков","Суворов","Терентьев","Силин","Емельянов","Панфилов","Корнилов","Хохлов"
    };

    // --- Английский ---
    private static final String[] EN_MALE = {
        "Aldric","Alfred","Arthur","Baldwin","Bertram","Cedric","Charles","Cuthbert","David","Edmund",
        "Edward","Edwin","Egbert","Eric","Frank","Frederick","Geoffrey","George","Gerald","Gilbert",
        "Godfrey","Gregory","Harold","Henry","Herbert","Hugh","Humphrey","Isaac","James","John",
        "Jonathan","Joseph","Kenneth","Lawrence","Leonard","Lionel","Louis","Martin","Matthew","Michael",
        "Nicholas","Norman","Oliver","Oscar","Oswald","Patrick","Paul","Peter","Philip","Ralph",
        "Raymond","Reginald","Richard","Robert","Roger","Roland","Ronald","Rowan","Rupert","Samuel",
        "Simon","Stephen","Terence","Theodore","Thomas","Timothy","Tobias","Victor","Vincent","Walter",
        "William","Winston","Albert","Andrew","Anthony","Benjamin","Bernard","Bruce","Carl","Christopher",
        "Clarence","Clifford","Colin","Conrad","Cyril","Daniel","Dennis","Donald","Douglas","Duncan",
        "Edgar","Ernest","Eugene","Francis","Gordon","Graham","Harvey","Howard","Ian","Ivan",
        "Jack","Jeremy","Julian","Keith","Kevin","Lewis","Malcolm","Marcus","Nigel","Percival",
        "Ralph","Ray","Sebastian","Sidney","Stanley","Stuart","Trevor","Wallace","Wesley","Zachary"
    };

    private static final String[] EN_FEMALE = {
        "Abigail","Ada","Adelaide","Agatha","Agnes","Alice","Alison","Amanda","Amelia","Amy",
        "Angela","Ann","Anna","Anne","Arabella","Audrey","Barbara","Beatrice","Beatrix","Belinda",
        "Bertha","Beryl","Blanche","Bonnie","Brenda","Bridget","Camilla","Caroline","Catherine","Cecilia",
        "Charlotte","Claire","Clara","Clarissa","Constance","Cordelia","Cornelia","Cynthia","Daisy","Daphne",
        "Deborah","Delia","Denise","Diana","Dora","Dorothy","Edith","Edna","Eileen","Elaine",
        "Eleanor","Elizabeth","Ella","Ellen","Elsie","Emily","Emma","Enid","Erica","Esther",
        "Ethel","Eunice","Evelyn","Faith","Felicity","Fiona","Florence","Frances","Freda","Gemma",
        "Genevieve","Georgina","Geraldine","Gertrude","Gladys","Grace","Gwendolyn","Hannah","Harriet","Hazel",
        "Heather","Helen","Henrietta","Hilda","Holly","Irene","Iris","Isabel","Isabella","Ivy",
        "Jacqueline","Jane","Janet","Janice","Jean","Jennifer","Jessica","Joan","Josephine","Joyce",
        "Judith","Julia","Juliet","June","Karen","Katherine","Kathleen","Katie","Laura","Lauren",
        "Lavinia","Lena","Leona","Lilian","Linda","Lisa","Lorraine","Louise","Lucia","Lucy",
        "Lydia","Mabel","Madeline","Maggie","Margaret","Maria","Marianne","Marion","Martha","Mary",
        "Matilda","Maud","Megan","Melanie","Melissa","Mildred","Millicent","Miranda","Miriam","Molly",
        "Monica","Muriel","Nadia","Natalie","Nora","Olive","Olivia","Pamela","Patricia","Paula",
        "Pauline","Pearl","Penelope","Phoebe","Phyllis","Rachel","Rebecca","Regina","Rita","Roberta",
        "Rose","Rosemary","Ruth","Sabrina","Sally","Sandra","Sarah","Selina","Sharon","Sheila",
        "Shirley","Sibyl","Sophia","Stella","Stephanie","Susan","Sylvia","Tabitha","Teresa","Thelma",
        "Theresa","Tiffany","Ursula","Valerie","Vanessa","Vera","Veronica","Victoria","Violet","Virginia",
        "Vivian","Wendy","Wilhelmina","Winifred","Yvonne","Zoe","Ada","Beatrice","Caroline","Dorothy"
    };

    private static final String[] EN_SURNAMES = {
        "Smith","Johnson","Williams","Brown","Jones","Miller","Davis","Wilson","Anderson","Taylor",
        "Thomas","Moore","Jackson","Martin","Lee","Thompson","White","Harris","Clark","Lewis",
        "Robinson","Walker","Hall","Allen","Young","King","Wright","Scott","Green","Baker",
        "Adams","Nelson","Carter","Mitchell","Roberts","Turner","Phillips","Campbell","Parker","Evans",
        "Edwards","Collins","Stewart","Morris","Murphy","Cook","Rogers","Morgan","Peterson","Cooper",
        "Reed","Bailey","Bell","Howard","Ward","Cox","Diaz","Richardson","Wood","Watson",
        "Brooks","Kelly","Sanders","Price","Bennett","Woods","Barnes","Ross","Henderson","Coleman",
        "Jenkins","Perry","Powell","Long","Patterson","Hughes","Flores","Washington","Butler","Simmons",
        "Foster","Gonzales","Bryant","Alexander","Russell","Griffin","Diaz","Hayes","Myers","Ford",
        "Hamilton","Graham","Sullivan","Wallace","Woods","Cole","West","Jordan","Owens","Reynolds",
        "Fisher","Ellis","Harrison","Gibson","McDonald","Cruz","Marshall","Ortiz","Gomez","Murray"
    };

    // --- Французский (латиница без диакритики) ---
    private static final String[] FR_MALE = {
        "Jean","Pierre","Louis","Henri","Charles","Francois","Antoine","Jacques","Philippe","Nicolas",
        "Etienne","Guillaume","Mathieu","Thierry","Olivier","Pascal","Renaud","Sebastien","Vincent","Xavier",
        "Yves","Emile","Armand","Bernard","Claude","Damien","Edouard","Fabien","Gaston","Hugues",
        "Ignace","Julien","Leon","Marcel","Noel","Octave","Patrice","Quentin","Remi","Serge",
        "Thibaut","Urbain","Valentin","Wandrille","Yannick","Aime","Blaise","Cyril","Didier","Eugene",
        "Fernand","Georges","Hubert","Irenee","Joel","Kevin","Lionel","Maurice","Norbert","Odon",
        "Prosper","Raoul","Sylvain","Tristan","Ulysse","Victor","Wilfried","Yvon","Zacharie","Adrien",
        "Baptiste","Cedric","Denis","Edmond","Frederic","Gabriel","Herve","Isaac","Jerome","Kleber",
        "Laurent","Michel","Narcisse","Alain","Albert","Alexandre","Alphonse","Amedee","Anatole","Anselme",
        "Auguste","Aurelien","Barthelemy","Benoit","Bruno","Casimir","Christian","Christophe","Clement","Constant",
        "Cyprien","Daniel","David","Edgard","Emmanuel","Eric","Ernest","Etienne","Evariste","Felix",
        "Florent","Francis","Franck","Gaetan","Gerard","Gervais","Gilles","Gregoire","Gustave","Hippolyte",
        "Honore","Hugo","Isidore","Jean-Baptiste","Jeremie","Joachim","Joseph","Jules","Lambert","Leopold",
        "Lucien","Ludovic","Marius","Martin","Mathurin","Maxime","Maximilien","Medard","Modeste","Nestor",
        "Norbert","Omer","Ovide","Pacome","Patrice","Paul","Philibert","Prosper","Raphael","Raymond",
        "Rene","Robert","Roch","Roland","Romeo","Samuel","Severin","Simon","Stephane","Sylvain",
        "Theodore","Thibault","Timothee","Toussaint","Valere","Valery","Vianney","Xavier","Yves","Zephirin"
    };

    private static final String[] FR_FEMALE = {
        "Marie","Jeanne","Francoise","Marguerite","Catherine","Anne","Louise","Elisabeth","Madeleine","Suzanne",
        "Charlotte","Claire","Julie","Cecile","Camille","Emilie","Helene","Isabelle","Josephine","Lucie",
        "Mathilde","Nathalie","Oceane","Pauline","Renee","Sophie","Therese","Ursule","Valentine","Yvonne",
        "Agnes","Beatrice","Colette","Denise","Estelle","Florence","Genevieve","Hortense","Irene","Jacqueline",
        "Lea","Manon","Ninon","Olympe","Penelope","Rosalie","Simone","Victorine","Zoe","Adele",
        "Blanche","Constance","Delphine","Eloise","Fanny","Gabrielle","Henriette","Ines","Juliette","Laure",
        "Marthe","Noemie","Odette","Perrine","Solange","Tiphaine","Veronique","Amandine","Brigitte","Coralie",
        "Dorothee","Emma","Frederique","Georgette","Helene","Ida","Justine","Karine","Lorraine","Maille",
        "Adeline","Agathe","Aimee","Albertine","Alexandrine","Alice","Amelie","Anais","Angelique","Antoinette",
        "Apolline","Ariane","Aurelie","Axelle","Barbara","Benedicte","Berenice","Berthe","Blaisine","Blandine",
        "Capucine","Caroline","Cassandre","Catherine","Cecilia","Celeste","Chantal","Charline","Christelle","Christiane",
        "Clarisse","Clemence","Clementine","Clotilde","Colombe","Cyprienne","Danielle","Diane","Dolorès","Edith",
        "Eleonore","Eliane","Elodie","Emmanuelle","Eugenie","Eulalie","Evelyne","Fabienne","Faustine","Felicie",
        "Fleur","Fortunee","France","Francine","Gabrielle","Gervaise","Ghislaine","Gisèle","Gwenaelle","Hortense",
        "Huguette","Isabeau","Jacquette","Jeannine","Josette","Judith","Katel","Laetitia","Laurence","Leonie",
        "Liane","Liliane","Lorraine","Lucette","Madeleine","Marcelle","Margaux","Marion","Martine","Micheline",
        "Mireille","Monique","Muriel","Nadine","Nicole","Noelle","Orianne","Pascale","Perlette","Philippine",
        "Priscille","Rebecca","Regine","Reine","Roseline","Sabine","Severine","Sidonie","Solene","Stephanie",
        "Sylvie","Tatiana","Theodora","Uranie","Valerie","Véronique","Victoire","Virginie","Viviane","Yvette"
    };

    private static final String[] FR_SURNAMES = {
        "Martin","Bernard","Dubois","Thomas","Robert","Richard","Petit","Durand","Leroy","Moreau",
        "Simon","Laurent","Lefebvre","Michel","Garcia","David","Bertrand","Roux","Vincent","Fournier",
        "Morel","Girard","Andre","Lefevre","Mercier","Dupont","Lambert","Bonnet","Francois","Martinez",
        "Legrand","Garnier","Faure","Rousseau","Blanc","Guerin","Muller","Henry","Roussel","Nicolas",
        "Perrin","Morin","Mathieu","Clement","Gauthier","Dumont","Lopez","Fontaine","Chevalier","Robin",
        "Masson","Sanchez","Gerard","Nguyen","Boyer","Denis","Lemaire","Duval","Joly","Gautier",
        "Roger","Roche","Roy","Noel","Meyer","Lucas","Meunier","Brun","Blanchard","Giraud",
        "Riviere","Brunet","Gaillard","Barbier","Arnaud","Martins","Rodriguez","Bertin","Lacroix","Vidal",
        "Cartier","Colin","Leclerc","Picard","Aubert","Benoit","Berger","Bertrand","Blanc","Boucher",
        "Bourgeois","Caron","Charpentier","Chevallier","Clement","Cordier","Cousin","Delaunay","Delorme","Descamps",
        "Dubois","Dufour","Dumas","Dupuis","Fleury","Fournier","Gautier","Giraud","Guyot","Henry",
        "Hernandez","Huet","Jacquet","Jean","Joly","Laine","Langlois","Laurent","Leclercq","Legrand",
        "Leleu","Lemoine","Leroux","Leveque","Lucas","Marchand","Marin","Marie","Menard","Mercier",
        "Meunier","Millet","Monnier","Moreau","Moulin","Muller","Nicolas","Noel","Olivier","Paris",
        "Pascal","Perrot","Petit","Philippe","Picard","Pierre","Poirier","Pons","Prevost","Renard",
        "Renaud","Rey","Reynaud","Ribeiro","Riviere","Robert","Robin","Roche","Roger","Rolland",
        "Rousseau","Roussel","Roy","Royer","Roux","Sanchez","Sauvage","Schmitt","Schneider","Simon",
        "Tessier","Thomas","Toussaint","Vasseur","Verdier","Vidal","Vincent","Weber","Yvon","Zimmermann"
    };

    // --- Немецкий (латиница без умлаутов) ---
    private static final String[] DE_MALE = {
        "Friedrich","Heinrich","Wilhelm","Karl","Otto","Hans","Wolfgang","Klaus","Dieter","Gunther",
        "Helmut","Werner","Kurt","Ernst","Rudolf","Hermann","Albert","Franz","Josef","Anton",
        "Stefan","Michael","Andreas","Thomas","Markus","Martin","Christian","Sebastian","Daniel","Tobias",
        "Matthias","Alexander","Florian","Maximilian","Lukas","Jonas","Felix","Paul","Leon","Elias",
        "Noah","Ben","Finn","Tim","Jan","Lars","Sven","Nils","Olaf","Rolf",
        "Arno","Axel","Bernd","Bert","Bruno","Clemens","Conrad","Detlef","Dietrich","Eberhard",
        "Eduard","Egon","Emil","Erhard","Erich","Erik","Erwin","Falk","Ferdinand","Frank",
        "Georg","Gerhard","Gernot","Gottfried","Gregor","Gunther","Gustav","Harald","Heiko","Heinz",
        "Henning","Herbert","Holger","Horst","Hubert","Ingo","Joachim","Johann","Johannes","Jorg",
        "Julius","Jurgen","Kai","Kaspar","Konrad","Leopold","Lorenz","Lothar","Ludwig","Manfred",
        "Marcel","Marco","Mario","Matthias","Max","Moritz","Nikolaus","Norbert","Otto","Patrick",
        "Peter","Philipp","Rainer","Ralf","Reinhard","Reinhold","Richard","Robert","Roland","Rudolf",
        "Rudiger","Sascha","Siegfried","Sigmund","Steffen","Thorsten","Til","Udo","Ulrich","Uwe",
        "Volker","Waldemar","Walter","Wendelin","Wenzel","Wilhelm","Winfried","Wolf","Wolfram","Xaver"
    };

    private static final String[] DE_FEMALE = {
        "Anna","Maria","Sophie","Emma","Mia","Hannah","Lena","Laura","Lea","Julia",
        "Katharina","Christina","Sabine","Petra","Monika","Ursula","Renate","Brigitte","Karin","Heike",
        "Angelika","Ingrid","Erika","Helga","Gisela","Birgit","Elke","Claudia","Susanne","Gabriele",
        "Martina","Silke","Yvonne","Nicole","Stefanie","Sandra","Andrea","Tanja","Jessica","Melanie",
        "Christin","Marie","Johanna","Frieda","Greta","Ida","Klara","Lotte","Marlene","Wilhelmine",
        "Adelheid","Agnes","Alexandra","Alice","Amalie","Anja","Anke","Anneliese","Antonia","Astrid",
        "Barbara","Beate","Beatrix","Bernadette","Bettina","Bianca","Brigitta","Carola","Caroline","Catharina",
        "Charlotte","Christa","Christiane","Cordula","Cornelia","Dagmar","Daniela","Diana","Dietlinde","Dora",
        "Dorothea","Edelgard","Edith","Eleonore","Elfriede","Elisabeth","Ellen","Elsbeth","Emilia","Emmi",
        "Erna","Eva","Evelin","Franziska","Frederike","Gerlinde","Gertrud","Gisela","Godelinde","Gudrun",
        "Gundula","Hannelore","Hedwig","Heide","Helene","Henriette","Herta","Hilde","Hildegard","Ines",
        "Inge","Irene","Irmgard","Isabel","Isolde","Jacqueline","Jana","Janine","Jasmin","Jeanette",
        "Jennifer","Johanna","Josefine","Judith","Jutta","Karla","Karolina","Kathrin","Katja","Kerstin",
        "Kirsten","Konstanze","Kornelia","Kristin","Kunigunde","Leonie","Liane","Lieselotte","Lilian","Linda",
        "Lisbeth","Lore","Lorena","Luise","Madlen","Magdalena","Maike","Manuela","Margarete","Margit",
        "Marianne","Marion","Marlies","Marta","Mechthild","Meike","Melitta","Mia","Michaela","Minna",
        "Miriam","Monika","Nadine","Natalie","Nina","Olga","Ottilie","Paula","Petra","Ramona",
        "Regina","Renate","Rosemarie","Roswitha","Ruth","Sabrina","Selma","Sieglinde","Sigrid","Silvia",
        "Simone","Sonja","Steffi","Susanne","Svenja","Sybille","Tabea","Thea","Theresa","Traute",
        "Trude","Ulrike","Ursula","Ute","Verena","Veronika","Viola","Virginia","Waltraud","Wilhelmine"
    };

    private static final String[] DE_SURNAMES = {
        "Muller","Schmidt","Schneider","Fischer","Weber","Meyer","Wagner","Becker","Schulz","Hoffmann",
        "Schafer","Koch","Bauer","Richter","Klein","Wolf","Schroder","Neumann","Schwarz","Zimmermann",
        "Braun","Kruger","Hofmann","Hartmann","Lange","Schmitt","Werner","Schmitz","Krause","Meier",
        "Lehmann","Schmid","Schulze","Maier","Kohler","Herrmann","Konig","Walter","Mayer","Huber",
        "Kaiser","Fuchs","Peters","Lang","Scholz","Moller","Weiss","Jung","Hahn","Vogel",
        "Friedrich","Keller","Gunther","Frank","Berger","Winkler","Roth","Beck","Lorenz","Baumann",
        "Franke","Albrecht","Schuster","Simon","Ludwig","Bohm","Winter","Kraus","Martin","Schumacher",
        "Kramer","Vogt","Stein","Jager","Otto","Sommer","Gross","Seidel","Heinrich","Brandt",
        "Haas","Schreiber","Graf","Schulte","Dietrich","Ziegler","Kuhn","Kuhn","Pohl","Engel",
        "Horn","Busch","Bergmann","Thomas","Voigt","Sauer","Arnold","Wolff","Pfeiffer","Wittmann",
        "Seifert","Schwarz","Zimmer","Behrens","Muller","Kuhnert","Klose","Franz","Frey","Hein",
        "Kraft","Lucas","Marx","Petersen","Riedel","Rudolph","Sander","Schwarz","Stark","Ullrich",
        "Wagner","Weber","Wegner","Weiss","Wendt","Werner","Wolf","Ziegler","Zimmermann","Zoller"
    };

    // --- Арабский (латиница) ---
    private static final String[] AR_MALE = {
        "Muhammad","Ahmad","Ali","Hassan","Hussein","Omar","Khalid","Yusuf","Ibrahim","Abdullah",
        "Saeed","Mustafa","Mahmoud","Yasser","Sami","Rami","Nabih","Karim","Fadi","Jamal",
        "Hamid","Rashid","Sulaiman","Talal","Majid","Nasser","Hani","Wail","Ziyad","Ammar",
        "Anwar","Ayman","Bashir","Bilal","Faisal","Fawzi","Ghassan","Hadi","Hamza","Harun",
        "Hisham","Idris","Imad","Ismail","Jabir","Jamil","Jihad","Kamal","Khalil","Latif",
        "Luay","Maher","Malik","Mansur","Marwan","Mazen","Mubarak","Munir","Musa","Nabil",
        "Nadim","Naim","Nizar","Osman","Qasim","Rafiq","Raghib","Ramzi","Riad","Rida",
        "Sabri","Sadik","Salah","Salem","Samir","Shadi","Sharif","Tariq","Tawfiq","Thabit",
        "Wahid","Waleed","Yahya","Yaqoub","Yasin","Younis","Zaid","Zakariya","Zuhair","Adel",
        "Amir","Asad","Ayoub","Aziz","Fadel","Fahd","Fathi","Habib","Hakim","Hatem"
    };

    private static final String[] AR_FEMALE = {
        "Fatima","Aisha","Maryam","Zainab","Khadija","Sarah","Laila","Nur","Hind","Rana",
        "Dina","Yasmin","Salma","Amal","Jannah","Rawan","Reem","Shahd","Lina","Malak",
        "Mai","Najla","Haya","Wiam","Yusra","Aya","Bushra","Tahani","Jamila","Hanan",
        "Abeer","Afaf","Ahlam","Alia","Amira","Asma","Azzah","Badria","Basma","Dalal",
        "Dana","Duaa","Fadwa","Farah","Fatma","Ghada","Ghalia","Habiba","Hafsa","Hala",
        "Halima","Ibtisam","Ilham","Inas","Iman","Israa","Jawaher","Karima","Kawthar","Lamia",
        "Latifa","Leila","Lubna","Madiha","Majida","Maha","Manal","Marwa","Muna","Nadia",
        "Nadira","Nahla","Nawal","Nihal","Nour","Rabab","Rania","Rawda","Ruqayya","Sabah",
        "Sabreen","Safiya","Samira","Sawsan","Shadia","Shaima","Siham","Suha","Sumaya","Thuraya",
        "Wafa","Warda","Yara","Zahra","Zakiya","Zeinab","Zubaida","Amina","Hafsa","Ruqayya"
    };

    private static final String[] AR_SURNAMES = {
        "Al-Hassan","Al-Hussein","Al-Ali","Al-Ahmad","Al-Muhammad","Al-Omar","Al-Khalid","Al-Yusuf",
        "Al-Ibrahim","Al-Saeed","Al-Mustafa","Al-Mahmoud","Al-Yasser","Al-Sami","Al-Rami","Al-Nabih",
        "Al-Karim","Al-Fadi","Al-Jamal","Al-Hamid","Al-Rashid","Al-Sulaiman","Al-Talal","Al-Majid",
        "Al-Nasser","Al-Hani","Al-Wail","Al-Ziyad","Al-Salam","Al-Fuad","Al-Amin","Al-Aziz",
        "Al-Bashir","Al-Faisal","Al-Ghani","Al-Hakim","Al-Jabbar","Al-Kader","Al-Latif","Al-Malik",
        "Al-Nur","Al-Qadir","Al-Rahim","Al-Rahman","Al-Samad","Al-Tawwab","Al-Wahid","Al-Wadud",
        "Al-Zahir","Al-Baqi","Al-Hadi","Al-Qawi","Al-Matin","Al-Wali","Al-Hamid","Al-Majid",
        "Al-Haqq","Al-Mubin","Al-Hafiz","Al-Hasib","Al-Jalil","Al-Karim","Al-Raqib","Al-Mujib",
        "Al-Wasi","Al-Hakim","Al-Wadud","Al-Majid","Al-Ba'ith","Al-Shahid","Al-Haqq","Al-Wakil",
        "Al-Qawi","Al-Matin","Al-Wali","Al-Hamid","Al-Muhsi","Al-Mubdi","Al-Mu'id","Al-Muhyi"
    };

    // --- Китайский (пиньинь, латиница) ---
    private static final String[] ZH_MALE = {
        "Wei","Qiang","Jun","Lei","Yang","Yong","Yan","Jie","Juan","Tao",
        "Ming","Chao","Xiuying","Xia","Ping","Gang","Guiying","Fang","Peng","Hua",
        "Hong","Yulan","Fei","Jianhua","Hui","Li","Ning","Wen","Bin","Feng",
        "An","Bo","Cheng","Da","Dong","Enlai","Fu","Guo","Hao","Hong",
        "Jian","Jin","Kai","Kang","Kun","Liang","Lin","Long","Min","Nan",
        "Peng","Qi","Qing","Rong","Shan","Sheng","Shi","Song","Tao","Tian",
        "Wang","Wu","Xiang","Xiao","Xin","Xing","Xiong","Xuan","Yan","Yi",
        "Yin","Yong","You","Yu","Yuan","Yue","Yun","Ze","Zhang","Zhao",
        "Zhen","Zheng","Zhi","Zhong","Zhou","Zhu","Zi","Zong","Zu","Zun",
        "Bing","Cai","Chun","Cong","Dai","Fan","Fang","Gao","Gong","Guang",
        "He","Hu","Huang","Jia","Jiang","Jing","Jun","Le","Liu","Lu"
    };

    private static final String[] ZH_FEMALE = {
        "Xiuying","Xia","Ping","Gang","Guiying","Fang","Peng","Hua","Hong","Yulan",
        "Fei","Jianhua","Hui","Li","Ning","Wen","Bin","Feng","Li","Min",
        "Jing","Yan","Na","Jie","Mei","Ling","Ping","Hongmei","Xiulan","Guifang",
        "Ai","An","Bao","Bi","Cai","Chan","Chang","Chen","Cui","Dan",
        "Dong","E","Fan","Fang","Fen","Feng","Fu","Gai","Gao","Ge",
        "Gui","Guo","Hai","Han","Hao","He","Hong","Hua","Hui","Ji",
        "Jia","Jian","Jiao","Jin","Jing","Juan","Jun","Kai","Lan","Lei",
        "Li","Lin","Ling","Liu","Lu","Lian","Man","Mei","Min","Ming",
        "Na","Nan","Ning","Ni","Ping","Qi","Qian","Qing","Qiu","Rong",
        "Ru","Shan","Shao","Shen","Shi","Shu","Si","Song","Su","Sui",
        "Tian","Ting","Tong","Wan","Wang","Wei","Wen","Wu","Xi","Xia",
        "Xian","Xiang","Xiao","Xin","Xing","Xiu","Xuan","Xue","Ya","Yan",
        "Yang","Yao","Yi","Yin","Ying","Yong","You","Yu","Yuan","Yue",
        "Yun","Zhen","Zheng","Zhi","Zhong","Zhu","Zi","Zong","Zui","Zun"
    };

    private static final String[] ZH_SURNAMES = {
        "Wang","Li","Zhang","Liu","Chen","Yang","Huang","Zhao","Zhou","Wu",
        "Xu","Sun","Ma","Zhu","Hu","Guo","He","Gao","Lin","Luo",
        "Zheng","Liang","Xie","Song","Tang","Xu","Han","Feng","Deng","Cao",
        "Peng","Zeng","Xiao","Tian","Dong","Pan","Yuan","Cai","Jiang","Yu",
        "Du","Ye","Cheng","Su","Wei","Lu","Ding","Ren","Shen","Yao",
        "Lu","Jiang","Cui","Zhong","Tan","Lu","Wang","Fan","Jin","Shi",
        "Liao","Jia","Xia","Fu","Fang","Zou","Xiong","Bai","Meng","Qin",
        "Qiu","Hou","Jiang","Yin","Xue","Yan","Duan","Lei","Qian","Tang",
        "Gong","Shao","Wan","Qin","Yan","Long","Tao","He","Gu","Mao",
        "Hao","Yan","Gong","Shao","Wan","Qin","Yan","Long","Tao","He"
    };

    // --- Хинди (латиница) ---
    private static final String[] HI_MALE = {
        "Raj","Amit","Suresh","Ramesh","Vijay","Anil","Sunil","Mohan","Rahul","Arjun",
        "Krishna","Ram","Shiv","Hari","Gopal","Vishnu","Prakash","Deepak","Sanjay","Ajay",
        "Vinod","Ashok","Rakesh","Mukesh","Dinesh","Mahesh","Yogesh","Rajesh","Naresh","Jayesh",
        "Aakash","Abhay","Aditya","Ajit","Akash","Alok","Amar","Anand","Aniket","Ankit",
        "Anuj","Arun","Ashish","Avinash","Balram","Bhavesh","Bhushan","Chetan","Darshan","Dev",
        "Devanand","Dhruv","Dilip","Ganesh","Gaurav","Girish","Gopal","Govind","Harish","Hemant",
        "Hitesh","Ishwar","Jagdish","Jai","Jitendra","Kailash","Kamal","Karan","Kishore","Krishan",
        "Lakshman","Lalit","Madan","Mahendra","Manoj","Mayank","Mihir","Mukul","Nakul","Nandan",
        "Narayan","Navin","Neeraj","Nikhil","Nirav","Om","Pankaj","Paras","Paresh","Parth",
        "Pradeep","Pranav","Prashant","Pratap","Prem","Punit","Raghav","Rajan","Rajanikant","Rakesh",
        "Ramesh","Ranjan","Ravi","Rohit","Rudra","Sachin","Sagar","Sahil","Sandeep","Sanjeev",
        "Santosh","Sarthak","Satish","Saurabh","Shankar","Shashank","Shyam","Sudhir","Suresh","Tarun",
        "Tejas","Uday","Umesh","Vaibhav","Vasant","Ved","Vijay","Vikas","Vinay","Vishal",
        "Vivek","Yash","Yashwant","Yogendra","Yuvraj"
    };

    private static final String[] HI_FEMALE = {
        "Sita","Gita","Radha","Lakshmi","Saraswati","Durga","Parvati","Kali","Savitri","Meera",
        "Anjali","Priya","Sunita","Anita","Kavita","Nisha","Reena","Sheela","Usha","Veena",
        "Kamla","Shanti","Sarita","Suman","Manju","Pooja","Deepa","Rekha","Seema","Mamta",
        "Aarti","Aditi","Aishwarya","Akshara","Alka","Amrita","Ananya","Anjali","Ankita","Anu",
        "Anushka","Archana","Aruna","Asha","Ashwini","Avani","Ayesha","Bharti","Bhavna","Bina",
        "Chandra","Charu","Chetna","Damini","Darshana","Deepika","Devika","Diksha","Divya","Ekta",
        "Gauri","Gayatri","Geeta","Gitanjali","Hema","Himani","Indira","Isha","Jaya","Jyoti",
        "Kajal","Kalpana","Kamini","Karishma","Kavya","Kiran","Komal","Kritika","Kusum","Lata",
        "Lavanya","Leela","Lila","Madhu","Madhuri","Malini","Maya","Meena","Megha","Mohini",
        "Mridula","Mukta","Nandini","Namrata","Neelam","Neha","Nidhi","Nirmala","Nisha","Nutan",
        "Padma","Pallavi","Parul","Pooja","Poonam","Prachi","Pratibha","Preeti","Priyanka","Rachana",
        "Radhika","Ragini","Rajni","Rakhi","Rama","Rani","Rashmi","Rati","Renu","Richa",
        "Ritu","Riya","Roopa","Roshni","Rupali","Sadhana","Sakshi","Sandhya","Sangeeta","Sanjana",
        "Sarita","Seema","Shalini","Shanta","Sharda","Shikha","Shilpa","Shobha","Shraddha","Shreya",
        "Shruti","Smita","Sneha","Sonali","Sonia","Sudha","Sujata","Sukanya","Sumitra","Sunanda",
        "Sunita","Supriya","Sushma","Swati","Tanvi","Tara","Tejaswini","Trisha","Uma","Urvashi",
        "Vandana","Vanita","Varsha","Vasundhara","Vidya","Vinita","Vrinda","Yamini","Yashoda","Zara"
    };

    private static final String[] HI_SURNAMES = {
        "Sharma","Verma","Gupta","Agrawal","Jain","Singh","Kumar","Yadav","Mishra","Pandey",
        "Tiwari","Dubey","Shukla","Chaudhary","Rao","Nair","Menon","Reddy","Patel","Desai",
        "Joshi","Bhat","Iyengar","Iyer","Namboodiri","Pillai","Gaur","Sen","Das","Basu",
        "Chakraborty","Banerjee","Mukherjee","Chatterjee","Ganguly","Bose","Roy","Dutta","Saha","Sinha",
        "Kapoor","Khanna","Malhotra","Chopra","Mehta","Shah","Patil","Deshmukh","Kulkarni","Joshi",
        "Naik","Shetty","Hegde","Kamat","Prabhu","Bhatt","Trivedi","Dwivedi","Chaturvedi","Upadhyay",
        "Acharya","Shastri","Pandit","Vaidya","Siddiqui","Khan","Ansari","Qureshi","Sheikh","Syed",
        "Mirza","Baig","Pathan","Shaikh","Memon","Surti","Khoja","Bohra","Khatri","Arora",
        "Bhatia","Sethi","Anand","Bajaj","Gulati","Khurana","Madan","Nagpal","Oberoi","Talwar",
        "Vohra","Wadhwa","Ahuja","Batra","Chadha","Dhingra","Gambhir","Kohli","Luthra","Malik"
    };

    // --- Испанский (латиница без диакритики) ---
    private static final String[] ES_MALE = {
        "Juan","Carlos","Jose","Luis","Miguel","Antonio","Francisco","Manuel","Pedro","Pablo",
        "Javier","Sergio","Diego","Alejandro","Fernando","Ricardo","Alberto","Jorge","Raul","Eduardo",
        "Rafael","Enrique","Andres","Hector","Oscar","Ruben","Victor","Gonzalo","Ivan","Adrian",
        "Agustin","Alfonso","Alfredo","Alvaro","Arturo","Benito","Bernardo","Bruno","Cesar","Cristian",
        "Cristobal","Daniel","David","Domingo","Edgar","Emilio","Ernesto","Esteban","Eugenio","Federico",
        "Felipe","Felix","Gabriel","Gerardo","German","Gilberto","Gustavo","Hugo","Ignacio","Ismael",
        "Jacobo","Jaime","Jesus","Joaquin","Julio","Leandro","Leonardo","Lorenzo","Lucas","Marcos",
        "Mariano","Mario","Martin","Mateo","Matias","Mauricio","Maximo","Nicolas","Octavio","Pascual",
        "Patricio","Ramon","Ramiro","Reynaldo","Roberto","Rodrigo","Rogelio","Rolando","Salvador","Samuel",
        "Santiago","Saul","Sebastian","Silvestre","Simon","Tomas","Valentin","Vicente","Xavier","Zacarias"
    };

    private static final String[] ES_FEMALE = {
        "Maria","Carmen","Ana","Isabel","Laura","Marta","Lucia","Sara","Elena","Paula",
        "Sofia","Rosa","Pilar","Teresa","Cristina","Beatriz","Silvia","Patricia","Monica","Nuria",
        "Rocio","Alba","Andrea","Irene","Natalia","Eva","Julia","Claudia","Daniela","Adriana",
        "Alicia","Amparo","Angela","Antonia","Aurora","Beatriz","Belen","Blanca","Carla","Carolina",
        "Catalina","Cecilia","Clara","Concepcion","Consuelo","Dolores","Elisa","Elvira","Emilia","Encarnacion",
        "Esperanza","Estefania","Esther","Eugenia","Fatima","Gloria","Guadalupe","Ines","Inmaculada","Irene",
        "Josefa","Juana","Judith","Leticia","Lidia","Lorena","Lourdes","Luz","Magdalena","Manuela",
        "Marina","Marisol","Mercedes","Micaela","Miriam","Montserrat","Nerea","Noelia","Olga","Paloma",
        "Raquel","Rebeca","Rosalia","Rosario","Ruth","Sabina","Salome","Sandra","Sara","Soledad",
        "Susana","Teresa","Valentina","Veronica","Victoria","Virginia","Viviana","Ximena","Yolanda","Zoe"
    };

    private static final String[] ES_SURNAMES = {
        "Garcia","Rodriguez","Martinez","Hernandez","Lopez","Gonzalez","Perez","Sanchez","Ramirez","Torres",
        "Flores","Rivera","Gomez","Diaz","Cruz","Morales","Ortiz","Gutierrez","Chavez","Ramos",
        "Ruiz","Alvarez","Mendoza","Vargas","Castillo","Jimenez","Moreno","Romero","Herrera","Medina",
        "Aguilar","Alonso","Andrade","Arias","Bautista","Bermudez","Blanco","Bravo","Cabrera","Calderon",
        "Campos","Cardenas","Carrillo","Casanova","Castaneda","Castro","Cervantes","Cordero","Corona","Cortes",
        "Delgado","Dominguez","Duran","Escobar","Espinoza","Estrada","Fernandez","Figueroa","Fuentes","Gallego",
        "Galvan","Garrido","Gil","Guerrero","Guzman","Ibarra","Iglesias","Juarez","Lara","Leon",
        "Lozano","Luna","Machado","Maldonado","Marin","Marquez","Mata","Mejia","Mendez","Miranda",
        "Molina","Montoya","Munoz","Navarro","Nunez","Ochoa","Padilla","Palacios","Pena","Peralta",
        "Pineda","Ponce","Quintero","Reyes","Rios","Rivas","Robles","Rojas","Rosales","Salazar"
    };

    // --- Бенгальский (латиница) ---
    private static final String[] BN_MALE = {
        "Raj","Amit","Suresh","Ramesh","Vijay","Anil","Sunil","Mohan","Rahul","Arjun",
        "Krishna","Ram","Shiv","Hari","Gopal","Vishnu","Prakash","Deepak","Sanjay","Ajay",
        "Vinod","Ashok","Rakesh","Mukesh","Dinesh","Mahesh","Yogesh","Rajesh","Naresh","Jayesh",
        "Abhijit","Abhik","Aditya","Ajoy","Akash","Amitava","Ananda","Anirban","Anup","Arindam",
        "Arup","Ashim","Ayan","Balaram","Barun","Bhabesh","Bhaskar","Bibhuti","Bikash","Bimal",
        "Biren","Biswajit","Buddhadeb","Chandan","Debabrata","Debashis","Debjit","Deep","Dhiren","Dilip",
        "Dulal","Ganesh","Gautam","Gobinda","Gour","Haripada","Himadri","Indrajit","Jayanta","Jiban",
        "Kalyan","Kamal","Kanai","Kartik","Kaushik","Keshab","Krishna","Lakshman","Madan","Manoj",
        "Manas","Mrinal","Nanda","Narayan","Nikhil","Niranjan","Nirmal","Palash","Pankaj","Partha",
        "Pradip","Prasanta","Prasenjit","Pratap","Purnendu","Rabi","Raghunath","Rajat","Rajib","Rakesh",
        "Ranjan","Ratan","Rathin","Ratul","Rupak","Samar","Sanat","Sandip","Sanjib","Santosh",
        "Satyajit","Shankar","Shyamal","Sisir","Somen","Sourav","Subhash","Subir","Sudarshan","Sudhir",
        "Sujit","Sukanta","Sukumar","Sumanta","Sunil","Sushil","Swapan","Tapan","Tapas","Tarun",
        "Ujjal","Uttam","Vijay","Vikas","Vishal","Yash"
    };

    private static final String[] BN_FEMALE = {
        "Sita","Gita","Radha","Lakshmi","Saraswati","Durga","Parvati","Kali","Savitri","Meera",
        "Anjali","Priya","Sunita","Anita","Kavita","Nisha","Reena","Sheela","Usha","Veena",
        "Kamla","Shanti","Sarita","Suman","Manju","Pooja","Deepa","Rekha","Seema","Mamta",
        "Abha","Aditi","Aishwarya","Amita","Ananya","Anima","Anjali","Anuradha","Aparna","Aparajita",
        "Archana","Arpita","Asha","Ashima","Avanti","Bandana","Barnali","Basabi","Bela","Bharati",
        "Bhaswati","Bina","Bishakha","Chandana","Chandni","Charulata","Chetana","Chitra","Damayanti","Debjani",
        "Deepa","Dipti","Doyel","Gauri","Gayatri","Geeta","Gita","Haimanti","Hena","Indrani",
        "Ipsita","Ishita","Jaba","Jaya","Jayanti","Jhuma","Joya","Kalpana","Kamala","Karabi",
        "Karuna","Kavita","Keya","Krishna","Kusum","Lata","Leela","Lipica","Madhabi","Madhumita",
        "Mahua","Malati","Malini","Mamata","Manasi","Mandira","Manidipa","Maya","Meenakshi","Megha",
        "Mira","Mitali","Mohini","Mou","Mousumi","Mridula","Mukta","Nandita","Namita","Neela",
        "Nibedita","Nilanjana","Nirmala","Nisha","Nita","Padma","Papiya","Parul","Piyali","Poonam",
        "Pratima","Preeti","Priyanka","Purna","Pushpa","Rachana","Radha","Raima","Rakhi","Rama",
        "Rani","Rashmi","Ratna","Rekha","Renu","Richa","Rina","Rituparna","Riya","Roopa",
        "Roshni","Ruma","Rupa","Sabita","Sadhana","Sagarika","Sahana","Sandhya","Sangita","Sanjukta",
        "Saraswati","Sarita","Sarmila","Sathi","Seema","Shampa","Sharmila","Shikha","Shilpa","Shobha",
        "Shreya","Shruti","Shyamali","Sipra","Smita","Sneha","Sohini","Soma","Sonali","Sonia",
        "Sudha","Sujata","Sukla","Sumitra","Sunanda","Sunita","Suparna","Supriya","Sushma","Swati",
        "Tanushree","Tara","Tulika","Uma","Urvashi","Uttara","Vandana","Varsha","Vidya","Yamini"
    };

    private static final String[] BN_SURNAMES = {
        "Sharma","Verma","Gupta","Agrawal","Jain","Singh","Kumar","Yadav","Mishra","Pandey",
        "Tiwari","Dubey","Shukla","Chaudhury","Rao","Nair","Menon","Reddy","Patel","Desai",
        "Joshi","Bhat","Ayangar","Iyer","Pillai","Gaur","Sen","Das","Basu","Chakraborty",
        "Banerjee","Mukherjee","Chatterjee","Ganguly","Bose","Roy","Dutta","Saha","Sinha","Bhattacharya",
        "Adhikari","Bagchi","Bakshi","Bandyopadhyay","Barman","Bhadra","Bhunia","Biswas","Chanda","Chandra",
        "Dasgupta","De","Deb","Dey","Dhar","Ghosh","Ghoshal","Halder","Hazra","Jana",
        "Kabiraj","Kanungo","Kar","Karmakar","Kundu","Laha","Maji","Mal","Mandal","Manna",
        "Mitra","Modak","Mondal","Nag","Nandi","Pal","Palit","Panja","Pramanik","Purkayastha",
        "Raha","Rakshit","Ray","Sadhukhan","Samanta","Sanyal","Sarkar","Sen","Sengupta","Sil",
        "Sinha","Sur","Talukdar","Thakur","Tripathi","Trivedi","Vaidya","Varma","Yadav","Zamindar"
    };

    // --- Португальский (латиница без диакритики) ---
    private static final String[] PT_MALE = {
        "Joao","Jose","Antonio","Francisco","Carlos","Paulo","Pedro","Lucas","Luiz","Marcos",
        "Gabriel","Rafael","Daniel","Marcelo","Bruno","Eduardo","Felipe","Rodrigo","Manoel","Mateus",
        "Andre","Fernando","Ricardo","Alberto","Diego","Thiago","Vinicius","Leonardo","Guilherme","Henrique",
        "Alexandre","Alfredo","Amauri","Anderson","Arthur","Augusto","Benedito","Benjamin","Bernardo","Caio",
        "Cesar","Claudio","Cristiano","Davi","Denis","Domingos","Douglas","Edson","Elias","Emerson",
        "Enzo","Eric","Ernesto","Fabio","Fabiano","Fabricio","Felix","Flavio","Franklin","Geraldo",
        "Gilberto","Giovani","Glauco","Gustavo","Heitor","Hugo","Igor","Ivan","Jair","Joaquim",
        "Jonas","Jorge","Julio","Junior","Leandro","Lucas","Luciano","Luigi","Manoel","Marcio",
        "Mario","Mateus","Mauricio","Miguel","Murilo","Nelson","Nicolas","Otavio","Paulo","Ramon",
        "Raul","Renato","Roberto","Robson","Rodolfo","Rogerio","Ronaldo","Samuel","Sebastiao","Sergio",
        "Silvio","Simao","Tadeu","Thales","Tomas","Valter","Vicente","Victor","Wagner","Wesley",
        "William","Yuri","Zacarias","Adriano","Alan","Aldo","Alessandro","Alex","Almir","Amadeu",
        "Anibal","Aparecido","Ariel","Arnaldo","Baltazar","Bento","Breno","Cassio","Caua","Celso",
        "Ciro","Cristobal","Damiao","Danilo","Dario","Davi","Dionisio","Donizete","Edimilson","Emanuel",
        "Estevao","Eugenio","Everton","Ezequiel","Fabio","Fausto","Firmino","Floriano","Franco","Frederico",
        "Genivaldo","Gerson","Gilmar","Giovane","Hamilton","Haroldo","Heber","Heraldo","Humberto","Ibrahim",
        "Inacio","Isaac","Isaias","Israel","Jadson","Jaime","Jairo","Janio","Jeferson","Jeremias"
    };

    private static final String[] PT_FEMALE = {
        "Maria","Ana","Francisca","Antonia","Adriana","Juliana","Marcia","Fernanda","Patricia","Aline",
        "Camila","Amanda","Bruna","Jessica","Leticia","Julia","Luciana","Vanessa","Mariana","Gabriela",
        "Larissa","Beatriz","Carolina","Natalia","Renata","Cristina","Debora","Priscila","Tatiane","Rafaela",
        "Alice","Amelia","Angelica","Aparecida","Ariane","Aurora","Barbara","Benedita","Bianca","Brenda",
        "Carina","Carla","Carlota","Cassia","Catarina","Cecilia","Celeste","Clara","Clarice","Claudia",
        "Cristiane","Dalva","Daniela","Denise","Diana","Dulce","Edilene","Eduarda","Elaine","Eliana",
        "Elisangela","Elisa","Elizabete","Eloisa","Elvira","Emilia","Erica","Estela","Ester","Eunice",
        "Fabiana","Fatima","Flavia","Franciele","Gabriele","Geovana","Gilda","Giovana","Gisela","Gisele",
        "Graziele","Helena","Heloisa","Iara","Iasmin","Ines","Iracema","Irene","Isabel","Isabela",
        "Isadora","Ivone","Jandira","Janice","Jaqueline","Joana","Joelma","Josefa","Jucilene","Karine",
        "Katia","Kelly","Larissa","Laura","Lavinia","Leila","Leticia","Lidiane","Ligia","Lilian",
        "Livia","Lorena","Luana","Lucia","Luciana","Luiza","Luzia","Madalena","Maiara","Maithe",
        "Manoela","Marcela","Margarida","Marlene","Marta","Mayara","Melissa","Michele","Milena","Monica",
        "Nadia","Naiara","Nara","Neide","Nilza","Noemi","Norma","Olivia","Paloma","Patricia",
        "Paula","Paulina","Priscila","Rachel","Rafaela","Raquel","Rebeca","Regina","Renata","Rita",
        "Roberta","Rosa","Rosana","Rosangela","Ruth","Sabrina","Samara","Sandra","Sara","Sheila",
        "Simone","Sofia","Solange","Sonia","Stefani","Sueli","Tais","Talita","Tania","Tatiana",
        "Teresa","Thais","Thalita","Valentina","Valeria","Vanessa","Vera","Vitoria","Viviane","Yara",
        "Zelia","Zilda","Zoe","Adrieli","Alessandra","Alexandra","Andreia","Ariadne","Beatris","Cintia"
    };

    private static final String[] PT_SURNAMES = {
        "Silva","Santos","Oliveira","Souza","Rodrigues","Ferreira","Alves","Pereira","Lima","Gomes",
        "Costa","Ribeiro","Martins","Carvalho","Almeida","Lopes","Soares","Fernandes","Vieira","Barbosa",
        "Rocha","Dias","Nascimento","Andrade","Moreira","Nunes","Marques","Machado","Mendes","Freitas",
        "Cardoso","Correia","Cavalcanti","Monteiro","Araujo","Cunha","Pinto","Batista","Teixeira","Miranda",
        "Campos","Castro","Duarte","Fonseca","Guimaraes","Henriques","Jesus","Leite","Macedo","Maia",
        "Matos","Melo","Moraes","Neves","Nogueira","Oliveira","Paiva","Pacheco","Peixoto","Pires",
        "Queiroz","Ramos","Reis","Resende","Sales","Sampaio","Sanches","Saraiva","Siqueira","Tavares",
        "Torres","Valente","Vasconcelos","Vaz","Verissimo","Viana","Vilela","Xavier","Zanetti","Zanini",
        "Abreu","Aguiar","Albuquerque","Alencar","Amaral","Amorim","Antunes","Azevedo","Bandeira","Barros",
        "Bastos","Bezerra","Bittencourt","Braga","Brandao","Brito","Bueno","Caetano","Caldeira","Camargo",
        "Carneiro","Carrara","Cesar","Chaves","Coelho","Conceicao","Cordeiro","Coutinho","Cruz","Damasceno",
        "Dantas","Delgado","Diniz","Domingues","Donato","Esteves","Fagundes","Farias","Feliciano","Fioravanti",
        "Furtado","Garcia","Godoy","Goncalves","Goulart","Guedes","Guidi","Horta","Ibrahim","Jacob",
        "Jardim","Juliao","Lacerda","Laurindo","Lavor","Lemos","Lins","Lobato","Lucena","Magalhaes",
        "Mancini","Manso","Marinho","Mendonca","Mesquita","Mota","Muniz","Nakamura","Nobre","Oliveira"
    };

    // --- Персидский (латиница) ---
    private static final String[] FA_MALE = {
        "Ali","Muhammad","Hassan","Hussein","Reza","Mehdi","Amir","Saeed","Majid","Kazem",
        "Javad","Ahmad","Mahmoud","Asghar","Akbar","Bahram","Dariush","Farhad","Kourosh","Babak",
        "Siavash","Arash","Pouya","Nima","Saman","Kamran","Fereydoun","Rostam","Esfandiar","Ardeshir",
        "Abbas","Abdollah","Adel","Afshin","Ahmadreza","Akbar","Alireza","Amirhossein","Anoush","Aryan",
        "Bahman","Behrouz","Bijan","Borzu","Cyrus","Ehsan","Ebrahim","Emad","Farid","Farrokh",
        "Farshad","Fazel","Fereidoon","Gholam","Hadi","Hamid","Hamidreza","Hasan","Heshmat","Hooman",
        "Hossein","Iman","Jamshid","Kambiz","Kamran","Kaveh","Keyvan","Khosrow","Mahdi","Mahmoud",
        "Manouchehr","Masoud","Mehrdad","Milad","Mohammad","Mohsen","Mostafa","Morteza","Mojtaba","Nader",
        "Navid","Nasser","Omid","Parviz","Payam","Pedram","Peyman","Pourya","Rahim","Ramin",
        "Reza","Rostam","Saeid","Saman","Shahram","Shahrokh","Siamak","Sohrab","Soroush","Tahmuras",
        "Vahid","Vahidreza","Yahya","Yashar","Yousef","Zahak","Zia","Afshin","Arya","Behzad",
        "Dara","Eskandar","Faramarz","Farzad","Giv","Goudarz","Hormoz","Iraj","Jamshid","Kaveh",
        "Khashayar","Maziar","Mehrzad","Nader","Parham","Parvaz","Rostam","Shahin","Sohrab","Touraj",
        "Vahid","Yazdan","Zartosht","Arman","Bahador","Dariush","Esfandiar","Fariborz","Gudarz","Hooshang",
        "Jam","Kianoush","Manouchehr","Nosrat","Parviz","Rakhshan","Sohrab","Tahmasb","Vali","Zaman"
    };

    private static final String[] FA_FEMALE = {
        "Fatemeh","Zahra","Maryam","Narges","Sara","Elham","Mina","Lila","Shirin","Parisa",
        "Nazanin","Bahareh","Samira","Nastaran","Rana","Mahsa","Negar","Hediyeh","Sohr","Yasaman",
        "Niloufar","Shabnam","Golnaz","Anahita","Roudabeh","Tahmineh","Farangis","Gordafarid","Katayoun","Pouran",
        "Afarin","Afrouz","Akram","Afsaneh","Aghdas","Ahoo","Akhtar","Alaleh","Anahid","Arezoo",
        "Armaghan","Asal","Ashraf","Azadeh","Azam","Azita","Banafsheh","Behnaz","Bita","Delaram",
        "Dorna","Elaheh","Elnaz","Faranak","Fariba","Farideh","Farnaz","Fereshteh","Forough","Gelareh",
        "Ghazal","Golnar","Golnoush","Haleh","Hanieh","Hasti","Hedieh","Homeira","Hoora","Hoorieh",
        "Jaleh","Kamand","Kiana","Kimia","Kobra","Ladan","Laleh","Laya","Leila","Mahboubeh",
        "Mahtab","Mahya","Maliheh","Mana","Mansoureh","Marzieh","Maryam","Masoumeh","Mehri","Mitra",
        "Mobina","Mojgan","Mozhgan","Nahal","Narges","Nasim","Neda","Negin","Niloofar","Niousha",
        "Parastoo","Pardis","Pareesa","Parinaz","Parisa","Parvaneh","Pegah","Raha","Rana","Reyhaneh",
        "Roksana","Roya","Sadaf","Sahar","Sanaz","Sara","Sarvenaz","Sepideh","Setareh","Shadi",
        "Shahla","Shahrzad","Shirin","Shiva","Sholeh","Sima","Sogand","Soheila","Somayeh","Soraya",
        "Sudabeh","Sussan","Tahmineh","Tara","Taraneh","Tina","Vida","Yasaman","Yekta","Zahra",
        "Zohreh","Ziba","Zohra","Afsaneh","Anahita","Banu","Delkash","Elaheh","Forough","Golnaz"
    };

    private static final String[] FA_SURNAMES = {
        "Mohammadi","Hosseini","Ahmadi","Rezaei","Mousavi","Karimi","Jafari","Sadeghi","Hashemi","Nouri",
        "Rahimi","Heydari","Moradi","Akbari","Yousefi","Sharifi","Kazemi","Soltani","Zareh","Bahrami",
        "Farhadi","Najafi","Abbasi","Amini","Ghorbani","Alizadeh","Rahmani","Mahdavi","Taheri","Kamali",
        "Sadegh","Ebrahimi","Salehi","Rostami","Bagheri","Khani","Aghaei","Behzadi","Jafarzadeh","Khalili",
        "Mansouri","Nazari","Pourmohammadi","Rasouli","Saeedi","Shahbazi","Sheikh","Talebi","Vaziri","Zahedi",
        "Adib","Afshar","Aghajani","Ansari","Asadi","Azizi","Babaei","Bahadori","Bakhshi","Danesh",
        "Dehghani","Eskandari","Fallah","Fazeli","Forouzan","Ghaderi","Ghanbari","Ghasemi","Golestani","Hamidi",
        "Hemmati","Hoda","Hojjati","Jahanbakhsh","Jalali","Jamali","Kamali","Kargar","Kazemzadeh","Keshavarz",
        "Khodadadi","Khoshnevis","Latifi","Mahmoodi","Mehrabi","Mirsadeghi","Moghadam","Montazeri","Motahari","Naderi",
        "Namazi","Niknam","Norouzi","Parvizi","Pourhosseini","Rafiei","Rahmanian","Rajabi","Ranjbar","Rezaei",
        "Rostami","Sadeghian","Safari","Sajjadi","Salari","Samadi","Sedighi","Shafiei","Shahidi","Sharif",
        "Soleimani","Tabatabai","Tahmasebi","Tavakoli","Tehrani","Vaezi","Yazdani","Zamani","Zarei","Zolfaghari"
    };

    // --- Греческий (латиница) ---
    private static final String[] EL_MALE = {
        "Giorgos","Giannis","Kostas","Dimitris","Nikos","Panagiotis","Vasilis","Christos","Antonis","Michalis",
        "Thanasis","Spyros","Petros","Alexandros","Stelios","Markos","Lefteris","Argyris","Stefanos","Ilias",
        "Aristeidis","Theodoros","Evangelos","Charalampos","Apostolos","Fotis","Tasos","Manolis","Lazaros","Angelos",
        "Achilleas","Adonis","Agamemnon","Alexis","Anastasios","Andreas","Anestis","Antonios","Aris","Athanasios",
        "Christoforos","Dionysis","Dimitrios","Efstathios","Eleftherios","Emmanouil","Epaminondas","Eugenios","Filippos","Georgios",
        "Gerasimos","Grigorios","Haralambos","Iakovos","Ioannis","Isidoros","Kleanthis","Konstantinos","Kyriakos","Leonidas",
        "Loukas","Marios","Miltiadis","Minas","Nikolaos","Odysseas","Panos","Pantelis","Paraskevas","Pavlos",
        "Periklis","Polychronis","Prokopis","Sotiris","Spyridon","Stamatis","Stavros","Stratis","Symeon","Thanasis",
        "Themistoklis","Thrasyvoulos","Timoleon","Triantafyllos","Vaggelis","Vasileios","Vlasis","Xenofon","Yiannis","Zisis",
        "Alexandros","Antonis","Aristidis","Christoforos","Dimitris","Evangelos","Fotis","Georgios","Haris","Ilias",
        "Konstantinos","Leonidas","Manolis","Nikos","Panagiotis","Petros","Spyros","Thanasis","Vasilis","Yiannis",
        "Anargyros","Anastasios","Andreas","Antonios","Apostolos","Aristomenis","Athanasios","Christos","Dimitrios","Efthymios",
        "Eleftherios","Emmanouil","Evangelos","Georgios","Gerasimos","Grigorios","Ioannis","Konstantinos","Kyriakos","Lambros",
        "Marios","Michail","Nikolaos","Panagiotis","Panteleimon","Petros","Sotirios","Spyridon","Stavros","Theodoros"
    };

    private static final String[] EL_FEMALE = {
        "Maria","Eleni","Aikaterini","Vasiliki","Sofia","Angeliki","Georgia","Dhimitra","Konstantina","Panagiota",
        "Anastasia","Ioanna","Christina","Paraskevi","Evangelia","Eirini","Despina","Athina","Zoi","Efthymia",
        "Styliani","Chrysoula","Aspasia","Olympia","Kalliopi","Pinelopi","Andromachi","Agapi","Dora","Afroditi",
        "Agatha","Agnì","Aikaterina","Alexandra","Aliki","Anastasi","Andriani","Anna","Anthi","Antigoni",
        "Areti","Ariadni","Artemis","Athanasia","Calliope","Charikleia","Chloe","Chrysa","Damiani","Danai",
        "Daphne","Dimitra","Dionysia","Dorothea","Eftychia","Elisavet","Eleni","Eleftheria","Elpida","Ermioni",
        "Eugenia","Evdokia","Evgenia","Filitsa","Fotini","Galia","Garyfallia","Gavriela","Genovefa","Glykeria",
        "Ifigeneia","Ilektra","Iliana","Ioanna","Ioulia","Irene","Isidora","Kali","Kallirroi","Katerina",
        "Katina","Kiki","Kleio","Kleopatra","Korina","Kyriaki","Lamprini","Lena","Litsa","Loukia",
        "Magdalini","Margarita","Marina","Maro","Melina","Meropi","Myrto","Nadia","Natalia","Nefeli",
        "Nikoletta","Niki","Olga","Ourania","Pagona","Panagoula","Paraskevi","Parthena","Pelagia","Persefoni",
        "Polina","Rania","Rena","Roxani","Sevastiani","Smaragda","Sofia","Sotiria","Stavroula","Stella",
        "Theodora","Theofania","Thespina","Thomais","Thaleia","Triantafyllia","Vasiliki","Vasilina","Vicky","Violeta",
        "Xanthippi","Xenia","Yiannoula","Zacharoula","Zafeiria","Zoe","Zografia","Areti","Chrysi","Dimitra"
    };

    private static final String[] EL_SURNAMES = {
        "Papadopoulos","Georgiou","Dimitriou","Nikolaou","Ioannou","Vasileiou","Konstantinou","Antoniou","Pappas","Oikonomou",
        "Makris","Athanasiou","Christodoulou","Stefanidis","Theodorou","Petridis","Lazaridis","Karagiannis","Stavropoulos","Karagiorgos",
        "Tsimpoukis","Michailidis","Chatzis","Papanikolaou","Spanos","Roussos","Fotopoulos","Karamanlis","Dragoumis","Venizelos",
        "Alexiou","Anagnostou","Andreou","Antonopoulos","Apostolou","Bakas","Bekiaris","Chatzidakis","Chatzigiannis","Christou",
        "Diamantis","Dimopoulos","Doukas","Economides","Eleftheriou","Fotiadis","Gavriel","Georgiadis","Giannakopoulos","Giannopoulos",
        "Gikas","Grigoriadis","Hatzis","Iliadis","Kalogeropoulos","Kanelopoulos","Kapsalis","Karalis","Karras","Katsaros",
        "Kazantzakis","Kolovos","Kondylis","Kontos","Kostakis","Kouris","Kouros","Kyriakidis","Lambrakis","Laskaris",
        "Liakos","Logothetis","Lykoudis","Manolakis","Mavridis","Mavrommatis","Megalos","Melas","Michalopoulos","Mihailidis",
        "Mitropoulos","Moraitis","Nikolaidis","Nomikos","Oikonomidis","Panagiotopoulos","Panagopoulos","Papachristou","Papageorgiou","Papakonstantinou",
        "Papanastasiou","Papatheodorou","Papazoglou","Pavlidis","Petrakis","Petropoulos","Politis","Poulakis","Psarras","Raptis",
        "Rigos","Samaras","Sarris","Sideris","Sioufas","Skoulas","Sotiriou","Spanos","Stamatakis","Stamatiou",
        "Stavrakis","Stefanou","Tatsis","Theodorakis","Theodoridis","Trikoupis","Tsakalos","Tsaldaris","Tsatsos","Vasilakis",
        "Vlachos","Voulgaris","Xanthopoulos","Xenakis","Zachariadis","Zafeiris","Zervas","Zografos","Zorbas","Zouros"
    };

    // --- Древнегреческий (латиница) ---
    private static final String[] GRC_MALE = {
        "Sokrates","Platon","Aristoteles","Perikles","Themistokles","Leonidas","Alexandros","Philippos","Homeros","Hesiodos",
        "Sophokles","Euripides","Aischylos","Aristophanes","Thukydides","Herodotos","Xenophon","Demosthenes","Isokrates","Lysias",
        "Pythagoras","Empedokles","Herakleitos","Demokritos","Epikouros","Zenon","Kleanthes","Chrysippos","Plotinos","Proklos",
        "Achilleus","Agamemnon","Aias","Alkibiades","Anaxagoras","Anaximandros","Anaximenes","Antisthenes","Apollodoros","Archimedes",
        "Archilochos","Aristeides","Aristippos","Aristomenes","Bias","Chilon","Chrysippos","Demetrios","Diogenes","Dionysios",
        "Empedokles","Epaminondas","Eratosthenes","Eukleides","Euripides","Hektor","Herakleitos","Herodotos","Hesiodos","Hipparchos",
        "Hippokrates","Homeros","Iason","Isokrates","Kadmos","Kallikrates","Kimon","Kleisthenes","Kleomenes","Kritias",
        "Kroisos","Leonidas","Leukippos","Lykourgos","Lysandros","Miltiades","Menandros","Myson","Nestor","Odysseus",
        "Orpheus","Parmenides","Patroklos","Peisistratos","Periandros","Pheidias","Pindaros","Pittakos","Plutarchos","Polybios",
        "Polykleitos","Poseidonios","Protagoras","Ptolemy","Pyrrhon","Pythagoras","Sappho","Simonides","Solon","Sophokles",
        "Thales","Themistokles","Theokritos","Theophrastos","Thukydides","Timoleon","Xenophanes","Xenophon","Zeuxis","Zeno"
    };

    private static final String[] GRC_FEMALE = {
        "Athena","Hera","Aphrodite","Artemis","Demeter","Hestia","Persephone","Helene","Klytaimnestra","Andromache",
        "Penelope","Kalypso","Kirke","Antigone","Iphigeneia","Hekabe","Kassandra","Ariadne","Phaidra","Medeia",
        "Danae","Alkmini","Hermione","Europa","Isis","Atalante","Amazone","Hippolyte","Penthesilea","Elektra",
        "Klytemnestra","Antiope","Aerope","Aethra","Aglaia","Aigle","Alkestis","Amphitrite","Ananke","Andromeda",
        "Antikleia","Apate","Ariadne","Aspasia","Asteria","Ate","Beroe","Briseis","Chloris","Chryseis",
        "Daphne","Deianeira","Dione","Doris","Eirene","Elpis","Eos","Erato","Eris","Eunomia",
        "Eurycleia","Eurydike","Evadne","Galatea","Glauke","Gorgophone","Hebe","Hecuba","Helle","Hemera",
        "Hera","Hesione","Hippodameia","Hygeia","Ianthe","Iokaste","Iole","Iris","Ismene","Kalliope",
        "Kallirrhoe","Kassandra","Keto","Kleio","Klymene","Kore","Kreusa","Kybele","Leda","Leto",
        "Leukothea","Lysithea","Maia","Melpomene","Metis","Mnemosyne","Nemesis","Nike","Niobe","Oinone",
        "Ourania","Pandora","Pasiphae","Peitho","Pelopeia","Pheme","Philomela","Phyllis","Polymnia","Procne",
        "Psyche","Rhea","Sappho","Selene","Semela","Sophrosyne","Stheneboia","Terpsichore","Thalia","Theano",
        "Themis","Thetis","Thoosa","Tyche","Urania","Xanthe","Xanthippe","Zephyritis","Zoe","Aidos"
    };

    private static final String[] GRC_SURNAMES = {
        "Homeridis","Platonidis","Aristotelis","Periklidis","Themistoklidis","Leonidis","Alexandridis","Philippidis","Hesiodios","Sophoklidis",
        "Euripidis","Aischylidis","Thukydideios","Herodoteios","Xenophontos","Demostheneios","Isokrateios","Pythagoreios","Empedoklidis","Herakleidis",
        "Parmenidis","Anaxagoridis","Anaximandrou","Anaximenous","Antisthenous","Apollodorou","Archimedeios","Archilocheios","Aristeidou","Aristippeios",
        "Demetriou","Diogenous","Dionysiou","Epaminondou","Eratosthenous","Eukleidou","Hektoreios","Hipparchou","Hippokrateios","Iasonidis",
        "Kadmeios","Kallikrateios","Kimoneios","Kleisthenous","Kleomenous","Kritiou","Kroisiou","Leukippeios","Lykourgou","Lysandreios",
        "Miltiadou","Menandreios","Nestoreios","Odysseios","Orphikos","Patrokleios","Peisistratou","Periandreios","Pheidiou","Pindareios",
        "Pittakou","Ploutarcheios","Polybieios","Polykleiteios","Poseidoniou","Protagoreios","Ptolemaiou","Pyrrhoneios","Sapphous","Simonideios",
        "Soloneios","Thaleios","Theokriteios","Theophrasteios","Timoleontos","Xenophaneios","Zeuxidos","Zenoneios","Achilleios","Agamemnonios",
        "Aiakides","Alkibiadeios","Aristeides","Aristomenous","Bianteios","Chiloneios","Dionysiakos","Epikoureios","Eumeneios","Hipparcheios",
        "Kallimacheios","Kimonikos","Kleantheios","Kritolaos","Leonidas","Lysimacheios","Miltiadeios","Myronidis","Nikandrou","Pausaniou"
    };
}