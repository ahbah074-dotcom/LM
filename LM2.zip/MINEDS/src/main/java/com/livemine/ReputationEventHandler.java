package com.livemine;

import com.livemine.entity.LiveNPCEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.level.BlockEvent;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * Обработчик событий игрока → репутация.
 *
 * v1.0:
 *   - ASSAULT (−30) при ударе по NPC.
 *   - KILL_NPC (−50) при убийстве NPC.
 *   - DESTROY_1_BLOCK (−2) при разрушении блока в чужой деревне.
 *   - Приветствие с текущей репутацией при входе.
 */
@EventBusSubscriber(modid = LiveMineMod.MOD_ID)
public final class ReputationEventHandler {

    private ReputationEventHandler() {}

    // =========================================================================
    // Удар по NPC
    // =========================================================================

    @SubscribeEvent
    public static void onAttackEntity(AttackEntityEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!(event.getTarget() instanceof LiveNPCEntity npc)) return;

        String rawId = npc.getVillageRawId();
        if (rawId.isEmpty()) return;

        UUID villageUuid = UUID.nameUUIDFromBytes(rawId.getBytes(StandardCharsets.UTF_8));

        try {
            ReputationManager.getInstance()
                .onWitnessedAction(villageUuid, player.getUUID(),
                    ReputationManager.Action.ASSAULT);
        } catch (Exception e) {
            LiveMineMod.LOGGER.error("ReputationEventHandler.onAttack failed", e);
        }
    }

    // =========================================================================
    // Убийство NPC
    // =========================================================================

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof LiveNPCEntity npc)) return;

        Entity source = event.getSource().getEntity();
        if (!(source instanceof ServerPlayer player)) return;

        String rawId = npc.getVillageRawId();
        if (rawId.isEmpty()) return;

        UUID villageUuid = UUID.nameUUIDFromBytes(rawId.getBytes(StandardCharsets.UTF_8));

        try {
            ReputationManager.getInstance()
                .onWitnessedAction(villageUuid, player.getUUID(),
                    ReputationManager.Action.KILL_NPC);
        } catch (Exception e) {
            LiveMineMod.LOGGER.error("ReputationEventHandler.onKill failed", e);
        }
    }

    // =========================================================================
    // Разрушение блока в чужой деревне
    // =========================================================================

    @SubscribeEvent
    public static void onBlockBreak(BlockEvent.BreakEvent event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (!(event.getPlayer() instanceof ServerPlayer player)) return;

        BlockPos pos = event.getPos();

        // Ищем владельца территории.
        var owner = com.livemine.territory.TerritoryManager.getInstance()
            .getOwner(level, pos.getX(), pos.getZ());
        if (owner == null) return;

        // Игрок в своей деревне? Пропускаем.
        // (Пока не поддерживаем "свою" деревню для игрока — считаем чужой.)
        try {
            ReputationManager.getInstance()
                .onWitnessedAction(owner.id(), player.getUUID(),
                    ReputationManager.Action.DESTROY_1_BLOCK);
        } catch (Exception e) {
            LiveMineMod.LOGGER.error("ReputationEventHandler.onBreak failed", e);
        }
    }

    // =========================================================================
    // Приветствие при входе
    // =========================================================================

    @SubscribeEvent
    public static void onPlayerJoin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;

        // Показываем "нейтральное" приветствие — репутация появится,
        // когда игрок взаимодействует с деревней.
        player.sendSystemMessage(Component.literal(
            "§6[LiveMine]§r §7Нажмите §eG§7, чтобы открыть справочник."
        ));
    }
}