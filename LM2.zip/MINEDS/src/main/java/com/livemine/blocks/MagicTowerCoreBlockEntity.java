package com.livemine.blocks;

import com.livemine.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * BlockEntity ядра магической башни: mana + currentRecipe.
 */
public class MagicTowerCoreBlockEntity extends BlockEntity {

    public static final double MAX_MANA = 100.0;
    public static final double MANA_REGEN = 1.0;
    public static final double CRAFT_COST = 0.5;

    private static final int TICK_INTERVAL = 80;

    private String currentRecipe = "";
    private double craftProgress;
    private double mana;

    private int tickCounter;

    public MagicTowerCoreBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.MAGIC_TOWER_CORE_BE.get(), pos, state);
    }

    public static void tick(Level level, BlockPos pos, BlockState state, MagicTowerCoreBlockEntity entity) {
        if (level.isClientSide()) return;

        entity.tickCounter++;
        if (entity.tickCounter < TICK_INTERVAL) return;
        entity.tickCounter = 0;

        if (entity.mana < MAX_MANA) {
            entity.mana = Math.min(MAX_MANA, entity.mana + MANA_REGEN);
        }

        if (!entity.currentRecipe.isEmpty() && entity.mana >= 10) {
            entity.craftProgress += 2.0;
            entity.mana -= CRAFT_COST;

            if (entity.craftProgress >= 100) {
                entity.currentRecipe = "";
                entity.craftProgress = 0;
            }
        }

        entity.setChanged();
    }

    public String getCurrentRecipe() { return currentRecipe; }
    public double getCraftProgress() { return craftProgress; }
    public double getMana() { return mana; }
    public double getMaxMana() { return MAX_MANA; }
    public boolean isCrafting() { return !currentRecipe.isEmpty(); }

    public void setRecipe(String recipe) {
        this.currentRecipe = recipe != null ? recipe : "";
        this.craftProgress = 0;
        setChanged();
    }

    public void addMana(double amount) {
        this.mana = Math.max(0, Math.min(MAX_MANA, this.mana + amount));
        setChanged();
    }

    public boolean consumeMana(double amount) {
        if (mana < amount) return false;
        mana -= amount;
        setChanged();
        return true;
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putString("recipe", currentRecipe);
        tag.putDouble("progress", craftProgress);
        tag.putDouble("mana", mana);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        currentRecipe = tag.getString("recipe");
        craftProgress = tag.getDouble("progress");
        mana = tag.getDouble("mana");
    }
}
