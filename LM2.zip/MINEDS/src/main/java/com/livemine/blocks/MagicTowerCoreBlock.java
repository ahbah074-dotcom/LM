package com.livemine.blocks;

import com.livemine.registry.ModBlockEntities;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;

/**
 * Ядро магической башни.
 */
public class MagicTowerCoreBlock extends BaseEntityBlock {

    public static final MapCodec<MagicTowerCoreBlock> CODEC = simpleCodec(MagicTowerCoreBlock::new);

    public MagicTowerCoreBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new MagicTowerCoreBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state,
                                                                   BlockEntityType<T> type) {
        if (level.isClientSide()) return null;
        return createTickerHelper(type, ModBlockEntities.MAGIC_TOWER_CORE_BE.get(),
            MagicTowerCoreBlockEntity::tick);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos,
                                                Player player, BlockHitResult hit) {
        if (level.isClientSide()) return InteractionResult.SUCCESS;

        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof MagicTowerCoreBlockEntity tower) {
            player.sendSystemMessage(Component.literal(
                "§5Магическая башня§r\n" +
                "§7Мана: §f" + String.format("%.1f", tower.getMana()) + "/" + tower.getMaxMana() +
                "§7 | Крафт: §f" + (tower.getCurrentRecipe().isEmpty() ? "нет" : tower.getCurrentRecipe()) +
                "§7 | Прогресс: §f" + String.format("%.0f%%", tower.getCraftProgress())
            ));
        }
        return InteractionResult.CONSUME;
    }
}
