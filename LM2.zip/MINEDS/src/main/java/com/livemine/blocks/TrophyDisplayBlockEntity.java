package com.livemine.blocks;

import com.livemine.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

/**
 * BlockEntity витрины трофеев.
 */
public class TrophyDisplayBlockEntity extends BlockEntity {

    public static final int MAX_TROPHIES = 9;

    public static final class TrophyEntry {
        public ItemStack item;
        public String description;
        public long awardedDay;

        public TrophyEntry(ItemStack item, String description, long day) {
            this.item = item != null ? item : ItemStack.EMPTY;
            this.description = description != null ? description : "";
            this.awardedDay = day;
        }

        public CompoundTag save(HolderLookup.Provider registries) {
            CompoundTag tag = new CompoundTag();
            tag.put("item", item.saveOptional(registries));
            tag.putString("desc", description);
            tag.putLong("day", awardedDay);
            return tag;
        }

        public static TrophyEntry load(CompoundTag tag, HolderLookup.Provider registries) {
            ItemStack item = ItemStack.parseOptional(registries, tag.getCompound("item"));
            return new TrophyEntry(item, tag.getString("desc"), tag.getLong("day"));
        }
    }

    private final List<TrophyEntry> trophies = new ArrayList<>();

    public TrophyDisplayBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.TROPHY_DISPLAY_BE.get(), pos, state);
    }

    public boolean addTrophy(TrophyEntry entry) {
        if (trophies.size() >= MAX_TROPHIES) return false;
        trophies.add(entry);
        setChanged();
        return true;
    }

    public List<TrophyEntry> getTrophies() { return trophies; }
    public int getTrophyCount() { return trophies.size(); }

    public void removeTrophy(int index) {
        if (index < 0 || index >= trophies.size()) return;
        trophies.remove(index);
        setChanged();
    }

    public void clearTrophies() {
        trophies.clear();
        setChanged();
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);

        ListTag list = new ListTag();
        for (TrophyEntry entry : trophies) list.add(entry.save(registries));
        tag.put("trophies", list);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        trophies.clear();

        ListTag list = tag.getList("trophies", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            trophies.add(TrophyEntry.load(list.getCompound(i), registries));
        }
    }
}
