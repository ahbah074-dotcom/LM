package com.livemine.blocks;

import com.livemine.VillageData;
import com.livemine.VillageManager;
import com.livemine.registry.ModBlockEntities;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;

/**
 * Центр деревни.
 *
 * v2.0: onPlace делегирует создание деревни в VillageManager
 * (единая точка регистрации, синхронизирует SavedData + реестр).
 */
public class VillageCenterBlock extends BaseEntityBlock {

    public static final MapCodec<VillageCenterBlock> CODEC = simpleCodec(VillageCenterBlock::new);
    public static final IntegerProperty VILLAGE_LEVEL =
        IntegerProperty.create("village_level", 0, 5);

    public VillageCenterBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(VILLAGE_LEVEL, 0));
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(VILLAGE_LEVEL);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new VillageCenterBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state,
                                                                   BlockEntityType<T> type) {
        if (level.isClientSide()) return null;
        return createTickerHelper(type, ModBlockEntities.VILLAGE_CENTER_BE.get(),
            VillageCenterBlockEntity::tick);
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean isMoving) {
        super.onPlace(state, level, pos, oldState, isMoving);

        if (!level.isClientSide() && level instanceof ServerLevel sl) {
            String name = "Деревня " + pos.getX() + "," + pos.getZ();
            // Единая точка регистрации — через VillageManager.
            VillageManager.getInstance().createVillage(name, pos, sl, "generic");
        }
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
        if (state.getBlock() != newState.getBlock()) {
            BlockEntity be = level.getBlockEntity(pos);
            if (be instanceof VillageCenterBlockEntity center) {
                center.dropContents();
            }
        }
        super.onRemove(state, level, pos, newState, isMoving);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos,
                                                Player player, BlockHitResult hit) {
        if (level.isClientSide()) return InteractionResult.SUCCESS;

        if (level instanceof ServerLevel sl) {
            String vid = "village_" + pos.asLong();
            VillageData vd = new VillageData(vid, sl);
            if (vd.exists()) {
                player.sendSystemMessage(Component.literal(
                    "§6=== " + vid + " ===\n" +
                    "§7Население: §f" + vd.getPopulation() +
                    "§7 | Радиус: §f" + vd.getRadius() +
                    "§7 | Ресурсы: §f" + String.format("%.1f", vd.getResources())
                ));
            } else {
                player.sendSystemMessage(Component.literal("§7Деревня не зарегистрирована"));
            }
        }
        return InteractionResult.CONSUME;
    }
}