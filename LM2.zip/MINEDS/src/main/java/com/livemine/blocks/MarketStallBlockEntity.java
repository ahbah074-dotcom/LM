package com.livemine.blocks;

import com.livemine.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

/**
 * BlockEntity торговой лавки.
 *
 * v2.0: добавлены tryPurchase (C→S) и buildSyncPacket (S→C).
 */
public class MarketStallBlockEntity extends BlockEntity {

    private static final int TICK_INTERVAL = 200;
    private static final int MAX_TRADES = 12;

    public static final class TradeEntry {
        public ItemStack offer;
        public ItemStack price;
        public int stock;
        public double demand;

        public TradeEntry(ItemStack offer, ItemStack price) {
            this.offer = offer != null ? offer : ItemStack.EMPTY;
            this.price = price != null ? price : ItemStack.EMPTY;
            this.stock = 0;
            this.demand = 1.0;
        }

        public CompoundTag save(HolderLookup.Provider registries) {
            CompoundTag tag = new CompoundTag();
            tag.put("offer", offer.saveOptional(registries));
            tag.put("price", price.saveOptional(registries));
            tag.putInt("stock", stock);
            tag.putDouble("demand", demand);
            return tag;
        }

        public static TradeEntry load(CompoundTag tag, HolderLookup.Provider registries) {
            ItemStack offer = ItemStack.parseOptional(registries, tag.getCompound("offer"));
            ItemStack price = ItemStack.parseOptional(registries, tag.getCompound("price"));
            TradeEntry entry = new TradeEntry(offer, price);
            entry.stock = tag.getInt("stock");
            entry.demand = tag.getDouble("demand");
            return entry;
        }
    }

    private final List<TradeEntry> trades = new ArrayList<>();
    private int tickCounter;

    public MarketStallBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.MARKET_STALL_BE.get(), pos, state);
    }

    public static void tick(Level level, BlockPos pos, BlockState state, MarketStallBlockEntity entity) {
        if (level.isClientSide()) return;

        entity.tickCounter++;
        if (entity.tickCounter < TICK_INTERVAL) return;
        entity.tickCounter = 0;

        boolean changed = false;
        for (TradeEntry entry : entity.trades) {
            if (entry.stock < 10) {
                entry.demand = Math.min(3.0, entry.demand + 0.1);
                changed = true;
            } else if (entry.stock > 50) {
                entry.demand = Math.max(0.3, entry.demand - 0.05);
                changed = true;
            }
        }
        if (changed) entity.setChanged();
    }

    public List<TradeEntry> getTrades() { return trades; }
    public int getTradeCount() { return trades.size(); }

    public boolean addTrade(TradeEntry entry) {
        if (trades.size() >= MAX_TRADES) return false;
        trades.add(entry);
        setChanged();
        return true;
    }

    public void removeTrade(int index) {
        if (index < 0 || index >= trades.size()) return;
        trades.remove(index);
        setChanged();
    }

    public void clearTrades() {
        trades.clear();
        setChanged();
    }

    public void changeStock(int index, int delta) {
        if (index < 0 || index >= trades.size()) return;
        TradeEntry entry = trades.get(index);
        entry.stock = Math.max(0, entry.stock + delta);
        setChanged();
    }

    // =========================================================================
    // v2.0: Покупка лота
    // =========================================================================

    /**
     * Попытка покупки лота игроком.
     * - Проверяет наличие товара (stock > 0).
     * - Проверяет, что у игрока есть ингредиенты оплаты.
     * - Выдаёт offer, забирает price.
     *
     * @return true, если покупка успешна
     */
    public boolean tryPurchase(int slotIndex, ServerPlayer player) {
        if (slotIndex < 0 || slotIndex >= trades.size()) return false;

        TradeEntry entry = trades.get(slotIndex);
        if (entry.stock <= 0) return false;
        if (entry.offer.isEmpty()) return false;

        // Проверяем оплату в инвентаре игрока.
        if (!entry.price.isEmpty()) {
            int have = countItem(player, entry.price);
            if (have < entry.price.getCount()) return false;
            // Забираем.
            consumeItem(player, entry.price, entry.price.getCount());
        }

        // Выдаём товар.
        ItemStack give = entry.offer.copy();
        if (!player.getInventory().add(give)) {
            player.drop(give, false);
        }

        entry.stock--;
        setChanged();

        return true;
    }

    private int countItem(ServerPlayer player, ItemStack want) {
        int count = 0;
        var inv = player.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (!stack.isEmpty() && ItemStack.isSameItemSameComponents(stack, want)) {
                count += stack.getCount();
            }
        }
        return count;
    }

    private void consumeItem(ServerPlayer player, ItemStack want, int amount) {
        int remaining = amount;
        var inv = player.getInventory();
        for (int i = 0; i < inv.getContainerSize() && remaining > 0; i++) {
            ItemStack stack = inv.getItem(i);
            if (!stack.isEmpty() && ItemStack.isSameItemSameComponents(stack, want)) {
                int take = Math.min(remaining, stack.getCount());
                stack.shrink(take);
                remaining -= take;
                if (stack.isEmpty()) inv.setItem(i, ItemStack.EMPTY);
            }
        }
        player.getInventory().setChanged();
    }

    /**
     * Собирает пакет для отправки клиенту.
     */
    public com.livemine.network.MarketStallSyncPacket buildSyncPacket() {
        List<com.livemine.network.MarketStallSyncPacket.TradeView> views = new ArrayList<>();
        for (TradeEntry entry : trades) {
            String offerName = entry.offer.isEmpty()
                ? "" : entry.offer.getHoverName().getString();
            int offerCount = entry.offer.getCount();

            String priceName = entry.price.isEmpty()
                ? "" : entry.price.getHoverName().getString();
            int priceCount = entry.price.getCount();

            views.add(new com.livemine.network.MarketStallSyncPacket.TradeView(
                offerName, offerCount,
                priceName, priceCount,
                entry.stock, entry.demand
            ));
        }
        return new com.livemine.network.MarketStallSyncPacket(worldPosition, views);
    }

    // =========================================================================
    // NBT
    // =========================================================================

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);

        ListTag list = new ListTag();
        for (TradeEntry entry : trades) list.add(entry.save(registries));
        tag.put("trades", list);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        trades.clear();

        ListTag list = tag.getList("trades", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            trades.add(TradeEntry.load(list.getCompound(i), registries));
        }
    }
}