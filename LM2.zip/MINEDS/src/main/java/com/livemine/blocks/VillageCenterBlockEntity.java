package com.livemine.blocks;

import com.livemine.VillageData;
import com.livemine.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * BlockEntity центра деревни.
 */
public class VillageCenterBlockEntity extends BlockEntity {

    private static final int TICK_INTERVAL = 200;

    private String villageName = "Unnamed Village";
    private String villageId = "";
    private int villageLevel = 0;
    private int tickCounter;

    public VillageCenterBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.VILLAGE_CENTER_BE.get(), pos, state);
    }

    public static void tick(Level level, BlockPos pos, BlockState state, VillageCenterBlockEntity entity) {
        if (level.isClientSide()) return;
        if (!(level instanceof ServerLevel sl)) return;

        entity.tickCounter++;
        if (entity.tickCounter < TICK_INTERVAL) return;
        entity.tickCounter = 0;

        String vid = "village_" + pos.asLong();
        VillageData vd = new VillageData(vid, sl);
        if (!vd.exists()) return;

        vd.addNeed("food", 1.0);
        vd.addNeed("wood", 0.5);
        vd.addNeed("ore", 0.5);

        entity.setChanged();
    }

    public String getVillageName() { return villageName; }
    public void setVillageName(String name) {
        this.villageName = name != null ? name : "";
        setChanged();
    }

    public String getVillageId() { return villageId; }
    public void setVillageId(String id) {
        this.villageId = id != null ? id : "";
        setChanged();
    }

    public int getVillageLevel() { return villageLevel; }
    public void setVillageLevel(int lvl) {
        this.villageLevel = Math.max(0, Math.min(5, lvl));
        setChanged();
    }

    public void dropContents() {
        // Данные в LiveMineSavedData
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putString("village_name", villageName);
        tag.putString("village_id", villageId);
        tag.putInt("village_level", villageLevel);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        if (tag.contains("village_name")) villageName = tag.getString("village_name");
        if (tag.contains("village_id")) villageId = tag.getString("village_id");
        if (tag.contains("village_level")) villageLevel = tag.getInt("village_level");
    }
}
