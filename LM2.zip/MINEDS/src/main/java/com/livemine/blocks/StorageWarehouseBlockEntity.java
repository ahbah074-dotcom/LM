package com.livemine.blocks;

import com.livemine.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * BlockEntity склада ресурсов.
 */
public class StorageWarehouseBlockEntity extends BlockEntity {

    private static final int TICK_INTERVAL = 100;

    private double storedOre;
    private double storedWood;
    private double storedFood;
    private double storedTools;

    private int tickCounter;

    public StorageWarehouseBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.STORAGE_WAREHOUSE_BE.get(), pos, state);
    }

    public static void tick(Level level, BlockPos pos, BlockState state, StorageWarehouseBlockEntity entity) {
        if (level.isClientSide()) return;

        entity.tickCounter++;
        if (entity.tickCounter < TICK_INTERVAL) return;
        entity.tickCounter = 0;

        entity.setChanged();
    }

    public double getOre() { return storedOre; }
    public double getWood() { return storedWood; }
    public double getFood() { return storedFood; }
    public double getTools() { return storedTools; }
    public double getTotal() { return storedOre + storedWood + storedFood + storedTools; }

    public void addOre(double amount) { storedOre = Math.max(0, storedOre + amount); setChanged(); }
    public void addWood(double amount) { storedWood = Math.max(0, storedWood + amount); setChanged(); }
    public void addFood(double amount) { storedFood = Math.max(0, storedFood + amount); setChanged(); }
    public void addTools(double amount) { storedTools = Math.max(0, storedTools + amount); setChanged(); }

    public boolean consumeOre(double amount) {
        if (storedOre < amount) return false;
        storedOre -= amount; setChanged(); return true;
    }
    public boolean consumeWood(double amount) {
        if (storedWood < amount) return false;
        storedWood -= amount; setChanged(); return true;
    }
    public boolean consumeFood(double amount) {
        if (storedFood < amount) return false;
        storedFood -= amount; setChanged(); return true;
    }
    public boolean consumeTools(double amount) {
        if (storedTools < amount) return false;
        storedTools -= amount; setChanged(); return true;
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putDouble("ore", storedOre);
        tag.putDouble("wood", storedWood);
        tag.putDouble("food", storedFood);
        tag.putDouble("tools", storedTools);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        storedOre = tag.getDouble("ore");
        storedWood = tag.getDouble("wood");
        storedFood = tag.getDouble("food");
        storedTools = tag.getDouble("tools");
    }
}
