package com.livemine.blocks;

import com.livemine.registry.ModBlockEntities;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;

/**
 * Торговая лавка.
 *
 * v2.0: ПКМ отправляет MarketStallSyncPacket клиенту.
 */
public class MarketStallBlock extends BaseEntityBlock {

    public static final MapCodec<MarketStallBlock> CODEC = simpleCodec(MarketStallBlock::new);

    public MarketStallBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new MarketStallBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state,
                                                                   BlockEntityType<T> type) {
        if (level.isClientSide()) return null;
        return createTickerHelper(type, ModBlockEntities.MARKET_STALL_BE.get(),
            MarketStallBlockEntity::tick);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos,
                                                Player player, BlockHitResult hit) {
        if (level.isClientSide()) return InteractionResult.SUCCESS;

        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof MarketStallBlockEntity stall) {
            if (stall.getTrades().isEmpty()) {
                player.sendSystemMessage(Component.literal("§7Лавка пуста."));
                return InteractionResult.CONSUME;
            }

            if (player instanceof ServerPlayer sp) {
                try {
                    sp.connection.send(stall.buildSyncPacket());
                } catch (Exception e) {
                    player.sendSystemMessage(Component.literal(
                        "§cОшибка открытия лавки: " + e.getMessage()));
                }
            }
        }
        return InteractionResult.CONSUME;
    }
}