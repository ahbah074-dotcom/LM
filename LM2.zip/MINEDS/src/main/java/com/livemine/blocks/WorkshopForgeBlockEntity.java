package com.livemine.blocks;

import com.livemine.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * BlockEntity кузницы: fuel + currentCraft.
 */
public class WorkshopForgeBlockEntity extends BlockEntity {

    public static final int MAX_FUEL = 2000;

    private static final int TICK_INTERVAL = 40;
    private static final double PROGRESS_STEP = 0.5;

    private String currentCraft = "";
    private double craftProgress;
    private int fuel = 400;

    private int tickCounter;

    public WorkshopForgeBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.WORKSHOP_FORGE_BE.get(), pos, state);
    }

    public static void tick(Level level, BlockPos pos, BlockState state, WorkshopForgeBlockEntity entity) {
        if (level.isClientSide()) return;

        entity.tickCounter++;
        if (entity.tickCounter < TICK_INTERVAL) return;
        entity.tickCounter = 0;

        if (entity.fuel > 0 && !entity.currentCraft.isEmpty()) {
            entity.craftProgress += PROGRESS_STEP;
            entity.fuel--;

            if (entity.craftProgress >= 100) {
                entity.currentCraft = "";
                entity.craftProgress = 0;
            }
            entity.setChanged();
        }
    }

    public String getCurrentCraft() { return currentCraft; }
    public double getCraftProgress() { return craftProgress; }
    public int getFuel() { return fuel; }
    public boolean isActive() { return fuel > 0 && !currentCraft.isEmpty(); }

    public void setCraft(String craft) {
        this.currentCraft = craft != null ? craft : "";
        this.craftProgress = 0;
        setChanged();
    }

    public void setCraftProgress(double progress) {
        this.craftProgress = Math.max(0, Math.min(100, progress));
        setChanged();
    }

    public void addFuel(int amount) {
        this.fuel = Math.min(MAX_FUEL, Math.max(0, this.fuel + amount));
        setChanged();
    }

    public void setFuel(int amount) {
        this.fuel = Math.max(0, Math.min(MAX_FUEL, amount));
        setChanged();
    }

    public boolean consumeFuel(int amount) {
        if (fuel < amount) return false;
        fuel -= amount;
        setChanged();
        return true;
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putString("craft", currentCraft);
        tag.putDouble("progress", craftProgress);
        tag.putInt("fuel", fuel);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        currentCraft = tag.getString("craft");
        craftProgress = tag.getDouble("progress");
        fuel = tag.getInt("fuel");
    }
}
