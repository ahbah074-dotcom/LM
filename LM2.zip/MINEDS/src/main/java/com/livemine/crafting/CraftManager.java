package com.livemine.crafting;

import com.livemine.NPCSkills;
import com.livemine.entity.LiveNPCEntity;
import com.livemine.recipe.RecipeSafetyPolicy;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.List;

/**
 * Менеджер крафта инструментов NPC.
 *
 * v2.0: добавлен публичный craftAnyTool(LiveNPCEntity, ServerLevel).
 */
public final class CraftManager {

    public enum ToolType {
        PICKAXE("кирка"),
        AXE("топор"),
        SWORD("меч"),
        SHOVEL("лопата"),
        HOE("мотыга");

        public final String ruName;
        ToolType(String ru) { this.ruName = ru; }
    }

    public enum ToolTier {
        WOODEN(1, "деревянный"),
        STONE(3, "каменный"),
        IRON(5, "железный"),
        DIAMOND(7, "алмазный"),
        NETHERITE(9, "незеритовый");

        public final int requiredLevel;
        public final String ruName;
        ToolTier(int req, String ru) { this.requiredLevel = req; this.ruName = ru; }
    }

    private CraftManager() {}

    // =========================================================================
    // v2.0: Единая точка входа для NPC
    // =========================================================================

    /**
     * Пытается скрафтить любой доступный инструмент.
     * Идёт от высшего тира к низшему, от самого простого инструмента.
     * @return true, если что-то скрафчено
     */
    public static boolean craftAnyTool(LiveNPCEntity npc, ServerLevel level) {
        if (npc == null || level == null) return false;
        if (npc.getSkills() == null) return false;

        ToolTier tier = getAvailableTier(npc);

        // От высшего тира — вниз.
        ToolTier[] tiers = ToolTier.values();
        for (int ti = tiers.length - 1; ti >= 0; ti--) {
            ToolTier t = tiers[ti];
            if (t.requiredLevel > tier.requiredLevel) continue;

            for (ToolType type : ToolType.values()) {
                // Не крафтим то, что уже есть.
                if (hasTool(npc, type)) continue;

                if (craftTool(npc, level, type, t)) {
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean hasTool(LiveNPCEntity npc, ToolType type) {
        for (ItemStack stack : npc.getInventoryItems()) {
            if (stack.isEmpty()) continue;
            if (matchesToolType(stack.getItem(), type)) return true;
        }
        return false;
    }

    // =========================================================================
    // Проверки
    // =========================================================================

    public static ToolTier getAvailableTier(LiveNPCEntity npc) {
        if (npc == null || npc.getSkills() == null) return ToolTier.WOODEN;
        double smithing = npc.getSkills().getLevel(NPCSkills.SkillType.SMITHING);

        ToolTier best = ToolTier.WOODEN;
        for (ToolTier tier : ToolTier.values()) {
            if (smithing >= tier.requiredLevel) best = tier;
        }
        return best;
    }

    public static boolean canCraft(LiveNPCEntity npc, ToolType type, ToolTier tier) {
        if (npc == null || type == null || tier == null) return false;
        if (npc.getSkills() == null) return false;
        double smithing = npc.getSkills().getLevel(NPCSkills.SkillType.SMITHING);
        return smithing >= tier.requiredLevel;
    }

    // =========================================================================
    // Крафт
    // =========================================================================

    public static boolean craftTool(LiveNPCEntity npc, ServerLevel level,
                                     ToolType type, ToolTier tier) {
        if (npc == null || level == null || type == null || tier == null) return false;
        if (!canCraft(npc, type, tier)) return false;

        Item material = getMaterial(tier);
        if (material == null) return false;

        int materialCount = getMaterialCount(type);
        int stickCount = getStickCount(type);

        ItemStack result = createToolStack(type, tier);
        if (result.isEmpty()) return false;

        var verdict = RecipeSafetyPolicy.getInstance()
            .evaluateRecipe(result, null, level.getGameTime());
        if (verdict != RecipeSafetyPolicy.Verdict.ALLOW) {
            return false;
        }

        if (!hasInInventory(npc, material, materialCount)) return false;
        if (!hasInInventory(npc, Items.STICK, stickCount)) return false;

        consumeFromInventory(npc, material, materialCount);
        consumeFromInventory(npc, Items.STICK, stickCount);

        npc.addItemToInventory(result);

        RecipeSafetyPolicy.getInstance().recordCraft(result, level.getGameTime());

        long day = level.getDayTime() / 24000L;
        npc.getSkills().addXP(NPCSkills.SkillType.SMITHING, 0.05, day);

        return true;
    }

    // =========================================================================
    // Вспомогательные
    // =========================================================================

    private static Item getMaterial(ToolTier tier) {
        return switch (tier) {
            case WOODEN -> Items.OAK_PLANKS;
            case STONE -> Items.COBBLESTONE;
            case IRON -> Items.IRON_INGOT;
            case DIAMOND -> Items.DIAMOND;
            case NETHERITE -> Items.NETHERITE_INGOT;
        };
    }

    private static int getMaterialCount(ToolType type) {
        return switch (type) {
            case PICKAXE, AXE -> 3;
            case SWORD, HOE -> 2;
            case SHOVEL -> 1;
        };
    }

    private static int getStickCount(ToolType type) {
        return switch (type) {
            case PICKAXE, AXE, SHOVEL, HOE -> 2;
            case SWORD -> 1;
        };
    }

    private static ItemStack createToolStack(ToolType type, ToolTier tier) {
        Item item = switch (tier) {
            case WOODEN -> switch (type) {
                case PICKAXE -> Items.WOODEN_PICKAXE;
                case AXE -> Items.WOODEN_AXE;
                case SWORD -> Items.WOODEN_SWORD;
                case SHOVEL -> Items.WOODEN_SHOVEL;
                case HOE -> Items.WOODEN_HOE;
            };
            case STONE -> switch (type) {
                case PICKAXE -> Items.STONE_PICKAXE;
                case AXE -> Items.STONE_AXE;
                case SWORD -> Items.STONE_SWORD;
                case SHOVEL -> Items.STONE_SHOVEL;
                case HOE -> Items.STONE_HOE;
            };
            case IRON -> switch (type) {
                case PICKAXE -> Items.IRON_PICKAXE;
                case AXE -> Items.IRON_AXE;
                case SWORD -> Items.IRON_SWORD;
                case SHOVEL -> Items.IRON_SHOVEL;
                case HOE -> Items.IRON_HOE;
            };
            case DIAMOND -> switch (type) {
                case PICKAXE -> Items.DIAMOND_PICKAXE;
                case AXE -> Items.DIAMOND_AXE;
                case SWORD -> Items.DIAMOND_SWORD;
                case SHOVEL -> Items.DIAMOND_SHOVEL;
                case HOE -> Items.DIAMOND_HOE;
            };
            case NETHERITE -> switch (type) {
                case PICKAXE -> Items.NETHERITE_PICKAXE;
                case AXE -> Items.NETHERITE_AXE;
                case SWORD -> Items.NETHERITE_SWORD;
                case SHOVEL -> Items.NETHERITE_SHOVEL;
                case HOE -> Items.NETHERITE_HOE;
            };
        };
        return new ItemStack(item, 1);
    }

    private static boolean hasInInventory(LiveNPCEntity npc, Item item, int count) {
        int total = 0;
        for (ItemStack stack : npc.getInventoryItems()) {
            if (stack.is(item)) total += stack.getCount();
            if (total >= count) return true;
        }
        return false;
    }

    private static void consumeFromInventory(LiveNPCEntity npc, Item item, int count) {
        List<ItemStack> items = npc.getInventoryItems();
        int remaining = count;

        for (int i = 0; i < items.size() && remaining > 0; i++) {
            ItemStack stack = items.get(i);
            if (stack.is(item)) {
                int take = Math.min(remaining, stack.getCount());
                stack.shrink(take);
                remaining -= take;
                if (stack.isEmpty()) items.set(i, ItemStack.EMPTY);
            }
        }
        npc.setInventoryItems(items);
    }

    public static int findToolSlot(LiveNPCEntity npc, ToolType type) {
        List<ItemStack> items = npc.getInventoryItems();
        for (int i = 0; i < items.size(); i++) {
            ItemStack stack = items.get(i);
            if (matchesToolType(stack.getItem(), type)) return i;
        }
        return -1;
    }

    private static boolean matchesToolType(Item item, ToolType type) {
        String name = item.getDescriptionId().toLowerCase();
        return switch (type) {
            case PICKAXE -> name.contains("pickaxe");
            case AXE -> name.contains("_axe");
            case SWORD -> name.contains("sword");
            case SHOVEL -> name.contains("shovel");
            case HOE -> name.contains("_hoe");
        };
    }
}