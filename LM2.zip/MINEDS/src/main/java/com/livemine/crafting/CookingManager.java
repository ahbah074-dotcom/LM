package com.livemine.crafting;

import com.livemine.NPCSkills;
import com.livemine.entity.LiveNPCEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.List;

/**
 * Менеджер готовки еды NPC.
 *
 * v2.0: добавлен публичный cookAnyFood(LiveNPCEntity, ServerLevel).
 */
public final class CookingManager {

    public enum FoodType {
        BREAD("Хлеб", NPCSkills.SkillType.COOKING, 1.0),
        COOKED_BEEF("Жареная говядина", NPCSkills.SkillType.COOKING, 1.0),
        COOKED_PORKCHOP("Жареная свинина", NPCSkills.SkillType.COOKING, 1.0),
        MUSHROOM_STEW("Тушёные грибы", NPCSkills.SkillType.COOKING, 2.0),
        RABBIT_STEW("Тушёный кролик", NPCSkills.SkillType.COOKING, 3.0),
        PUMPKIN_PIE("Тыквенный пирог", NPCSkills.SkillType.COOKING, 4.0);

        public final String ruName;
        public final NPCSkills.SkillType skill;
        public final double requiredLevel;

        FoodType(String ru, NPCSkills.SkillType skill, double req) {
            this.ruName = ru;
            this.skill = skill;
            this.requiredLevel = req;
        }
    }

    private CookingManager() {}

    // =========================================================================
    // v2.0: Единая точка входа для NPC
    // =========================================================================

    /**
     * Пытается приготовить любую доступную еду.
     * От простого к сложному.
     * @return true, если что-то приготовлено
     */
    public static boolean cookAnyFood(LiveNPCEntity npc, ServerLevel level) {
        if (npc == null || level == null) return false;
        if (npc.getSkills() == null) return false;

        for (FoodType type : FoodType.values()) {
            if (!canCook(npc, type)) continue;
            if (cook(npc, level, type)) return true;
        }
        return false;
    }

    // =========================================================================
    // Проверки
    // =========================================================================

    public static boolean canCook(LiveNPCEntity npc, FoodType food) {
        if (npc == null || food == null) return false;
        if (npc.getSkills() == null) return false;
        double level = npc.getSkills().getLevel(food.skill);
        return level >= food.requiredLevel;
    }

    public static List<FoodType> getAvailableFoods(LiveNPCEntity npc) {
        List<FoodType> result = new java.util.ArrayList<>();
        for (FoodType type : FoodType.values()) {
            if (canCook(npc, type)) result.add(type);
        }
        return result;
    }

    // =========================================================================
    // Готовка
    // =========================================================================

    public static boolean cook(LiveNPCEntity npc, ServerLevel level, FoodType food) {
        if (npc == null || level == null || food == null) return false;
        if (!canCook(npc, food)) return false;

        switch (food) {
            case BREAD -> {
                if (!hasItems(npc, Items.WHEAT, 3)) return false;
                consume(npc, Items.WHEAT, 3);
                npc.addItemToInventory(new ItemStack(Items.BREAD));
            }
            case COOKED_BEEF -> {
                if (!hasItems(npc, Items.BEEF, 1)) return false;
                consume(npc, Items.BEEF, 1);
                npc.addItemToInventory(new ItemStack(Items.COOKED_BEEF));
            }
            case COOKED_PORKCHOP -> {
                if (!hasItems(npc, Items.PORKCHOP, 1)) return false;
                consume(npc, Items.PORKCHOP, 1);
                npc.addItemToInventory(new ItemStack(Items.COOKED_PORKCHOP));
            }
            case MUSHROOM_STEW -> {
                if (!hasItems(npc, Items.RED_MUSHROOM, 1)
                    || !hasItems(npc, Items.BROWN_MUSHROOM, 1)
                    || !hasItems(npc, Items.BOWL, 1)) return false;
                consume(npc, Items.RED_MUSHROOM, 1);
                consume(npc, Items.BROWN_MUSHROOM, 1);
                consume(npc, Items.BOWL, 1);
                npc.addItemToInventory(new ItemStack(Items.MUSHROOM_STEW));
            }
            case RABBIT_STEW -> {
                if (!hasItems(npc, Items.COOKED_RABBIT, 1)
                    || !hasItems(npc, Items.CARROT, 1)
                    || !hasItems(npc, Items.BAKED_POTATO, 1)
                    || !hasItems(npc, Items.BOWL, 1)) return false;
                consume(npc, Items.COOKED_RABBIT, 1);
                consume(npc, Items.CARROT, 1);
                consume(npc, Items.BAKED_POTATO, 1);
                consume(npc, Items.BOWL, 1);
                npc.addItemToInventory(new ItemStack(Items.RABBIT_STEW));
            }
            case PUMPKIN_PIE -> {
                if (!hasItems(npc, Items.PUMPKIN, 1)
                    || !hasItems(npc, Items.SUGAR, 1)
                    || !hasItems(npc, Items.EGG, 1)) return false;
                consume(npc, Items.PUMPKIN, 1);
                consume(npc, Items.SUGAR, 1);
                consume(npc, Items.EGG, 1);
                npc.addItemToInventory(new ItemStack(Items.PUMPKIN_PIE));
            }
        }

        long day = level.getDayTime() / 24000L;
        npc.getSkills().addXP(food.skill, 0.05, day);
        return true;
    }

    // =========================================================================
    // Утилиты
    // =========================================================================

    private static boolean hasItems(LiveNPCEntity npc, Item item, int count) {
        int total = 0;
        for (ItemStack stack : npc.getInventoryItems()) {
            if (stack.is(item)) total += stack.getCount();
            if (total >= count) return true;
        }
        return false;
    }

    private static void consume(LiveNPCEntity npc, Item item, int count) {
        List<ItemStack> items = npc.getInventoryItems();
        int remaining = count;

        for (int i = 0; i < items.size() && remaining > 0; i++) {
            ItemStack stack = items.get(i);
            if (stack.is(item)) {
                int take = Math.min(remaining, stack.getCount());
                stack.shrink(take);
                remaining -= take;
                if (stack.isEmpty()) items.set(i, ItemStack.EMPTY);
            }
        }
        npc.setInventoryItems(items);
    }
}