package com.livemine;

import net.minecraft.nbt.CompoundTag;

/**
 * Запись личной памяти NPC.
 *
 * Используется в NPCMemory (256 обычных + 64 критических).
 */
public final class MemoryEntry {

    public enum Type {
        FACT, RUMOR, EVENT, DANGER, RESOURCE,
        SOCIAL, SKILL, PROPERTY, DEBT, FAMILY
    }

    public enum Category {
        CARTOGRAPHY, THREATS, CONSTRUCTION, AGRICULTURE,
        REPUTATION, DECISIONS, ALLIANCES, PROFESSIONAL,
        PORTALS, TRADE, SANITARY, ARCHAEOLOGY,
        ENGINEERING, DIMENSIONS, OCEAN, GREENERY,
        GENEALOGY, HOLIDAYS, CONFLICTS, CHRONICLE,
        EXCHANGE, FINDS
    }

    private Type type;
    private String source;
    private long timestamp;
    private float reliability;
    private float importance;
    private Category category;
    private String content;
    private long expiryDay;
    private boolean critical;

    public MemoryEntry(Type type, String source, long timestamp,
                       float reliability, float importance,
                       Category category, String content, long expiryDay) {
        this.type = type;
        this.source = source != null ? source : "";
        this.timestamp = timestamp;
        this.reliability = Math.max(0f, Math.min(1f, reliability));
        this.importance = Math.max(0f, Math.min(1f, importance));
        this.category = category;
        this.content = content != null ? content : "";
        this.expiryDay = expiryDay;
        this.critical = false;
    }

    public MemoryEntry(CompoundTag tag) {
        try {
            this.type = Type.valueOf(tag.getString("type"));
        } catch (IllegalArgumentException e) {
            this.type = Type.FACT;
        }
        this.source = tag.getString("source");
        this.timestamp = tag.getLong("timestamp");
        this.reliability = tag.getFloat("reliability");
        this.importance = tag.getFloat("importance");
        try {
            this.category = Category.valueOf(tag.getString("category"));
        } catch (IllegalArgumentException e) {
            this.category = Category.CHRONICLE;
        }
        this.content = tag.getString("content");
        this.expiryDay = tag.getLong("expiryDay");
        this.critical = tag.getBoolean("critical");
    }

    // =========================================================================
    // Геттеры
    // =========================================================================

    public Type getType() { return type; }
    public String getSource() { return source; }
    public long getTimestamp() { return timestamp; }
    public float getReliability() { return reliability; }
    public float getImportance() { return importance; }
    public Category getCategory() { return category; }
    public String getContent() { return content; }
    public long getExpiryDay() { return expiryDay; }
    public boolean isCritical() { return critical; }

    public void setCritical(boolean critical) { this.critical = critical; }

    // =========================================================================
    // Логика вытеснения
    // =========================================================================

    public float getEvictionScore(long currentDay) {
        float ageFactor = currentDay - timestamp;
        return importance * 100.0f - ageFactor;
    }

    public boolean isExpired(long currentDay) {
        return expiryDay > 0 && currentDay > expiryDay;
    }

    // =========================================================================
    // NBT
    // =========================================================================

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putString("type", type.name());
        tag.putString("source", source);
        tag.putLong("timestamp", timestamp);
        tag.putFloat("reliability", reliability);
        tag.putFloat("importance", importance);
        tag.putString("category", category.name());
        tag.putString("content", content);
        tag.putLong("expiryDay", expiryDay);
        tag.putBoolean("critical", critical);
        return tag;
    }

    public static MemoryEntry load(CompoundTag tag) {
        if (tag == null || tag.isEmpty()) return null;
        return new MemoryEntry(tag);
    }
}
