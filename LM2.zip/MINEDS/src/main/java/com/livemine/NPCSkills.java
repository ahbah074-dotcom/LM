package com.livemine;

import net.minecraft.nbt.CompoundTag;

import java.util.EnumMap;
import java.util.Map;
import java.util.Random;

/**
 * Система навыков NPC.
 *
 * 29 навыков (27 базовых + STEALTH + LOCKPOCKETING).
 * Уровни 0–10 (десятичные дроби внутри уровня).
 * Прокачка — по plateau-формуле из ТЗ 20.1 §7.
 * Забывание — после 45 игровых дней неиспользования.
 *
 * Хранение: EnumMap<SkillType, Double>.
 */
public final class NPCSkills {

    // =========================================================================
    // SkillType — 29 навыков
    // =========================================================================
    public enum SkillType {
        // Базовые 27 (в порядке ТЗ 20.0 §7)
        MINING         ("mining",          "Рудное дело",        "Mining"),
        LUMBERJACKING  ("lumberjacking",   "Лесное дело",        "Lumberjacking"),
        FARMING        ("farming",         "Земледелие",         "Farming"),
        COOKING        ("cooking",         "Кулинария",          "Cooking"),
        SMITHING       ("smithing",        "Кузнечное дело",     "Smithing"),
        CRAFTING       ("crafting",        "Ремесло",            "Crafting"),
        TRADING        ("trading",         "Торговля",           "Trading"),
        ALCHEMY        ("alchemy",         "Зельеварение",       "Alchemy"),
        DEFENSE        ("defense",         "Защита",             "Defense"),
        HUNTING        ("hunting",         "Охота",              "Hunting"),
        SCOUTING       ("scouting",        "Разведка",           "Scouting"),
        MEDICINE       ("medicine",        "Медицина",           "Medicine"),
        ENGINEERING    ("engineering",     "Инженерия",          "Engineering"),
        ANIMAL_HUSBANDRY("animal_husbandry","Животноводство",    "Animal Husbandry"),
        FISHING        ("fishing",         "Рыбалка",            "Fishing"),
        LABOR          ("labor",           "Подсобный труд",     "Labor"),
        BEEKEEPING     ("beekeeping",      "Пчеловодство",       "Beekeeping"),
        BUILDING       ("building",        "Строительство",      "Building"),
        GUARDING       ("guarding",        "Охрана",             "Guarding"),
        GENERAL_LABOR  ("general_labor",   "Простой труд",       "General Labor"),
        CARTOGRAPHY    ("cartography",     "Картография",        "Cartography"),
        PYROTECHNICS   ("pyrotechnics",    "Пиротехника",        "Pyrotechnics"),
        ARCHAEOLOGY    ("archaeology",     "Археология",         "Archaeology"),
        DIPLOMACY      ("diplomacy",       "Дипломатия",         "Diplomacy"),
        CARPENTRY      ("carpentry",       "Плотницкое дело",    "Carpentry"),
        SEAFARING      ("seafaring",       "Мореплавание",       "Seafaring"),
        MAGIC          ("magic",           "Магия",              "Magic"),

        // Новые 2 (ТЗ 20.1 §69)
        STEALTH        ("stealth",         "Скрытые кражи",      "Stealth"),
        LOCKPOCKETING  ("lockpocketing",   "Взлом замков",       "Lockpocketing");

        public final String langKey;
        public final String ruName;
        public final String enName;

        SkillType(String langKey, String ru, String en) {
            this.langKey = langKey;
            this.ruName = ru;
            this.enName = en;
        }
    }

    // =========================================================================
    // Поля
    // =========================================================================
    public static final int MAX_LEVEL = 10;
    public static final int MAX_ACTIVE_SKILLS = 3;
    public static final int FORGET_THRESHOLD_DAYS = 45;

    private final EnumMap<SkillType, Double> levels = new EnumMap<>(SkillType.class);
    /** Последний игровой день, когда NPC использовал навык (для забывания). */
    private final EnumMap<SkillType, Long> lastUsed = new EnumMap<>(SkillType.class);
    /** Предрасположенности (0.5–2.0) — влияют на скорость прокачки. */
    private final EnumMap<SkillType, Double> predispositions = new EnumMap<>(SkillType.class);

    private double intelligence = 1.0; // 0.5–2.0

    // =========================================================================
    // Конструкторы
    // =========================================================================

    public NPCSkills() {
        Random rnd = new Random();
        for (SkillType type : SkillType.values()) {
            // Начальный уровень: 0.0–2.0 случайно
            levels.put(type, rnd.nextDouble() * 2.0);
            // Стартовая предрасположенность: 0.5–1.5
            predispositions.put(type, 0.5 + rnd.nextDouble());
        }
        // Один навык — основной
        SkillType best = getBestSkill();
        levels.put(best, Math.max(levels.get(best), 3.0 + rnd.nextDouble() * 2.0));

        // Устанавливаем «последнее использование» = 0
        for (SkillType type : SkillType.values()) {
            lastUsed.put(type, 0L);
        }
    }

    // =========================================================================
    // Геттеры/сеттеры
    // =========================================================================

    public double getLevel(SkillType type) {
        return levels.getOrDefault(type, 0.0);
    }

    public void setLevel(SkillType type, double level) {
        levels.put(type, clamp(level));
    }

    public double getIntelligence() { return intelligence; }

    public void setIntelligence(double value) {
        this.intelligence = clampRange(value, 0.5, 2.0);
    }

    public double getPredisposition(SkillType type) {
        return predispositions.getOrDefault(type, 1.0);
    }

    public void setPredisposition(SkillType type, double value) {
        predispositions.put(type, clampRange(value, 0.1, 2.0));
    }

    public long getLastUsed(SkillType type) {
        return lastUsed.getOrDefault(type, 0L);
    }

    // =========================================================================
    // Прокачка (ТЗ 20.1 §7.2)
    // =========================================================================

    /**
     * Добавляет опыт к навыку.
     *
     * Формула: XP = base × plateau × intelligence × predisposition.
     * Plateau = max(0.10, 1 в€' 0.09 Г— L).
     *
     * @param type       Навык
     * @param baseXP     Базовая ценность действия (обычно 0.01–0.10)
     * @param currentDay Текущий игровой день (для отметки использования)
     */
    public void addXP(SkillType type, double baseXP, long currentDay) {
        double current = getLevel(type);
        if (current >= MAX_LEVEL) {
            lastUsed.put(type, currentDay);
            return;
        }

        double plateau = Math.max(0.10, 1.0 - 0.09 * current);
        double disposition = getPredisposition(type);
        double newXP = baseXP * plateau * intelligence * disposition;

        levels.put(type, clamp(current + newXP));
        lastUsed.put(type, currentDay);
    }

    /**
     * Упрощённый вызов без дня (для обратной совместимости в прототипах).
     */
    public void addXP(SkillType type, double baseXP) {
        addXP(type, baseXP, 0L);
    }

    /**
     * Множитель скорости работы для навыка.
     * Уровень 0 → 1.0×, уровень 10 → 3.0×.
     */
    public double getWorkSpeedMultiplier(SkillType type) {
        double level = getLevel(type);
        return 1.0 + (level / MAX_LEVEL) * 2.0;
    }

    // =========================================================================
    // Забывание (ТЗ 20.1 §7.3)
    // =========================================================================

    /**
     * Обрабатывает забывание навыков.
     * Вызывается раз в игровой день.
     *
     * @param currentDay Текущий игровой день
     */
    public void processDecay(long currentDay) {
        for (SkillType type : SkillType.values()) {
            double level = getLevel(type);
            if (level >= MAX_LEVEL) continue; // Мастер не забывает

            long last = getLastUsed(type);
            long daysSince = currentDay - last;
            if (daysSince < FORGET_THRESHOLD_DAYS) continue;

            // Скорость забывания по ТЗ 20.1 §7.3
            double decayRate;
            if (daysSince < 60)       decayRate = 0.0500;
            else if (daysSince < 90)  decayRate = 0.0575;
            else if (daysSince < 120) decayRate = 0.0725;
            else if (daysSince < 150) decayRate = 0.0875;
            else                       decayRate = 0.1025;

            // Не более 0.10 уровня за день
            double newLevel = Math.max(0.0, level - Math.min(decayRate, 0.10));
            levels.put(type, newLevel);
        }
    }

    // =========================================================================
    // Утилиты
    // =========================================================================

    public SkillType getBestSkill() {
        SkillType best = SkillType.GENERAL_LABOR;
        double bestVal = -1;
        for (Map.Entry<SkillType, Double> e : levels.entrySet()) {
            if (e.getValue() > bestVal) {
                bestVal = e.getValue();
                best = e.getKey();
            }
        }
        return best;
    }

    /**
     * Возвращает топ-N навыков (по уровню).
     */
    public java.util.List<SkillType> getTopSkills(int n) {
        return levels.entrySet().stream()
            .sorted((a, b) -> Double.compare(b.getValue(), a.getValue()))
            .limit(n)
            .map(Map.Entry::getKey)
            .collect(java.util.stream.Collectors.toList());
    }

    /**
     * Активные навыки — 3 лучших с уровнем > 0.5.
     */
    public java.util.Set<SkillType> getActiveSkills() {
        return new java.util.LinkedHashSet<>(getTopSkills(MAX_ACTIVE_SKILLS));
    }

    public Map<SkillType, Double> getAll() {
        return new EnumMap<>(levels);
    }

    // =========================================================================
    // NBT
    // =========================================================================

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        CompoundTag skillsTag = new CompoundTag();
        for (Map.Entry<SkillType, Double> e : levels.entrySet()) {
            skillsTag.putDouble(e.getKey().langKey, e.getValue());
        }
        tag.put("levels", skillsTag);

        CompoundTag predTag = new CompoundTag();
        for (Map.Entry<SkillType, Double> e : predispositions.entrySet()) {
            predTag.putDouble(e.getKey().langKey, e.getValue());
        }
        tag.put("predispositions", predTag);

        CompoundTag lastTag = new CompoundTag();
        for (Map.Entry<SkillType, Long> e : lastUsed.entrySet()) {
            lastTag.putLong(e.getKey().langKey, e.getValue());
        }
        tag.put("lastUsed", lastTag);

        tag.putDouble("intelligence", intelligence);
        return tag;
    }

    public static NPCSkills load(CompoundTag tag) {
        NPCSkills s = new NPCSkills();
        s.levels.clear();
        s.predispositions.clear();
        s.lastUsed.clear();

        CompoundTag skillsTag = tag.getCompound("levels");
        for (SkillType type : SkillType.values()) {
            s.levels.put(type, skillsTag.contains(type.langKey) ? skillsTag.getDouble(type.langKey) : 0.0);
        }

        CompoundTag predTag = tag.getCompound("predispositions");
        for (SkillType type : SkillType.values()) {
            s.predispositions.put(type,
                predTag.contains(type.langKey) ? predTag.getDouble(type.langKey) : 1.0);
        }

        CompoundTag lastTag = tag.getCompound("lastUsed");
        for (SkillType type : SkillType.values()) {
            s.lastUsed.put(type, lastTag.contains(type.langKey) ? lastTag.getLong(type.langKey) : 0L);
        }

        s.intelligence = tag.contains("intelligence") ? tag.getDouble("intelligence") : 1.0;
        return s;
    }

    // =========================================================================
    // Утилиты
    // =========================================================================

    private static double clamp(double v) {
        return Math.max(0.0, Math.min(MAX_LEVEL, v));
    }

    private static double clampRange(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }
}
