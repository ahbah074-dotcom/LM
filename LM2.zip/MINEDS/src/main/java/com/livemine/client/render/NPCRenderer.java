package com.livemine.client.render;

import com.livemine.LiveMineMod;
import com.livemine.entity.LiveNPCEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

/**
 * Рендерер NPC.
 *
 * Использует модель игрока (HumanoidModel) + броню.
 * Отображает:
 *   - Имя над головой
 *   - Профессию (цветной текст, если есть)
 *
 * Текстуры в assets/livemine/textures/entity/npc/<профессия>.png.
 */
public class NPCRenderer extends HumanoidMobRenderer<LiveNPCEntity, HumanoidModel<LiveNPCEntity>> {

    private static final ResourceLocation DEFAULT_TEXTURE =
        ResourceLocation.fromNamespaceAndPath(LiveMineMod.MOD_ID, "textures/entity/npc/default.png");

    private static final ResourceLocation FARMER_TEXTURE =
        ResourceLocation.fromNamespaceAndPath(LiveMineMod.MOD_ID, "textures/entity/npc/farmer.png");

    private static final ResourceLocation GUARD_TEXTURE =
        ResourceLocation.fromNamespaceAndPath(LiveMineMod.MOD_ID, "textures/entity/npc/guard.png");

    private static final ResourceLocation MERCHANT_TEXTURE =
        ResourceLocation.fromNamespaceAndPath(LiveMineMod.MOD_ID, "textures/entity/npc/merchant.png");

    private static final ResourceLocation MINER_TEXTURE =
        ResourceLocation.fromNamespaceAndPath(LiveMineMod.MOD_ID, "textures/entity/npc/miner.png");

    private static final ResourceLocation PRIEST_TEXTURE =
        ResourceLocation.fromNamespaceAndPath(LiveMineMod.MOD_ID, "textures/entity/npc/priest.png");

    public NPCRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);

        // Слой брони
        this.addLayer(new HumanoidArmorLayer<>(
            this,
            new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
            new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)),
            context.getModelManager()
        ));
    }

    // =========================================================================
    // Текстура
    // =========================================================================

    @Override
    public ResourceLocation getTextureLocation(LiveNPCEntity entity) {
        String profession = entity.getProfessionName();
        if (profession == null || profession.isEmpty()) return DEFAULT_TEXTURE;

        return switch (profession.toLowerCase()) {
            case "farmer", "фермер" -> FARMER_TEXTURE;
            case "guard", "стражник", "страж" -> GUARD_TEXTURE;
            case "merchant", "торговец" -> MERCHANT_TEXTURE;
            case "miner", "шахтёр", "шахтер" -> MINER_TEXTURE;
            case "priest", "жрец", "священник" -> PRIEST_TEXTURE;
            default -> DEFAULT_TEXTURE;
        };
    }

    // =========================================================================
    // Name tag — имя + профессия
    // =========================================================================

    @Override
    protected void renderNameTag(LiveNPCEntity entity, Component displayName,
                                  PoseStack poseStack, MultiBufferSource buffer, int packedLight, float partialTick) {
        // Базовый name tag с именем
        super.renderNameTag(entity, displayName, poseStack, buffer, packedLight, partialTick);

        // Профессия снизу
        String profession = entity.getProfessionName();
        if (profession != null && !profession.isEmpty()) {
            poseStack.pushPose();
            poseStack.translate(0.0, 0.3, 0.0);
            Component profComponent = Component.literal(profession)
                .withStyle(style -> style.withColor(getProfessionColor(profession)));
            super.renderNameTag(entity, profComponent, poseStack, buffer, packedLight, partialTick);
            poseStack.popPose();
        }
    }

    private static int getProfessionColor(String profession) {
        return switch (profession.toLowerCase()) {
            case "farmer", "фермер" -> 0x55FF55;
            case "miner", "шахтёр", "шахтер" -> 0xAAAAAA;
            case "blacksmith", "кузнец" -> 0xFF8800;
            case "guard", "стражник", "страж" -> 0xFF5555;
            case "healer", "лекарь", "медик" -> 0xFF55FF;
            case "trader", "торговец", "merchant" -> 0xFFFF55;
            case "fisherman", "рыбак" -> 0x55FFFF;
            case "priest", "жрец" -> 0xAA55FF;
            default -> 0xFFFFFF;
        };
    }

    @Override
    protected boolean shouldShowName(LiveNPCEntity entity) {
        return true;
    }
}
