package com.livemine.client;

import com.livemine.LiveMineMod;
import com.livemine.client.guide.GuideOpenHandler;
import com.livemine.client.render.GraveStoneRenderer;
import com.livemine.client.render.NPCRenderer;
import com.livemine.registry.ModEntities;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;

/**
 * Клиентская инициализация мода.
 *
 * 1.21.1: убран bus = ... (deprecated).
 */
@OnlyIn(Dist.CLIENT)
@EventBusSubscriber(modid = LiveMineMod.MOD_ID, value = Dist.CLIENT)
public final class ClientSetup {

    private ClientSetup() {}

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            LiveMineMod.LOGGER.info("LiveMine: client setup complete");
            com.livemine.client.VillageClientCacheStorage.init();
        });
    }

    @SubscribeEvent
    public static void onRegisterKeys(RegisterKeyMappingsEvent event) {
        GuideOpenHandler.registerKey(event);
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(
            ModEntities.LIVE_NPC.get(),
            NPCRenderer::new
        );
        event.registerEntityRenderer(
            ModEntities.GRAVE_STONE.get(),
            GraveStoneRenderer::new
        );
    }
}