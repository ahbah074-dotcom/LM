package com.livemine.client.gui;

import com.livemine.network.MarketStallBuyPacket;
import com.livemine.network.MarketStallSyncPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Простой экран торговой лавки.
 *
 * Список лотов + кнопка "Купить" на каждой строке.
 * Покупка → MarketStallBuyPacket → сервер.
 */
public class MarketStallScreen extends Screen {

    private static final int PANEL_WIDTH = 380;
    private static final int PANEL_MARGIN_TOP = 30;
    private static final int PANEL_MARGIN_BOTTOM = 40;
    private static final int ROW_HEIGHT = 28;

    private final BlockPos pos;
    private final List<MarketStallSyncPacket.TradeView> trades;
    private final List<Button> buyButtons = new ArrayList<>();

    public MarketStallScreen(BlockPos pos, List<MarketStallSyncPacket.TradeView> trades) {
        super(Component.literal("Торговая лавка"));
        this.pos = pos;
        this.trades = new ArrayList<>(trades);
    }

    public static void open(BlockPos pos, List<MarketStallSyncPacket.TradeView> trades) {
        Minecraft.getInstance().setScreen(new MarketStallScreen(pos, trades));
    }

    @Override
    protected void init() {
        buyButtons.clear();

        int panelX = this.width / 2 - PANEL_WIDTH / 2;
        int panelY = PANEL_MARGIN_TOP;
        int listStartY = panelY + 40;

        for (int i = 0; i < trades.size(); i++) {
            final int idx = i;
            MarketStallSyncPacket.TradeView t = trades.get(i);
            int y = listStartY + i * ROW_HEIGHT;

            Button btn = Button.builder(
                Component.literal("Купить"),
                b -> {
                    MarketStallBuyPacket.send(pos, idx);
                    this.onClose();
                }
            ).bounds(
                panelX + PANEL_WIDTH - 90,
                y + 4,
                80, 20
            ).build();

            if (t.stock <= 0) {
                btn.active = false;
            }

            addRenderableWidget(btn);
            buyButtons.add(btn);
        }

        addRenderableWidget(Button.builder(
            Component.literal("Закрыть"),
            b -> this.onClose()
        ).bounds(
            this.width / 2 - 50,
            this.height - PANEL_MARGIN_BOTTOM + 5,
            100, 24
        ).build());
    }

    @Override
    public void renderBackground(GuiGraphics gfx, int mouseX, int mouseY, float partialTick) {
        // Отключаем blur.
    }

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float partialTick) {
        gfx.fill(0, 0, this.width, this.height, 0xC0000000);

        int panelX = this.width / 2 - PANEL_WIDTH / 2;
        int panelY = PANEL_MARGIN_TOP;
        int panelH = this.height - PANEL_MARGIN_TOP - PANEL_MARGIN_BOTTOM;

        // Панель
        gfx.fill(panelX + 4, panelY + 4, panelX + PANEL_WIDTH + 4, panelY + panelH + 4, 0x80000000);
        gfx.fill(panelX, panelY, panelX + PANEL_WIDTH, panelY + panelH, 0xF0101018);
        gfx.renderOutline(panelX, panelY, PANEL_WIDTH, panelH, 0xFFAA8833);

        // Заголовок
        gfx.drawCenteredString(this.font,
            Component.literal("§6§lТорговая лавка"),
            this.width / 2, panelY + 12, 0xFFD700);

        // Разделитель
        gfx.fill(panelX + 10, panelY + 32, panelX + PANEL_WIDTH - 10, panelY + 33, 0xFF664422);

        if (trades.isEmpty()) {
            gfx.drawCenteredString(this.font,
                Component.literal("§7Лавка пуста"),
                this.width / 2, panelY + 60, 0xAAAAAA);
        } else {
            int listStartY = panelY + 40;
            for (int i = 0; i < trades.size(); i++) {
                MarketStallSyncPacket.TradeView t = trades.get(i);
                int y = listStartY + i * ROW_HEIGHT;

                // Строка
                gfx.fill(panelX + 8, y, panelX + PANEL_WIDTH - 8, y + ROW_HEIGHT - 2, 0x40000000);

                // Текст: "Nx Offer за Mx Price"
                String line = "§f" + t.offerCount + "x §e" + t.offerName
                    + " §7за §f" + t.priceCount + "x §e" + t.priceName;

                gfx.drawString(this.font, line, panelX + 16, y + 8, 0xFFFFFF, false);

                // Stock
                String stockStr = "§7(§a" + t.stock + "§7)";
                gfx.drawString(this.font, stockStr, panelX + PANEL_WIDTH - 200, y + 8, 0xAAAAAA, false);
            }
        }

        super.render(gfx, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}