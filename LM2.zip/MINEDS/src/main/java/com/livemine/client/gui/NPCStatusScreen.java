package com.livemine.client.gui;

import com.livemine.network.NPCInteractionPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

import java.util.List;

/**
 * GUI статуса NPC.
 *
 * v3.0: единое окно с тремя секциями:
 *   1. Статус (полоски здоровья, голода, энергии, социума).
 *   2. Диалог (реплика NPC по контексту).
 *   3. Квест (если предложен) + кнопки [Принять] [Отклонить].
 *
 * Управление: ESC или кнопка "Закрыть".
 * ПКМ по NPC → сервер отправляет NPCStatePacket → этот экран.
 */
public class NPCStatusScreen extends Screen {

    // Панель
    private static final int PANEL_WIDTH = 340;
    private static final int PANEL_MARGIN_TOP = 20;
    private static final int PANEL_MARGIN_BOTTOM = 50;

    // Полоски
    private static final int BAR_WIDTH = 200;
    private static final int BAR_HEIGHT = 10;
    private static final int BAR_SPACING = 14;

    // Цвета
    private static final int COLOR_HEALTH = 0xFFFF5555;
    private static final int COLOR_HUNGER = 0xFFFFAA00;
    private static final int COLOR_ENERGY = 0xFF55FF55;
    private static final int COLOR_SOCIAL = 0xFF5555FF;
    private static final int COLOR_BG_BAR = 0x80000000;
    private static final int COLOR_BORDER = 0xFF888888;
    private static final int COLOR_TEXT = 0xFFFFFFFF;
    private static final int COLOR_HEADER = 0xFFFFD700;
    private static final int COLOR_DIALOG = 0xFFFFEEAA;
    private static final int COLOR_QUEST = 0xFFAADDAA;

    // Поля
    private final int entityId;
    private final String name;
    private final String profession;
    private final double hunger;
    private final double energy;
    private final double health;
    private final double social;
    private final String currentGoal;
    private final String villageRawId;

    private final String dialogText;

    private final String questId;
    private final String questType;
    private final String questDescription;
    private final int questReward;
    private final int questTargetAmount;
    private final int questCurrentAmount;

    // =========================================================================
    // Конструктор
    // =========================================================================

    public NPCStatusScreen(int entityId, String name, String profession,
                           double hunger, double energy, double health, double social,
                           String currentGoal, String villageRawId,
                           String dialogText,
                           String questId, String questType, String questDescription,
                           int questReward, int questTargetAmount, int questCurrentAmount) {
        super(Component.literal("NPC Status"));
        this.entityId = entityId;
        this.name = name != null ? name : "NPC";
        this.profession = profession;
        this.hunger = hunger;
        this.energy = energy;
        this.health = health;
        this.social = social;
        this.currentGoal = currentGoal;
        this.villageRawId = villageRawId;
        this.dialogText = dialogText;
        this.questId = questId;
        this.questType = questType;
        this.questDescription = questDescription;
        this.questReward = questReward;
        this.questTargetAmount = questTargetAmount;
        this.questCurrentAmount = questCurrentAmount;
    }

    public static void open(int entityId, String name, String profession,
                            double hunger, double energy, double health, double social,
                            String currentGoal, String villageRawId,
                            String dialogText,
                            String questId, String questType, String questDescription,
                            int questReward, int questTargetAmount, int questCurrentAmount) {
        Minecraft.getInstance().setScreen(new NPCStatusScreen(
            entityId, name, profession, hunger, energy, health, social,
            currentGoal, villageRawId, dialogText,
            questId, questType, questDescription,
            questReward, questTargetAmount, questCurrentAmount
        ));
    }

    // =========================================================================
    // Инициализация кнопок
    // =========================================================================

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height - 38;

        boolean hasQuest = questId != null && !questId.isEmpty();

        if (hasQuest) {
            // Принять
            addRenderableWidget(Button.builder(
                Component.literal("Принять"),
                b -> {
                    NPCInteractionPayload.send(entityId,
                        NPCInteractionPayload.Action.ACCEPT_QUEST, questId);
                    this.onClose();
                }
            ).bounds(cx - 155, y, 90, 24).build());

            // Отклонить
            addRenderableWidget(Button.builder(
                Component.literal("Отклонить"),
                b -> {
                    NPCInteractionPayload.send(entityId,
                        NPCInteractionPayload.Action.DECLINE_QUEST, questId);
                    this.onClose();
                }
            ).bounds(cx - 60, y, 90, 24).build());

            // Обновить
            addRenderableWidget(Button.builder(
                Component.literal("Обновить"),
                b -> {
                    NPCInteractionPayload.send(entityId,
                        NPCInteractionPayload.Action.REFRESH, "");
                }
            ).bounds(cx + 35, y, 90, 24).build());
        } else {
            // Только "Закрыть"
            addRenderableWidget(Button.builder(
                Component.literal("Закрыть"),
                b -> this.onClose()
            ).bounds(cx - 50, y, 100, 24).build());
        }
    }

    // =========================================================================
    // Отключаем blur
    // =========================================================================

    @Override
    public void renderBackground(GuiGraphics gfx, int mouseX, int mouseY, float partialTick) {
        // Отключаем blur — рисуем свой фон в render().
    }

    // =========================================================================
    // Рендер
    // =========================================================================

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float partialTick) {
        // Плотное затемнение
        gfx.fill(0, 0, this.width, this.height, 0xC0000000);

        int cx = this.width / 2;
        int panelX = cx - PANEL_WIDTH / 2;
        int panelY = PANEL_MARGIN_TOP;
        int panelH = this.height - PANEL_MARGIN_TOP - PANEL_MARGIN_BOTTOM;

        // Панель
        gfx.fill(panelX + 4, panelY + 4, panelX + PANEL_WIDTH + 4, panelY + panelH + 4, 0x80000000);
        gfx.fill(panelX, panelY, panelX + PANEL_WIDTH, panelY + panelH, 0xF0101018);
        gfx.renderOutline(panelX, panelY, PANEL_WIDTH, panelH, 0xFFAA8833);
        gfx.renderOutline(panelX + 1, panelY + 1, PANEL_WIDTH - 2, panelH - 2, 0xFF443311);

        int contentX = panelX + 14;
        int contentW = PANEL_WIDTH - 28;
        int y = panelY + 12;

        // --- Заголовок ---
        gfx.drawCenteredString(this.font,
            Component.literal("§6§l" + name),
            cx, y, COLOR_HEADER);
        y += 14;

        if (profession != null && !profession.isEmpty()) {
            gfx.drawCenteredString(this.font,
                Component.literal("§7" + profession),
                cx, y, 0xAAAAAA);
            y += 12;
        }

        if (villageRawId != null && !villageRawId.isEmpty()) {
            String shortV = villageRawId.length() > 24
                ? villageRawId.substring(0, 24) + "…"
                : villageRawId;
            gfx.drawCenteredString(this.font,
                Component.literal("§8village: " + shortV),
                cx, y, 0x777777);
            y += 12;
        }

        // Разделитель
        y += 4;
        gfx.fill(panelX + 10, y, panelX + PANEL_WIDTH - 10, y + 1, 0xFF664422);
        y += 6;

        // --- Секция 1: Статус ---
        gfx.drawString(this.font, "§7§lСтатус", contentX, y, 0xFFFFFF, false);
        y += 12;

        gfx.drawString(this.font, "§7Цель: §f" + getGoalRu(currentGoal),
            contentX, y, COLOR_TEXT, false);
        y += 12;

        drawBar(gfx, contentX, y, "Здоровье", health, 20, COLOR_HEALTH);
        y += BAR_SPACING;
        drawBar(gfx, contentX, y, "Голод", hunger, 100, COLOR_HUNGER);
        y += BAR_SPACING;
        drawBar(gfx, contentX, y, "Энергия", energy, 100, COLOR_ENERGY);
        y += BAR_SPACING;
        drawBar(gfx, contentX, y, "Социум", social, 100, COLOR_SOCIAL);
        y += BAR_SPACING + 6;

        // --- Секция 2: Диалог ---
        gfx.fill(panelX + 10, y, panelX + PANEL_WIDTH - 10, y + 1, 0xFF664422);
        y += 6;
        gfx.drawString(this.font, "§7§lДиалог", contentX, y, 0xFFFFFF, false);
        y += 12;

        if (dialogText != null && !dialogText.isEmpty()) {
            List<FormattedCharSequence> lines = this.font.split(
                Component.literal("§e« " + dialogText + " »"), contentW);
            for (FormattedCharSequence line : lines) {
                gfx.drawString(this.font, line, contentX, y, COLOR_DIALOG, false);
                y += 11;
            }
        } else {
            gfx.drawString(this.font, "§7...", contentX, y, 0x777777, false);
            y += 11;
        }
        y += 4;

        // --- Секция 3: Квест ---
        boolean hasQuest = questId != null && !questId.isEmpty();
        if (hasQuest) {
            gfx.fill(panelX + 10, y, panelX + PANEL_WIDTH - 10, y + 1, 0xFF664422);
            y += 6;
            gfx.drawString(this.font, "§7§lЗадание", contentX, y, 0xFFFFFF, false);
            y += 12;

            gfx.drawString(this.font, "§a" + questType, contentX, y, COLOR_QUEST, false);
            y += 11;

            if (questDescription != null && !questDescription.isEmpty()) {
                List<FormattedCharSequence> lines = this.font.split(
                    Component.literal("§f" + questDescription), contentW);
                for (FormattedCharSequence line : lines) {
                    gfx.drawString(this.font, line, contentX, y, 0xFFFFFF, false);
                    y += 11;
                }
            }

            if (questTargetAmount > 0) {
                gfx.drawString(this.font,
                    "§7Прогресс: §f" + questCurrentAmount + "§7/§f" + questTargetAmount,
                    contentX, y, 0xFFFFFF, false);
                y += 11;
            }

            gfx.drawString(this.font, "§7Награда: §e+" + questReward + " репутации",
                contentX, y, 0xFFFFFF, false);
        }

        // Рендер кнопок
        super.render(gfx, mouseX, mouseY, partialTick);
    }

    // =========================================================================
    // Полоса
    // =========================================================================

    private void drawBar(GuiGraphics gfx, int x, int y, String label,
                         double value, double max, int color) {
        gfx.drawString(this.font, label + ": " + (int) value + "/" + (int) max,
            x, y, COLOR_TEXT, false);

        int barX = x + 80;
        gfx.fill(barX, y + 1, barX + BAR_WIDTH, y + 1 + BAR_HEIGHT, COLOR_BG_BAR);

        int fillWidth = max > 0
            ? (int) (BAR_WIDTH * Math.min(1.0, Math.max(0, value / max)))
            : 0;
        if (fillWidth > 0) {
            gfx.fill(barX, y + 1, barX + fillWidth, y + 1 + BAR_HEIGHT,
                0xFF000000 | color);
        }

        gfx.renderOutline(barX, y + 1, BAR_WIDTH, BAR_HEIGHT, COLOR_BORDER);
    }

    // =========================================================================
    // Утилиты
    // =========================================================================

    private static String getGoalRu(String goal) {
        if (goal == null) return "Неизвестно";
        return switch (goal.toUpperCase()) {
            case "WORK" -> "Работает";
            case "REST" -> "Отдыхает";
            case "HEALING", "HEAL" -> "Лечится";
            case "SOCIAL", "SOCIALIZE" -> "Общается";
            case "WANDER" -> "Бродит";
            case "FOOD", "EAT" -> "Ест";
            case "SURVIVAL" -> "Выживает";
            case "SAFETY" -> "Осторожничает";
            case "COMBAT" -> "Сражается";
            case "FLEE" -> "Убегает";
            case "LEARNING" -> "Учится";
            case "FAMILY" -> "С семьёй";
            case "ENTERTAINMENT" -> "Развлекается";
            case "COLLECTIVE" -> "На общих работах";
            case "BUILD" -> "Строит";
            default -> goal;
        };
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}