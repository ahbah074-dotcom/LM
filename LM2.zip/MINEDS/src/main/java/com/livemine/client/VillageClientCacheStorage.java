package com.livemine.client;

import com.livemine.network.VillageClientCache;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Клиентский кэш деревень (ТЗ 20.1 §76).
 *
 * Хранит последние полученные пакеты VillageClientCache.
 * Используется клиентскими GUI для отображения деревни.
 *
 * Экономия: 1 пакет на деревню вместо N пакетов на N NPC.
 * При 30 NPC в деревне — 1 пакет вместо 30.
 */
@OnlyIn(Dist.CLIENT)
public final class VillageClientCacheStorage {

    private static final Map<UUID, VillageClientCache> cache = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> lastUpdateTime = new ConcurrentHashMap<>();

    /** Время жизни записи в кэше (10 минут). */
    private static final long TTL_MILLIS = 10 * 60 * 1000L;

    private VillageClientCacheStorage() {}

    // =========================================================================
    // Инициализация
    // =========================================================================

    public static void init() {
        cache.clear();
        lastUpdateTime.clear();
    }

    // =========================================================================
    // Запись
    // =========================================================================

    public static void put(VillageClientCache packet) {
        if (packet == null || packet.getVillageId() == null) return;
        cache.put(packet.getVillageId(), packet);
        lastUpdateTime.put(packet.getVillageId(), System.currentTimeMillis());
    }

    // =========================================================================
    // Чтение
    // =========================================================================

    public static VillageClientCache get(UUID villageId) {
        if (villageId == null) return null;
        expireIfOld(villageId);
        return cache.get(villageId);
    }

    public static Map<UUID, VillageClientCache> getAll() {
        expireAll();
        return Collections.unmodifiableMap(cache);
    }

    public static Collection<VillageClientCache> getValues() {
        return getAll().values();
    }

    public static int size() {
        return cache.size();
    }

    // =========================================================================
    // Очистка
    // =========================================================================

    public static void clear() {
        cache.clear();
        lastUpdateTime.clear();
    }

    public static void remove(UUID villageId) {
        cache.remove(villageId);
        lastUpdateTime.remove(villageId);
    }

    // =========================================================================
    // TTL
    // =========================================================================

    private static void expireIfOld(UUID villageId) {
        Long t = lastUpdateTime.get(villageId);
        if (t == null) return;
        if (System.currentTimeMillis() - t > TTL_MILLIS) {
            cache.remove(villageId);
            lastUpdateTime.remove(villageId);
        }
    }

    private static void expireAll() {
        long now = System.currentTimeMillis();
        cache.keySet().removeIf(id -> {
            Long t = lastUpdateTime.get(id);
            return t != null && now - t > TTL_MILLIS;
        });
    }
}
