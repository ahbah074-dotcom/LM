package com.livemine.client.gui;

import com.livemine.VillageManager;
import com.livemine.domain.VillageRecord;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Экран списка деревень с кнопкой [TP] для каждой.
 */
public class VillageListScreen extends Screen {

    private static final int ROW_HEIGHT = 28;
    private static final int PANEL_WIDTH = 400;

    public VillageListScreen() {
        super(Component.literal("Деревни LiveMine"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int panelX = cx - PANEL_WIDTH / 2;
        int y = 60;

        List<VillageRecord> villages = new ArrayList<>(
            VillageManager.getInstance().getAllVillages());

        for (VillageRecord v : villages) {
            final String name = v.name();
            final int x = v.centerX();
            final int py = v.centerY();
            final int z = v.centerZ();

            Button tpBtn = Button.builder(
                Component.literal("§aTP"),
                b -> {
                    sendChat("/tp @s " + x + " " + (py + 2) + " " + z);
                    this.onClose();
                }
            ).bounds(panelX + PANEL_WIDTH - 80, y + 3, 60, 20).build();

            addRenderableWidget(tpBtn);
            y += ROW_HEIGHT;
        }

        addRenderableWidget(Button.builder(
            Component.literal("Назад"),
            b -> Minecraft.getInstance().setScreen(new AdminMenuScreen())
        ).bounds(cx - 50, this.height - 32, 100, 20).build());
    }

    @Override
    public void renderBackground(GuiGraphics gfx, int mouseX, int mouseY, float partialTick) {}

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float partialTick) {
        gfx.fill(0, 0, this.width, this.height, 0xC0000000);

        int cx = this.width / 2;
        gfx.drawCenteredString(this.font,
            Component.literal("§6§lДеревни"), cx, 30, 0xFFD700);

        int panelX = cx - PANEL_WIDTH / 2;
        int y = 60;

        List<VillageRecord> villages = new ArrayList<>(
            VillageManager.getInstance().getAllVillages());

        for (VillageRecord v : villages) {
            gfx.drawString(this.font,
                "§f" + v.name() + " §7[" + v.population() + " жит.]", 
                panelX, y + 8, 0xFFFFFF, false);
            gfx.drawString(this.font,
                "§8X:" + v.centerX() + " Y:" + v.centerY() + " Z:" + v.centerZ(),
                panelX, y + 18, 0x888888, false);
            y += ROW_HEIGHT;
        }

        super.render(gfx, mouseX, mouseY, partialTick);
    }

    private void sendChat(String command) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.getConnection() != null) {
            String cmd = command.startsWith("/") ? command.substring(1) : command;
            mc.getConnection().sendCommand(cmd);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}