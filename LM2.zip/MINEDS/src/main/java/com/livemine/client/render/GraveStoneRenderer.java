package com.livemine.client.render;

import com.livemine.LiveMineMod;
import com.livemine.entity.GraveStoneEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

/**
 * Рендер надгробия.
 *
 * 1.21.1: renderNameTag принимает 6 аргументов (с partialTick).
 * getDisplayName() переименован в getGraveDisplayName().
 */
public class GraveStoneRenderer extends EntityRenderer<GraveStoneEntity> {

    private static final ResourceLocation TEXTURE =
        ResourceLocation.fromNamespaceAndPath(LiveMineMod.MOD_ID, "textures/entity/grave_stone.png");

    public GraveStoneRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.4f;
        this.shadowStrength = 0.5f;
    }

    @Override
    public ResourceLocation getTextureLocation(GraveStoneEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(GraveStoneEntity entity, float entityYaw, float partialTick,
                       PoseStack poseStack, MultiBufferSource buffer, int packedLight) {

        if (!entity.getNpcName().isEmpty()) {
            String displayName = entity.getGraveDisplayName();

            poseStack.pushPose();
            poseStack.translate(0.0, 1.2, 0.0);
            poseStack.scale(1.0f, 1.0f, 1.0f);

            super.renderNameTag(
                entity,
                Component.literal("§7" + displayName),
                poseStack,
                buffer,
                packedLight,
                partialTick
            );

            if (!entity.getLifeDescription().isEmpty()) {
                poseStack.translate(0.0, -0.3, 0.0);
                poseStack.scale(0.7f, 0.7f, 0.7f);
                super.renderNameTag(
                    entity,
                    Component.literal("§8" + truncate(entity.getLifeDescription(), 40)),
                    poseStack,
                    buffer,
                    packedLight,
                    partialTick
                );
            }
            poseStack.popPose();
        }

        super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
    }

    @Override
    protected boolean shouldShowName(GraveStoneEntity entity) {
        return !entity.getNpcName().isEmpty();
    }

    private static String truncate(String s, int max) {
        if (s.length() <= max) return s;
        return s.substring(0, max - 1) + "…";
    }
}