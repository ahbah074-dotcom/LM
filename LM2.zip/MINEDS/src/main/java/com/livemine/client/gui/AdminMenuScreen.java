package com.livemine.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Админ-меню (F10).
 *
 * Кнопки:
 *   - Список деревень (→ VillageListScreen)
 *   - Список NPC
 *   - Профиль (stats)
 *   - Хроника
 *   - Память
 *   - Экономика
 *   - Достижения
 *   - Репутация
 *   - Сохранить
 *   - Перезагрузить конфиг
 *   - Debug
 *   - Закрыть
 */
public class AdminMenuScreen extends Screen {

    private static final int PANEL_WIDTH = 280;
    private static final int ROW_HEIGHT = 24;

    public AdminMenuScreen() {
        super(Component.literal("LiveMine — Админ-меню"));
    }

    public static void open() {
        Minecraft.getInstance().setScreen(new AdminMenuScreen());
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int panelX = cx - PANEL_WIDTH / 2;
        int y = 50;

        addBtn(panelX, y, "Посмотреть деревни", () -> {
            this.onClose();
            Minecraft.getInstance().setScreen(new VillageListScreen());
        });
        y += ROW_HEIGHT;

        addBtn(panelX, y, "Список NPC", () -> {
            this.onClose();
            sendChat("/lm npc list");
        });
        y += ROW_HEIGHT;

        addBtn(panelX, y, "Профиль (TPS)", () -> {
            sendChat("/lm stats");
            sendChat("/lm debug ticks");
        });
        y += ROW_HEIGHT;

        addBtn(panelX, y, "Экономика", () -> sendChat("/lm economy prices"));
        y += ROW_HEIGHT;

        addBtn(panelX, y, "Достижения", () -> sendChat("/lm achievement list"));
        y += ROW_HEIGHT;

        addBtn(panelX, y, "Репутация", () -> sendChat("/lm reputation get"));
        y += ROW_HEIGHT;

        addBtn(panelX, y, "Дипломатия", () -> sendChat("/lm diplomacy status"));
        y += ROW_HEIGHT;

        addBtn(panelX, y, "Собственность", () -> sendChat("/lm property list"));
        y += ROW_HEIGHT;

        y += 8;

        addBtn(panelX, y, "Сохранить данные", () -> sendChat("/lm save"));
        y += ROW_HEIGHT;

        addBtn(panelX, y, "Перезагрузить конфиг", () -> sendChat("/lm reload"));
        y += ROW_HEIGHT;

        addBtn(panelX, y, "Очистить кэш", () -> sendChat("/lm cache clear"));
        y += ROW_HEIGHT;

        y += 8;

        addBtn(panelX, y, "Закрыть", this::onClose);
    }

    private void addBtn(int x, int y, String label, Runnable action) {
        addRenderableWidget(Button.builder(
            Component.literal(label),
            b -> action.run()
        ).bounds(x, y, PANEL_WIDTH, 20).build());
    }

    private void sendChat(String command) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.getConnection() != null) {
            String cmd = command.startsWith("/") ? command.substring(1) : command;
            mc.getConnection().sendCommand(cmd);
        }
    }

    @Override
    public void renderBackground(GuiGraphics gfx, int mouseX, int mouseY, float partialTick) {
        // Отключаем blur
    }

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float partialTick) {
        gfx.fill(0, 0, this.width, this.height, 0xC0000000);

        int cx = this.width / 2;
        gfx.drawCenteredString(this.font,
            Component.literal("§6§lLiveMine — Админ-меню"),
            cx, 20, 0xFFD700);

        super.render(gfx, mouseX, mouseY, partialTick);

        gfx.drawCenteredString(this.font,
            Component.literal("§7Нажмите §eF10§7 в любой момент"),
            cx, this.height - 20, 0xAAAAAA);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}