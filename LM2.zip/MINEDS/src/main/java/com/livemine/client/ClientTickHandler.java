package com.livemine.client;

import com.livemine.LiveMineConfig;
import com.livemine.client.guide.GuideOpenHandler;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * Клиентский тик-хендлер.
 *
 * v2.1: убран bus = GAME (deprecated в NeoForge 21.1.x).
 */
@OnlyIn(Dist.CLIENT)
@EventBusSubscriber(modid = "livemine", value = Dist.CLIENT)
public final class ClientTickHandler {

    private static boolean firstJoinChecked = false;

    private ClientTickHandler() {}

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        if (!firstJoinChecked) {
            firstJoinChecked = true;
            if (LiveMineConfig.COMMON.showGuideOnFirstJoin.get()) {
                GuideOpenHandler.openGuide();
            }
        }
    }

    public static void reset() {
        firstJoinChecked = false;
    }
}