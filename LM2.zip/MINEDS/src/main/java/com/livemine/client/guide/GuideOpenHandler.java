package com.livemine.client.guide;

import com.livemine.client.gui.AdminMenuScreen;
import com.livemine.client.gui.InGameGuideScreen;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import org.lwjgl.glfw.GLFW;

/**
 * Обработчик клавиш G (справочник) и F10 (админ-меню).
 */
public final class GuideOpenHandler {

    public static final String KEY_CATEGORY = "key.categories.livemine";
    public static final String KEY_NAME = "key.livemine.guide";
    public static final String KEY_ADMIN = "key.livemine.admin";

    public static KeyMapping GUIDE_KEY;
    public static KeyMapping ADMIN_KEY;

    private GuideOpenHandler() {}

    public static void registerKey(RegisterKeyMappingsEvent event) {
        GUIDE_KEY = new KeyMapping(
            KEY_NAME,
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_G,
            KEY_CATEGORY
        );
        event.register(GUIDE_KEY);

        ADMIN_KEY = new KeyMapping(
            KEY_ADMIN,
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_F10,
            KEY_CATEGORY
        );
        event.register(ADMIN_KEY);
    }

    public static void openGuide() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        mc.setScreen(new InGameGuideScreen());
    }

    public static void openAdminMenu() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        mc.setScreen(new AdminMenuScreen());
    }
}