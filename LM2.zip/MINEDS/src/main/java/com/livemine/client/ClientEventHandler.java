package com.livemine.client;

import com.livemine.LiveMineMod;
import com.livemine.client.guide.GuideOpenHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Клиентский обработчик событий.
 *
 * v2.2: убран onMouseInput. ПКМ по NPC обрабатывается в LiveNPCEntity.mobInteract
 * на сервере — сервер сам отправляет NPCStatePacket.
 */
@OnlyIn(Dist.CLIENT)
@EventBusSubscriber(modid = LiveMineMod.MOD_ID, value = Dist.CLIENT)
public final class ClientEventHandler {

    private ClientEventHandler() {}

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        while (GuideOpenHandler.GUIDE_KEY.consumeClick()) {
            GuideOpenHandler.openGuide();
        }
        while (GuideOpenHandler.ADMIN_KEY.consumeClick()) {
            GuideOpenHandler.openAdminMenu();
        }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) {
            return;
        }

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        for (Entity entity : mc.level.entitiesForRendering()) {
            if (!(entity instanceof com.livemine.entity.LiveNPCEntity)) continue;
            // TODO: рендер полосок потребностей над NPC
        }
    }
}