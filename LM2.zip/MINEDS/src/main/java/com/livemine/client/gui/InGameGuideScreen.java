package com.livemine.client.gui;

import com.livemine.client.guide.GuideContent;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

/**
 * Экран внутриигрового справочника.
 *
 * v2.0: убран blur-фон; плотная тёмная панель с золотой рамкой;
 * контрастный текст; кнопки листания.
 */
public class InGameGuideScreen extends Screen {

    private static final int PANEL_WIDTH = 440;
    private static final int PANEL_MARGIN_TOP = 20;
    private static final int PANEL_MARGIN_BOTTOM = 50;

    private int currentPage;
    private int scrollOffset;
    private final List<GuideContent.GuidePage> pages;

    public InGameGuideScreen() {
        super(Component.literal("LiveMine — Справочник"));
        this.pages = GuideContent.getPages();
    }

    // =========================================================================
    // Init
    // =========================================================================

    @Override
    protected void init() {
        int cx = this.width / 2;

        // Кнопка "Назад"
        addRenderableWidget(Button.builder(
            Component.literal("←"),
            b -> { if (currentPage > 0) { currentPage--; scrollOffset = 0; } }
        ).bounds(cx - 110, this.height - 38, 30, 24).build());

        // Кнопка "Вперёд"
        addRenderableWidget(Button.builder(
            Component.literal("→"),
            b -> { if (currentPage < pages.size() - 1) { currentPage++; scrollOffset = 0; } }
        ).bounds(cx + 80, this.height - 38, 30, 24).build());

        // Кнопка "Закрыть"
        addRenderableWidget(Button.builder(
            Component.literal("Закрыть"),
            b -> this.onClose()
        ).bounds(cx - 50, this.height - 38, 100, 24).build());
    }

    // =========================================================================
    // Background — отключаем blur и штатный фон
    // =========================================================================

    @Override
    public void renderBackground(GuiGraphics gfx, int mouseX, int mouseY, float partialTick) {
        // Намеренно пусто: рисуем свой фон в render().
        // Это отключает blur и стандартный градиент.
    }

    // =========================================================================
    // Render
    // =========================================================================

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float partialTick) {
        // 1. Плотное затемнение всего экрана
        gfx.fill(0, 0, this.width, this.height, 0xC0000000);

        if (pages.isEmpty()) {
            super.render(gfx, mouseX, mouseY, partialTick);
            return;
        }

        if (currentPage >= pages.size()) currentPage = pages.size() - 1;
        if (currentPage < 0) currentPage = 0;

        GuideContent.GuidePage page = pages.get(currentPage);

        // 2. Панель справочника
        int panelX = this.width / 2 - PANEL_WIDTH / 2;
        int panelY = PANEL_MARGIN_TOP;
        int panelH = this.height - PANEL_MARGIN_TOP - PANEL_MARGIN_BOTTOM;

        // Тень под панелью
        gfx.fill(panelX + 4, panelY + 4, panelX + PANEL_WIDTH + 4, panelY + panelH + 4, 0x80000000);
        // Тело панели — почти чёрный, не прозрачный
        gfx.fill(panelX, panelY, panelX + PANEL_WIDTH, panelY + panelH, 0xF0101018);
        // Рамка
        gfx.renderOutline(panelX, panelY, PANEL_WIDTH, panelH, 0xFFAA8833);
        gfx.renderOutline(panelX + 1, panelY + 1, PANEL_WIDTH - 2, panelH - 2, 0xFF443311);

        int contentX = panelX + 20;
        int contentW = PANEL_WIDTH - 40;
        int y = panelY + 14;

        // 3. Заголовок
        gfx.drawCenteredString(this.font,
            Component.literal("§6§l" + page.title),
            this.width / 2, y, 0xFFD700);
        y += 16;

        // Разделитель
        gfx.fill(panelX + 10, y, panelX + PANEL_WIDTH - 10, y + 1, 0xFF664422);
        y += 10;

        // 4. Строки контента с клиппингом по панели
        int contentTop = y;
        int contentBottom = panelY + panelH - 30;
        int lineH = 11;

        for (String line : page.lines) {
            if (y >= contentTop - scrollOffset && y <= contentBottom + lineH) {
                int drawY = y - scrollOffset;
                if (drawY >= contentTop - lineH && drawY <= contentBottom) {
                    // Полупрозрачный фон за строкой для читаемости
                    gfx.fill(contentX - 2, drawY - 1, contentX + contentW + 2, drawY + lineH - 1, 0x30000000);
                    gfx.drawString(this.font, line, contentX, drawY, 0xFFFFFF, false);
                }
            }
            y += lineH;
            if (y - scrollOffset > contentBottom + 100) break;
        }

        // 5. Индикатор страницы
        String indicator = "§7Страница §f" + (currentPage + 1) + " §7/ §f" + pages.size();
        gfx.drawCenteredString(this.font, Component.literal(indicator),
            this.width / 2, panelY + panelH - 22, 0xAAAAAA);

        // 6. Рендер кнопок (без фона)
        super.render(gfx, mouseX, mouseY, partialTick);
    }

    // =========================================================================
    // Клавиатура
    // =========================================================================

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 262 && currentPage < pages.size() - 1) {
            currentPage++;
            scrollOffset = 0;
            return true;
        }
        if (keyCode == 263 && currentPage > 0) {
            currentPage--;
            scrollOffset = 0;
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    // =========================================================================
    // Прокрутка
    // =========================================================================

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        int maxScroll = Math.max(0, pages.get(currentPage).lines.size() * 11 - 220);
        scrollOffset = Math.max(0, Math.min(maxScroll, scrollOffset - (int) scrollY * 12));
        return true;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}