package com.livemine;

import com.livemine.ai.BrainDebugger;
import com.livemine.ai.NPCRegistry;
import com.livemine.entity.LiveNPCEntity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Менеджер свадеб и размножения NPC.
 *
 * v2.1: пишет в Chronicle деревни (свадьба, рождение).
 */
public final class MarriageManager {

    public static final int MIN_MARRIAGE_AGE = 18;
    public static final long MARRIAGE_COOLDOWN_DAYS = 5;
    public static final long BIRTH_COOLDOWN_DAYS = 15;
    public static final float BIRTH_CHANCE_PER_DAY = 0.05f;
    public static final double MIN_TRUST_FOR_MARRIAGE = 70.0;

    private static MarriageManager INSTANCE;

    private final Map<UUID, Long> marriageCooldowns = new HashMap<>();
    private final Map<UUID, Long> birthCooldowns = new HashMap<>();

    private MarriageManager() {}

    public static synchronized MarriageManager getInstance() {
        if (INSTANCE == null) INSTANCE = new MarriageManager();
        return INSTANCE;
    }

    public boolean canMarry(LiveNPCEntity npc, long currentDay) {
        if (npc == null || !npc.isAdult()) return false;
        if (npc.getSpouseUUID() != null) return false;
        if (npc.getAgeInDays() < MIN_MARRIAGE_AGE) return false;

        Long last = marriageCooldowns.get(npc.getUUID());
        return last == null || currentDay - last >= MARRIAGE_COOLDOWN_DAYS;
    }

    public boolean canMarry(LiveNPCEntity a, LiveNPCEntity b, long currentDay) {
        if (a == null || b == null) return false;
        if (a.getUUID().equals(b.getUUID())) return false;
        if (!canMarry(a, currentDay) || !canMarry(b, currentDay)) return false;

        String va = a.getVillageRawId();
        String vb = b.getVillageRawId();
        if (va == null || va.isEmpty()) return false;
        if (!va.equals(vb)) return false;

        double trust = com.livemine.ai.NPCRelationship.getTrust(a, b);
        return trust >= MIN_TRUST_FOR_MARRIAGE;
    }

    public boolean marry(LiveNPCEntity a, LiveNPCEntity b, long currentDay) {
        if (!canMarry(a, b, currentDay)) return false;

        CompoundTag tagA = getTag(a);
        CompoundTag tagB = getTag(b);
        if (tagA == null || tagB == null) return false;

        tagA.putUUID("spouse_uuid", b.getUUID());
        tagB.putUUID("spouse_uuid", a.getUUID());
        saveTag(a, tagA);
        saveTag(b, tagB);

        a.setSpouseUUID(b.getUUID());
        b.setSpouseUUID(a.getUUID());

        marriageCooldowns.put(a.getUUID(), currentDay);
        marriageCooldowns.put(b.getUUID(), currentDay);

        // v2.1: запись в хронику.
        String rawId = a.getVillageRawId();
        if (!rawId.isEmpty() && a.level() instanceof ServerLevel sl) {
            try {
                VillageData vd = new VillageData(rawId, sl);
                if (vd.exists()) {
                    vd.addChronicleEntry(Chronicle.EntryType.MARRIAGE, currentDay,
                        "Свадьба " + a.getCustomNameTag() + " и " + b.getCustomNameTag(),
                        a.getCustomNameTag());
                }
            } catch (Exception e) {
                LiveMineMod.LOGGER.error("Marriage: chronicle write failed", e);
            }
        }

        BrainDebugger.log(a, "MARRIAGE", "поженился с " + b.getCustomNameTag());
        LiveMineMod.LOGGER.info("Marriage: {} + {}", a.getCustomNameTag(), b.getCustomNameTag());
        return true;
    }

    public void tick(LiveNPCEntity npc, long currentDay) {
        if (npc == null || !npc.isAdult()) return;
        if (npc.getSpouseUUID() == null) return;
        if (!(npc.level() instanceof ServerLevel level)) return;

        Long lastBirth = birthCooldowns.get(npc.getUUID());
        if (lastBirth != null && currentDay - lastBirth < BIRTH_COOLDOWN_DAYS) return;

        if (level.random.nextFloat() > BIRTH_CHANCE_PER_DAY) return;

        LiveNPCEntity spouse = findSpouse(npc, level);
        if (spouse == null || !spouse.isAlive()) return;

        if (NPCRegistry.getTotalCount() >= LiveMineConfig.maxTotalNpcs()) return;

        String rawId = npc.getVillageRawId();
        if (!rawId.isEmpty()) {
            int inVillage = countInVillage(rawId, level);
            if (inVillage >= LiveMineConfig.maxNpcsPerVillage()) return;
        }

        spawnChild(npc, spouse, level, currentDay);
    }

    private void spawnChild(LiveNPCEntity a, LiveNPCEntity b, ServerLevel level, long currentDay) {
        var child = com.livemine.registry.ModEntities.LIVE_NPC.get().create(level);
        if (child == null) return;

        child.moveTo(a.getX() + 0.5, a.getY(), a.getZ() + 0.5, 0, 0);
        String name = NamePool.getInstance().generateName(level.random.nextBoolean());
        child.setCustomNameTag(name);
        child.setChild(true);
        child.setAgeInDays(0);

        String rawId = a.getVillageRawId();
        if (!rawId.isEmpty()) {
            child.setVillageRawId(rawId);
        }

        level.addFreshEntity(child);
        NPCRegistry.register(child);

        CompoundTag childTag = LiveMineSavedData.get(level).loadNPCData(child.getUUID());
        childTag.putDouble("health", 20.0);
        childTag.putDouble("hunger", 100.0);
        childTag.putDouble("energy", 100.0);
        childTag.putDouble("social", 100.0);
        childTag.putString("current_goal", "WANDER");
        childTag.putString("village_id", rawId);
        childTag.putUUID("parent_a_uuid", a.getUUID());
        childTag.putUUID("parent_b_uuid", b.getUUID());
        childTag.putLong("birth_day", currentDay);
        LiveMineSavedData.get(level).saveNPCData(child.getUUID(), childTag);

        birthCooldowns.put(a.getUUID(), currentDay);
        birthCooldowns.put(b.getUUID(), currentDay);

        // v2.1: запись в хронику.
        if (!rawId.isEmpty()) {
            try {
                VillageData vd = new VillageData(rawId, level);
                if (vd.exists()) {
                    vd.addChronicleEntry(Chronicle.EntryType.BIRTH, currentDay,
                        "Родился " + name + " (родители: "
                            + a.getCustomNameTag() + " и " + b.getCustomNameTag() + ")",
                        name);
                }
            } catch (Exception e) {
                LiveMineMod.LOGGER.error("Birth: chronicle write failed", e);
            }
        }

        BrainDebugger.log(a, "BIRTH", "родился " + name);
        LiveMineMod.LOGGER.info("Birth: {} + {} -> {}", a.getCustomNameTag(), b.getCustomNameTag(), name);
    }

    private LiveNPCEntity findSpouse(LiveNPCEntity npc, ServerLevel level) {
        UUID spouseId = npc.getSpouseUUID();
        if (spouseId == null) return null;
        return NPCRegistry.getNPC(spouseId);
    }

    private int countInVillage(String rawId, ServerLevel level) {
        int count = 0;
        for (var entry : LiveMineSavedData.get(level).getAllNpcData().entrySet()) {
            CompoundTag tag = entry.getValue();
            if (tag.getBoolean("dead")) continue;
            if (rawId.equals(tag.getString("village_id"))) count++;
        }
        return count;
    }

    private CompoundTag getTag(LiveNPCEntity npc) {
        if (!(npc.level() instanceof ServerLevel level)) return null;
        return LiveMineSavedData.get(level).loadNPCData(npc.getUUID());
    }

    private void saveTag(LiveNPCEntity npc, CompoundTag tag) {
        if (!(npc.level() instanceof ServerLevel level)) return;
        LiveMineSavedData.get(level).saveNPCData(npc.getUUID(), tag);
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        CompoundTag mc = new CompoundTag();
        marriageCooldowns.forEach((uuid, day) -> mc.putLong(uuid.toString(), day));
        tag.put("marriageCooldowns", mc);

        CompoundTag bc = new CompoundTag();
        birthCooldowns.forEach((uuid, day) -> bc.putLong(uuid.toString(), day));
        tag.put("birthCooldowns", bc);
        return tag;
    }

    public void load(CompoundTag tag) {
        marriageCooldowns.clear();
        birthCooldowns.clear();

        CompoundTag mc = tag.getCompound("marriageCooldowns");
        for (String k : mc.getAllKeys()) {
            try { marriageCooldowns.put(UUID.fromString(k), mc.getLong(k)); }
            catch (IllegalArgumentException ignored) {}
        }

        CompoundTag bc = tag.getCompound("birthCooldowns");
        for (String k : bc.getAllKeys()) {
            try { birthCooldowns.put(UUID.fromString(k), bc.getLong(k)); }
            catch (IllegalArgumentException ignored) {}
        }
    }

    public void clear() {
        marriageCooldowns.clear();
        birthCooldowns.clear();
    }
}