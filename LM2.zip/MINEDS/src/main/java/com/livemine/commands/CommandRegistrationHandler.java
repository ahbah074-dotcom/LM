package com.livemine.commands;

import com.livemine.LiveMineMod;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * Регистрация команд LiveMine.
 *
 * v2.1: убран bus = GAME (deprecated в NeoForge 21.1.x).
 */
@EventBusSubscriber(modid = LiveMineMod.MOD_ID)
public final class CommandRegistrationHandler {

    private CommandRegistrationHandler() {}

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        LiveMineCommands.register(event.getDispatcher());
        LiveMineMod.LOGGER.info("LiveMine: registered commands /livemine and /lm");
    }
}