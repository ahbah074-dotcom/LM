package com.livemine.commands;

import com.livemine.CollectiveMemory;
import com.livemine.LiveMineConfig;
import com.livemine.LiveMineSavedData;
import com.livemine.VillageData;
import com.livemine.VillageManager;
import com.livemine.achievement.AchievementManager;
import com.livemine.ai.NPCRegistry;
import com.livemine.diplomacy.AllianceManager;
import com.livemine.diplomacy.DiplomacyManager;
import com.livemine.diplomacy.MailManager;
import com.livemine.diplomacy.WarManager;
import com.livemine.domain.VillageRecord;
import com.livemine.entity.LiveNPCEntity;
import com.livemine.registry.ModEntities;
import com.livemine.world.CaravanManager;
import com.livemine.world.ScoutManager;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Mob;

import java.util.List;
import java.util.UUID;

/**
 * Команды LiveMine.
 *
 * v3.0:
 *   - /lm village list показывает X Y Z + кликабельную [TP].
 *   - /lm village tp <name|id|uuid> — телепорт в деревню.
 *   - /lm npc tp <uuid> — телепорт к NPC.
 */
public final class LiveMineCommands {

    private LiveMineCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        var root = Commands.literal("livemine").requires(src -> src.hasPermission(2));
        registerSubcommands(root);
        dispatcher.register(root);

        var alias = Commands.literal("lm").requires(src -> src.hasPermission(2));
        registerSubcommands(alias);
        dispatcher.register(alias);
    }

    private static void registerSubcommands(
            com.mojang.brigadier.builder.LiteralArgumentBuilder<CommandSourceStack> root) {

        // ---- Base ----
        root.then(Commands.literal("guide").executes(ctx -> {
            ctx.getSource().sendSuccess(() -> Component.literal("§6Клавиша §eG§6 — справочник"), false);
            return 1;
        }));
        root.then(Commands.literal("stats").executes(LiveMineCommands::cmdStats));
        root.then(Commands.literal("reload").executes(ctx -> {
            com.livemine.ConfigManager.reload();
            ctx.getSource().sendSuccess(() -> Component.literal("§aКонфиг перезагружен"), true);
            return 1;
        }));
        root.then(Commands.literal("save").executes(ctx -> {
            com.livemine.PersistenceManager.get(ctx.getSource().getLevel()).saveAll();
            ctx.getSource().sendSuccess(() -> Component.literal("§aДанные сохранены"), true);
            return 1;
        }));
        root.then(Commands.literal("cache").then(Commands.literal("clear").executes(ctx -> {
            com.livemine.ai.ResourceCache.clear();
            com.livemine.ai.PathCache.clear();
            ctx.getSource().sendSuccess(() -> Component.literal("§aКэши очищены"), true);
            return 1;
        })));

        // ---- Mode ----
        root.then(Commands.literal("mode")
            .then(Commands.argument("type", StringArgumentType.word())
                .executes(ctx -> {
                    String type = StringArgumentType.getString(ctx, "type").toUpperCase();
                    try {
                        var tier = com.livemine.ai.AdaptiveTickRate.Tier.valueOf(type);
                        ctx.getSource().sendSuccess(() -> Component.literal(
                            "§aРежим: " + tier.name()
                                + " §7(текущий: " + com.livemine.ai.AdaptiveTickRate.getCurrentTier() + ")"), false);
                        return 1;
                    } catch (IllegalArgumentException e) {
                        ctx.getSource().sendFailure(Component.literal(
                            "§cНеизвестный режим. Используйте: STABLE, NORMAL, STRESSED, CRITICAL"));
                        return 0;
                    }
                })));

        // ---- NPC ----
        root.then(Commands.literal("npc")
            .then(Commands.literal("list").executes(LiveMineCommands::cmdNpcList))
            .then(Commands.literal("info").then(Commands.argument("uuid", StringArgumentType.string())
                .executes(LiveMineCommands::cmdNpcInfo)))
            .then(Commands.literal("tp").then(Commands.argument("uuid", StringArgumentType.string())
                .executes(LiveMineCommands::cmdNpcTp)))
            .then(Commands.literal("kill").then(Commands.argument("uuid", StringArgumentType.string())
                .executes(LiveMineCommands::cmdNpcKill)))
            .then(Commands.literal("spawn")
                .executes(ctx -> spawnNpc(ctx, 1))
                .then(Commands.argument("count", IntegerArgumentType.integer(1, 50))
                    .executes(ctx -> spawnNpc(ctx, IntegerArgumentType.getInteger(ctx, "count"))))));

        // ---- Village ----
        root.then(Commands.literal("village")
            .executes(LiveMineCommands::cmdVillageList)
            .then(Commands.literal("list").executes(LiveMineCommands::cmdVillageList))
            .then(Commands.literal("nearest").executes(LiveMineCommands::cmdVillageNearest))
            .then(Commands.literal("tp").then(Commands.argument("id", StringArgumentType.string())
                .executes(LiveMineCommands::cmdVillageTp)))
            .then(Commands.literal("info").then(Commands.argument("id", StringArgumentType.string())
                .executes(LiveMineCommands::cmdVillageInfo)))
            .then(Commands.literal("create").then(Commands.argument("name", StringArgumentType.string())
                .executes(LiveMineCommands::cmdVillageCreate))));

        // ---- Reputation ----
        root.then(Commands.literal("reputation")
            .then(Commands.literal("get").executes(ctx -> {
                ServerPlayer player = ctx.getSource().getPlayer();
                if (player == null) return 0;
                var rm = com.livemine.ReputationManager.getInstance();
                ctx.getSource().sendSuccess(() -> Component.literal("§6=== Reputation ==="), false);
                for (var v : VillageManager.getInstance().getAllVillages()) {
                    int rep = rm.getVillageReputation(v.id(), player.getUUID());
                    var lvl = com.livemine.ReputationManager.Level.fromValue(rep);
                    final int fr = rep;
                    ctx.getSource().sendSuccess(() -> Component.literal(
                        "§7- §f" + v.name() + "§7: §e" + fr + " §7(" + lvl.ruName + ")"
                    ), false);
                }
                return 1;
            }))
            .then(Commands.literal("set").then(Commands.argument("value", IntegerArgumentType.integer(-100, 100))
                .executes(ctx -> {
                    ServerPlayer player = ctx.getSource().getPlayer();
                    if (player == null) return 0;
                    int value = IntegerArgumentType.getInteger(ctx, "value");
                    for (var v : VillageManager.getInstance().getAllVillages()) {
                        com.livemine.ReputationManager.getInstance()
                            .setVillageReputation(v.id(), player.getUUID(), value);
                    }
                    ctx.getSource().sendSuccess(() -> Component.literal(
                        "§aРепутация: " + value), true);
                    return 1;
                })))
            .then(Commands.literal("add").then(Commands.argument("delta", IntegerArgumentType.integer(-100, 100))
                .executes(ctx -> {
                    ServerPlayer player = ctx.getSource().getPlayer();
                    if (player == null) return 0;
                    int delta = IntegerArgumentType.getInteger(ctx, "delta");
                    for (var v : VillageManager.getInstance().getAllVillages()) {
                        com.livemine.ReputationManager.getInstance()
                            .addVillageReputation(v.id(), player.getUUID(), delta);
                    }
                    ctx.getSource().sendSuccess(() -> Component.literal(
                        "§aРепутация изменена: " + delta), true);
                    return 1;
                }))));

        // ---- Achievement ----
        root.then(Commands.literal("achievement")
            .then(Commands.literal("list").executes(ctx -> {
                ServerPlayer player = ctx.getSource().getPlayer();
                if (player == null) return 0;
                var am = AchievementManager.getInstance();
                var unlocked = am.getPlayerAchievements(player.getUUID());
                int total = am.getTotalAchievements();
                ctx.getSource().sendSuccess(() -> Component.literal(
                    "§6=== Достижения (" + unlocked.size() + "/" + total + ") ==="), false);
                for (AchievementManager.Achievement ach : am.getAllAchievements()) {
                    boolean has = unlocked.contains(ach);
                    String mark = has ? "§a✔" : "§7✘";
                    ctx.getSource().sendSuccess(() -> Component.literal(
                        "  " + mark + " §f" + ach.title + "§7 — " + ach.description
                    ), false);
                }
                return 1;
            }))
            .then(Commands.literal("unlock").then(Commands.argument("id", StringArgumentType.word())
                .executes(ctx -> {
                    ServerPlayer player = ctx.getSource().getPlayer();
                    if (player == null) return 0;
                    String id = StringArgumentType.getString(ctx, "id").toUpperCase();
                    try {
                        var ach = AchievementManager.Achievement.valueOf(id);
                        boolean ok = AchievementManager.getInstance().unlock(player, ach);
                        ctx.getSource().sendSuccess(() -> Component.literal(
                            ok ? "§aРазблокировано: " + ach.title : "§7Уже разблокировано"), true);
                        return 1;
                    } catch (IllegalArgumentException e) {
                        ctx.getSource().sendFailure(Component.literal("§cНеизвестное: " + id));
                        return 0;
                    }
                }))));

        // ---- Chronicle ----
        root.then(Commands.literal("chronicle")
            .then(Commands.literal("show").then(Commands.argument("village", StringArgumentType.string())
                .executes(ctx -> {
                    String vid = StringArgumentType.getString(ctx, "village");
                    VillageData vd = new VillageData(vid, ctx.getSource().getLevel());
                    if (!vd.exists()) {
                        ctx.getSource().sendFailure(Component.literal("§cНе найдена"));
                        return 0;
                    }
                    var entries = vd.getChronicle().getRecentEntries(30);
                    ctx.getSource().sendSuccess(() -> Component.literal(
                        "§6=== Хроника " + vid + " ==="), false);
                    for (var e : entries) {
                        ctx.getSource().sendSuccess(() -> Component.literal(
                            "§7[" + e.day + "] §f" + e.type.name() + "§7: §r" + e.description
                        ), false);
                    }
                    return 1;
                })))
            .then(Commands.literal("add")
                .then(Commands.argument("village", StringArgumentType.string())
                    .then(Commands.argument("text", StringArgumentType.greedyString())
                        .executes(ctx -> {
                            String vid = StringArgumentType.getString(ctx, "village");
                            String text = StringArgumentType.getString(ctx, "text");
                            ServerLevel level = ctx.getSource().getLevel();
                            VillageData vd = new VillageData(vid, level);
                            if (!vd.exists()) {
                                ctx.getSource().sendFailure(Component.literal("§cНе найдена"));
                                return 0;
                            }
                            long day = level.getDayTime() / 24000L;
                            vd.addChronicleEntry(com.livemine.Chronicle.EntryType.OTHER, day, text);
                            ctx.getSource().sendSuccess(() -> Component.literal("§aOK"), true);
                            return 1;
                        })))));

        // ---- Memory ----
        root.then(Commands.literal("memory")
            .then(Commands.literal("show").then(Commands.argument("village", StringArgumentType.string())
                .executes(ctx -> {
                    String vid = StringArgumentType.getString(ctx, "village");
                    VillageData vd = new VillageData(vid, ctx.getSource().getLevel());
                    if (!vd.exists()) {
                        ctx.getSource().sendFailure(Component.literal("§cНе найдена"));
                        return 0;
                    }
                    var mem = vd.getMemory();
                    ctx.getSource().sendSuccess(() -> Component.literal(
                        "§6=== Memory (" + mem.size() + ") ==="), false);
                    for (var rec : mem.getAllMemories()) {
                        ctx.getSource().sendSuccess(() -> Component.literal(
                            "§7[" + rec.category + "] §f" + rec.key + "§7: §r" + rec.value
                        ), false);
                    }
                    return 1;
                })))
            .then(Commands.literal("add")
                .then(Commands.argument("village", StringArgumentType.string())
                    .then(Commands.argument("key", StringArgumentType.word())
                        .then(Commands.argument("value", StringArgumentType.greedyString())
                            .executes(ctx -> {
                                String vid = StringArgumentType.getString(ctx, "village");
                                String key = StringArgumentType.getString(ctx, "key");
                                String value = StringArgumentType.getString(ctx, "value");
                                ServerLevel level = ctx.getSource().getLevel();
                                VillageData vd = new VillageData(vid, level);
                                if (!vd.exists()) {
                                    ctx.getSource().sendFailure(Component.literal("§cНе найдена"));
                                    return 0;
                                }
                                long day = level.getDayTime() / 24000L;
                                vd.remember(key, value, CollectiveMemory.Category.CHRONICLE, day);
                                ctx.getSource().sendSuccess(() -> Component.literal("§aOK"), true);
                                return 1;
                            }))))));

        // ---- Economy ----
        root.then(Commands.literal("economy")
            .then(Commands.literal("prices").executes(ctx -> {
                var em = com.livemine.EconomyManager.getInstance();
                ctx.getSource().sendSuccess(() -> Component.literal("§6=== Цены ==="), false);
                for (var c : em.getAllCommodities()) {
                    ctx.getSource().sendSuccess(() -> Component.literal(
                        "§7- §f" + c.id + "§7: §e" + String.format("%.2f", c.currentPrice)
                            + " §7(s/d=" + c.supply + "/" + c.demand + ")"
                    ), false);
                }
                return 1;
            }))
            .then(Commands.literal("update").executes(ctx -> {
                com.livemine.EconomyManager.getInstance().dailyUpdate();
                ctx.getSource().sendSuccess(() -> Component.literal("§aОбновлено"), true);
                return 1;
            })));

        // ---- Stall ----
        root.then(Commands.literal("stall")
            .then(Commands.literal("init")
                .then(Commands.argument("offer_count", IntegerArgumentType.integer(1, 64))
                    .then(Commands.argument("price_count", IntegerArgumentType.integer(1, 64))
                        .executes(ctx -> {
                            ServerPlayer player = ctx.getSource().getPlayer();
                            if (player == null) return 0;
                            ServerLevel level = ctx.getSource().getLevel();
                            BlockPos pos = player.blockPosition();

                            var be = level.getBlockEntity(pos);
                            if (!(be instanceof com.livemine.blocks.MarketStallBlockEntity stall)) {
                                ctx.getSource().sendFailure(Component.literal(
                                    "§cВстаньте на блок торговой лавки"));
                                return 0;
                            }

                            int offerCount = IntegerArgumentType.getInteger(ctx, "offer_count");
                            int priceCount = IntegerArgumentType.getInteger(ctx, "price_count");

                            net.minecraft.world.item.ItemStack heldOffer = player.getMainHandItem();
                            if (heldOffer.isEmpty()) {
                                ctx.getSource().sendFailure(Component.literal(
                                    "§cВозьмите предмет в руку"));
                                return 0;
                            }

                            net.minecraft.world.item.ItemStack offer = heldOffer.copyWithCount(offerCount);
                            net.minecraft.world.item.ItemStack price =
                                new net.minecraft.world.item.ItemStack(
                                    net.minecraft.world.item.Items.EMERALD, priceCount);

                            stall.clearTrades();
                            var entry = new com.livemine.blocks.MarketStallBlockEntity.TradeEntry(offer, price);
                            entry.stock = 10;
                            stall.addTrade(entry);

                            ctx.getSource().sendSuccess(() -> Component.literal(
                                "§aЛот добавлен: " + offerCount + "x " + heldOffer.getHoverName().getString()
                                    + " за " + priceCount + " изумрудов"), true);
                            return 1;
                        }))))
            .then(Commands.literal("clear").executes(ctx -> {
                ServerPlayer player = ctx.getSource().getPlayer();
                if (player == null) return 0;
                var be = ctx.getSource().getLevel().getBlockEntity(player.blockPosition());
                if (be instanceof com.livemine.blocks.MarketStallBlockEntity stall) {
                    stall.clearTrades();
                    ctx.getSource().sendSuccess(() -> Component.literal("§aЛавка очищена"), true);
                    return 1;
                }
                ctx.getSource().sendFailure(Component.literal("§cВстаньте на блок лавки"));
                return 0;
            })));

        // ---- Diplomacy ----
        root.then(Commands.literal("diplomacy")
            .then(Commands.literal("status").executes(ctx -> {
                var src = ctx.getSource();
                var villages = VillageManager.getInstance().getAllVillages();
                src.sendSuccess(() -> Component.literal(
                    "§6=== Diplomacy (" + villages.size() + " villages) ==="), false);
                src.sendSuccess(() -> Component.literal(
                    "§7relations: §f" + DiplomacyManager.getInstance().size()), false);
                src.sendSuccess(() -> Component.literal(
                    "§7alliances: §f" + AllianceManager.getInstance().size()), false);
                src.sendSuccess(() -> Component.literal(
                    "§7wars: §f" + WarManager.getInstance().size()), false);
                src.sendSuccess(() -> Component.literal(
                    "§7mail in transit: §f" + MailManager.getInstance().getInTransit().size()), false);
                src.sendSuccess(() -> Component.literal(
                    "§7caravans: §f" + CaravanManager.getInstance().getActiveCaravans().size()), false);
                return 1;
            })));

        // ---- Alliance ----
        root.then(Commands.literal("alliance")
            .then(Commands.literal("list").executes(ctx -> {
                var src = ctx.getSource();
                var all = AllianceManager.getInstance();
                src.sendSuccess(() -> Component.literal(
                    "§6=== Альянсы ==="), false);
                for (var v : VillageManager.getInstance().getAllVillages()) {
                    for (var a : all.getAlliancesFor(v.id())) {
                        final String vA = a.villageA.toString().substring(0, 8);
                        final String vB = a.villageB.toString().substring(0, 8);
                        final boolean rb = a.roadBuilt;
                        src.sendSuccess(() -> Component.literal(
                            "§7- §f" + vA + " ↔ " + vB
                                + " §7(дорога: " + (rb ? "§aесть" : "§7нет") + "§7)"), false);
                    }
                }
                return 1;
            })));

        // ---- War ----
        root.then(Commands.literal("war")
            .then(Commands.literal("list").executes(ctx -> {
                var src = ctx.getSource();
                var wars = WarManager.getInstance().getActiveWars();
                src.sendSuccess(() -> Component.literal(
                    "§6=== Войны (" + wars.size() + ") ==="), false);
                for (var w : wars) {
                    final String wId = w.warId.toString().substring(0, 8);
                    final String ag = w.aggressor.toString().substring(0, 8);
                    final String def = w.defender.toString().substring(0, 8);
                    final String reason = w.reason.ruName;
                    src.sendSuccess(() -> Component.literal(
                        "§7- §c[" + wId + "] §f" + ag + " → " + def
                            + " §7(" + reason + ")"), false);
                }
                return 1;
            }))
            .then(Commands.literal("declare")
                .then(Commands.argument("aggressor", StringArgumentType.string())
                    .then(Commands.argument("defender", StringArgumentType.string())
                        .then(Commands.argument("reason", StringArgumentType.word())
                            .executes(ctx -> {
                                try {
                                    UUID ag = UUID.fromString(StringArgumentType.getString(ctx, "aggressor"));
                                    UUID def = UUID.fromString(StringArgumentType.getString(ctx, "defender"));
                                    String reasonId = StringArgumentType.getString(ctx, "reason").toUpperCase();
                                    WarManager.WarReason reason = WarManager.WarReason.valueOf(reasonId);
                                    long day = ctx.getSource().getLevel().getDayTime() / 24000L;
                                    var war = WarManager.getInstance()
                                        .declareWar(ag, def, reason, "", day);
                                    if (war != null) {
                                        ctx.getSource().sendSuccess(() -> Component.literal(
                                            "§cВойна: " + reason.ruName), true);
                                        return 1;
                                    }
                                    ctx.getSource().sendFailure(Component.literal("§cНе удалось"));
                                    return 0;
                                } catch (IllegalArgumentException e) {
                                    ctx.getSource().sendFailure(Component.literal("§cНеверно"));
                                    return 0;
                                }
                            }))))));

        // ---- Caravan ----
        root.then(Commands.literal("caravan")
            .then(Commands.literal("list").executes(ctx -> {
                var src = ctx.getSource();
                var caravans = CaravanManager.getInstance().getActiveCaravans();
                src.sendSuccess(() -> Component.literal(
                    "§6=== Караваны (" + caravans.size() + ") ==="), false);
                for (var c : caravans) {
                    final String cid = c.caravanId.toString().substring(0, 8);
                    final String src8 = c.sourceVillage.toString().substring(0, 8);
                    final String dst8 = c.targetVillage.toString().substring(0, 8);
                    src.sendSuccess(() -> Component.literal(
                        "§7- §f[" + cid + "] " + src8 + " → " + dst8), false);
                }
                return 1;
            })));

        // ---- Scout ----
        root.then(Commands.literal("scout")
            .then(Commands.literal("known").then(Commands.argument("village", StringArgumentType.string())
                .executes(ctx -> {
                    try {
                        UUID vId = UUID.fromString(StringArgumentType.getString(ctx, "village"));
                        var known = ScoutManager.getInstance().getKnownVillages(vId);
                        ctx.getSource().sendSuccess(() -> Component.literal(
                            "§6Известно: §f" + known.size()), false);
                        for (UUID otherId : known) {
                            final String s = otherId.toString().substring(0, 8);
                            var rec = VillageManager.getInstance().getVillage(otherId);
                            final String nm = rec != null ? rec.name() : "?";
                            ctx.getSource().sendSuccess(() -> Component.literal(
                                "§7- §f" + s + " §7(" + nm + ")"), false);
                        }
                        return 1;
                    } catch (IllegalArgumentException e) {
                        ctx.getSource().sendFailure(Component.literal("§cНеверный UUID"));
                        return 0;
                    }
                }))));

        // ---- Property ----
        root.then(Commands.literal("property")
            .then(Commands.literal("list").executes(ctx -> {
                var src = ctx.getSource();
                var pm = com.livemine.property.PropertyManager.getInstance();
                src.sendSuccess(() -> Component.literal(
                    "§6=== Собственность (" + pm.size() + ", с домом: "
                        + pm.countWithHome() + ") ==="), false);
                int i = 0;
                for (var prop : pm.getAllProperties()) {
                    if (i++ >= 20) break;
                    var npc = NPCRegistry.getNPC(prop.ownerId);
                    String name = npc != null ? npc.getCustomNameTag()
                        : prop.ownerId.toString().substring(0, 8);
                    final int lvl = prop.homeLevel;
                    final String homeStr = prop.homePos != null
                        ? prop.homePos.toShortString() : "нет";
                    src.sendSuccess(() -> Component.literal(
                        "§7- §f" + name + "§7: дом §f" + homeStr
                            + " §7(ур. " + lvl + ")"), false);
                }
                return 1;
            }))
            .then(Commands.literal("info").then(Commands.argument("uuid", StringArgumentType.string())
                .executes(ctx -> {
                    try {
                        UUID id = UUID.fromString(StringArgumentType.getString(ctx, "uuid"));
                        var prop = com.livemine.property.PropertyManager.getInstance().get(id);
                        if (prop == null) {
                            ctx.getSource().sendFailure(Component.literal("§cНет данных"));
                            return 0;
                        }
                        ctx.getSource().sendSuccess(() -> Component.literal("§6=== Property ==="), false);
                        ctx.getSource().sendSuccess(() -> Component.literal(
                            "§7Home: §f" + (prop.homePos != null ? prop.homePos.toShortString() : "нет")
                                + " §7(ур. " + prop.homeLevel + ")"), false);
                        ctx.getSource().sendSuccess(() -> Component.literal(
                            "§7Сундуков: §f" + prop.personalChests.size()), false);
                        return 1;
                    } catch (IllegalArgumentException e) {
                        ctx.getSource().sendFailure(Component.literal("§cНеверный UUID"));
                        return 0;
                    }
                })))
            .then(Commands.literal("setlevel")
                .then(Commands.argument("uuid", StringArgumentType.string())
                    .then(Commands.argument("level", IntegerArgumentType.integer(1, 6))
                        .executes(ctx -> {
                            try {
                                UUID id = UUID.fromString(StringArgumentType.getString(ctx, "uuid"));
                                int level = IntegerArgumentType.getInteger(ctx, "level");
                                var prop = com.livemine.property.PropertyManager.getInstance()
                                    .getOrCreate(id, null);
                                prop.homeLevel = level;
                                ctx.getSource().sendSuccess(() -> Component.literal(
                                    "§aУровень дома установлен: " + level), true);
                                return 1;
                            } catch (IllegalArgumentException e) {
                                ctx.getSource().sendFailure(Component.literal("§cНеверный UUID"));
                                return 0;
                            }
                        })))));

        // ---- Debug ----
        root.then(Commands.literal("debug")
            .then(Commands.literal("brain").then(Commands.argument("uuid", StringArgumentType.string())
                .executes(LiveMineCommands::cmdDebugBrain)))
            .then(Commands.literal("cache").executes(ctx -> {
                ctx.getSource().sendSuccess(() -> Component.literal(
                    "§6ResourceCache: §f" + com.livemine.ai.ResourceCache.size()), false);
                ctx.getSource().sendSuccess(() -> Component.literal(
                    "§6PathCache: §f" + com.livemine.ai.PathCache.size()), false);
                return 1;
            }))
            .then(Commands.literal("ticks").executes(ctx -> {
                var tier = com.livemine.ai.AdaptiveTickRate.getCurrentTier();
                var interval = com.livemine.ai.AdaptiveTickRate.getSimulationInterval();
                var batch = com.livemine.ai.AdaptiveTickRate.getBatchPerTick();
                ctx.getSource().sendSuccess(() -> Component.literal(
                    "§6Tier: §f" + tier), false);
                ctx.getSource().sendSuccess(() -> Component.literal(
                    "§6Interval: §f" + interval + " тиков"), false);
                ctx.getSource().sendSuccess(() -> Component.literal(
                    "§6Batch: §f" + batch), false);
                return 1;
            })));
    }

    // =========================================================================
    // Stats
    // =========================================================================

    private static int cmdStats(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        src.sendSuccess(() -> Component.literal("§6=== LiveMine Stats ==="), false);
        src.sendSuccess(() -> Component.literal("§7NPC: §f" + NPCRegistry.getTotalCount()
            + "/" + LiveMineConfig.maxTotalNpcs()), false);
        src.sendSuccess(() -> Component.literal("§aACTIVE: §f" + NPCRegistry.getActiveCount()), false);
        src.sendSuccess(() -> Component.literal("§eSIMULATED: §f" + NPCRegistry.getSimulatedCount()), false);
        src.sendSuccess(() -> Component.literal("§8DORMANT: §f" + NPCRegistry.getDormantCount()), false);
        src.sendSuccess(() -> Component.literal("§7Деревень: §f" + VillageManager.getInstance().getVillageCount()), false);
        src.sendSuccess(() -> Component.literal("§7Tick tier: §f" + com.livemine.ai.AdaptiveTickRate.getCurrentTier()), false);
        return 1;
    }

    // =========================================================================
    // NPC
    // =========================================================================

    private static int cmdNpcList(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        List<Mob> npcs = NPCRegistry.getAll();
        if (npcs.isEmpty()) {
            src.sendSuccess(() -> Component.literal("§7NPC нет"), false);
            return 0;
        }
        src.sendSuccess(() -> Component.literal("§6NPC (" + npcs.size() + "):"), false);
        int shown = 0;
        for (Mob mob : npcs) {
            if (shown++ >= 20) break;
            if (!(mob instanceof LiveNPCEntity npc)) continue;
            String state = NPCRegistry.getActivityState(npc.getUUID()).name();
            String v = npc.getVillageRawId();
            final String uuidShort = npc.getUUID().toString().substring(0, 8);
            src.sendSuccess(() -> Component.literal(
                "§7- §f" + npc.getCustomNameTag() + " §7[" + state + "]"
                    + " §8" + uuidShort + " §8village=" + (v.isEmpty() ? "нет" : v)), false);
        }
        return npcs.size();
    }

    private static int cmdNpcInfo(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        try {
            UUID id = UUID.fromString(StringArgumentType.getString(ctx, "uuid"));
            LiveNPCEntity npc = NPCRegistry.getNPC(id);
            if (npc == null) { src.sendFailure(Component.literal("§cНе найден")); return 0; }
            CompoundTag tag = LiveMineSavedData.get(src.getLevel()).loadNPCData(id);
            src.sendSuccess(() -> Component.literal("§6=== NPC Info ==="), false);
            src.sendSuccess(() -> Component.literal("§7UUID: §f" + id), false);
            src.sendSuccess(() -> Component.literal("§7Имя: §f" + npc.getCustomNameTag()), false);
            src.sendSuccess(() -> Component.literal("§7Возраст: §f" + npc.getAgeInDays()), false);
            src.sendSuccess(() -> Component.literal("§7Деревня: §f" +
                (npc.getVillageRawId().isEmpty() ? "нет" : npc.getVillageRawId())), false);
            src.sendSuccess(() -> Component.literal("§7Цель: §f" + npc.getNpcBrain().getCurrentGoalName()), false);
            src.sendSuccess(() -> Component.literal("§cHP: §f" +
                String.format("%.1f", tag.getDouble("health"))), false);
            src.sendSuccess(() -> Component.literal("§eHunger: §f" +
                String.format("%.0f", tag.getDouble("hunger"))), false);
            src.sendSuccess(() -> Component.literal("§aEnergy: §f" +
                String.format("%.0f", tag.getDouble("energy"))), false);

            // Кликабельный tp
            final double nx = npc.getX();
            final double ny = npc.getY();
            final double nz = npc.getZ();
            String tpCmd = "/tp @s " + (int) nx + " " + (int) (ny + 1) + " " + (int) nz;
            src.sendSuccess(() -> Component.literal("§7[§aTP§7] §f" + tpCmd)
                .withStyle(s -> s.withClickEvent(
                    new ClickEvent(ClickEvent.Action.RUN_COMMAND, tpCmd))), false);
            return 1;
        } catch (IllegalArgumentException e) {
            src.sendFailure(Component.literal("§cНеверный UUID"));
            return 0;
        }
    }

    private static int cmdNpcTp(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        ServerPlayer player = src.getPlayer();
        if (player == null) return 0;

        String uuidStr = StringArgumentType.getString(ctx, "uuid");
        try {
            UUID id = UUID.fromString(uuidStr);
            var npc = NPCRegistry.getNPC(id);
            if (npc == null) {
                src.sendFailure(Component.literal("§cNPC не найден"));
                return 0;
            }
            ServerLevel level = (ServerLevel) player.level();
            player.teleportTo(level,
                npc.getX(), npc.getY() + 1.0, npc.getZ(),
                player.getYRot(), player.getXRot());
            src.sendSuccess(() -> Component.literal(
                "§aТелепорт к §f" + npc.getCustomNameTag()), false);
            return 1;
        } catch (IllegalArgumentException e) {
            src.sendFailure(Component.literal("§cНеверный UUID"));
            return 0;
        }
    }

    private static int cmdNpcKill(CommandContext<CommandSourceStack> ctx) {
        try {
            UUID id = UUID.fromString(StringArgumentType.getString(ctx, "uuid"));
            LiveNPCEntity npc = NPCRegistry.getNPC(id);
            if (npc == null) { ctx.getSource().sendFailure(Component.literal("§cНе найден")); return 0; }
            npc.discard();
            NPCRegistry.unregister(id);
            ctx.getSource().sendSuccess(() -> Component.literal("§aУдалён"), true);
            return 1;
        } catch (IllegalArgumentException e) {
            ctx.getSource().sendFailure(Component.literal("§cНеверный UUID"));
            return 0;
        }
    }

    private static int spawnNpc(CommandContext<CommandSourceStack> ctx, int count) {
        CommandSourceStack src = ctx.getSource();
        ServerPlayer player = src.getPlayer();
        if (player == null) { src.sendFailure(Component.literal("§cТолько для игроков")); return 0; }
        ServerLevel level = src.getLevel();
        if (NPCRegistry.getTotalCount() + count > LiveMineConfig.maxTotalNpcs()) {
            src.sendFailure(Component.literal("§cЛимит")); return 0;
        }
        BlockPos base = player.blockPosition();
        var nearest = VillageManager.getInstance().getNearestVillage(base.getX(), base.getZ(), 128);
        String rawId = nearest != null ? nearest.rawId() : "";
        int spawned = 0;
        for (int i = 0; i < count; i++) {
            double ox = (level.random.nextDouble() - 0.5) * 6;
            double oz = (level.random.nextDouble() - 0.5) * 6;
            LiveNPCEntity npc = ModEntities.LIVE_NPC.get().create(level);
            if (npc == null) continue;
            npc.moveTo(base.getX() + 0.5 + ox, base.getY(), base.getZ() + 0.5 + oz, 0, 0);
            npc.setCustomNameTag(com.livemine.NamePool.getInstance().generateName(level.random.nextBoolean()));
            npc.setAgeInDays(18 + level.random.nextInt(40));
            if (!rawId.isEmpty()) npc.setVillageRawId(rawId);
            level.addFreshEntity(npc);
            NPCRegistry.register(npc);
            CompoundTag tag = LiveMineSavedData.get(level).loadNPCData(npc.getUUID());
            tag.putDouble("health", 20.0);
            tag.putDouble("hunger", 100.0);
            tag.putDouble("energy", 100.0);
            tag.putDouble("social", 100.0);
            tag.putString("current_goal", "WANDER");
            tag.putString("village_id", rawId);
            tag.putBoolean("dead", false);
            LiveMineSavedData.get(level).saveNPCData(npc.getUUID(), tag);
            spawned++;
        }
        final int fs = spawned;
        final String vInfo = nearest != null ? nearest.name() : "нет";
        src.sendSuccess(() -> Component.literal("§aЗаспавнено: " + fs + " (деревня: " + vInfo + ")"), true);
        return spawned;
    }

    // =========================================================================
    // Village
    // =========================================================================

    /**
     * v3.0: показывает X Y Z + кликабельный [TP].
     */
    private static int cmdVillageList(CommandSourceStack src) {
        var villages = VillageManager.getInstance().getAllVillages();
        if (villages.isEmpty()) {
            src.sendSuccess(() -> Component.literal("§7Нет деревень"), false);
            return 0;
        }
        src.sendSuccess(() -> Component.literal("§6Деревни (" + villages.size() + "):"), false);
        for (var v : villages) {
            int x = v.centerX();
            int y = v.centerY();
            int z = v.centerZ();

            final String name = v.name();
            final int pop = v.population();
            final int rad = v.radius();
            final boolean ab = v.isAbandoned();

            src.sendSuccess(() -> Component.literal(
                "§7- §f" + name + " §7[" + pop + " жителей, R=" + rad + "]"
                    + (ab ? " §c[заброшена]" : " §a[активна]")), false);

            String tpCmd = "/tp @s " + x + " " + (y + 2) + " " + z;
            src.sendSuccess(() -> Component.literal(
                "  §8XYZ: §7" + x + " §7" + y + " §7" + z
                    + "  §7[§aTP§7] §f" + tpCmd)
                .withStyle(s -> s.withClickEvent(
                    new ClickEvent(ClickEvent.Action.RUN_COMMAND, tpCmd))), false);
        }
        return villages.size();
    }

    private static int cmdVillageList(CommandContext<CommandSourceStack> ctx) {
        return cmdVillageList(ctx.getSource());
    }

    private static int cmdVillageNearest(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = ctx.getSource().getPlayer();
        if (player == null) return 0;
        var nearest = VillageManager.getInstance().getNearestVillage(player.getBlockX(), player.getBlockZ());
        if (nearest == null) {
            ctx.getSource().sendSuccess(() -> Component.literal("§7Нет рядом"), false);
            return 0;
        }
        int x = nearest.centerX();
        int y = nearest.centerY();
        int z = nearest.centerZ();
        final String name = nearest.name();
        final int pop = nearest.population();

        ctx.getSource().sendSuccess(() -> Component.literal(
            "§6Ближайшая: §f" + name + " §7(" + pop + " жителей)"
        ), false);

        String tpCmd = "/tp @s " + x + " " + (y + 2) + " " + z;
        ctx.getSource().sendSuccess(() -> Component.literal(
            "  §8XYZ: §7" + x + " §7" + y + " §7" + z
                + "  §7[§aTP§7] §f" + tpCmd)
            .withStyle(s -> s.withClickEvent(
                new ClickEvent(ClickEvent.Action.RUN_COMMAND, tpCmd))), false);
        return 1;
    }

    private static int cmdVillageTp(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        ServerPlayer player = src.getPlayer();
        if (player == null) {
            src.sendFailure(Component.literal("§cТолько для игроков"));
            return 0;
        }

        String idStr = StringArgumentType.getString(ctx, "id");

        // 1. Поиск по rawId или UUID.
        VillageRecord village = VillageManager.getInstance().getVillageByStringId(idStr);
        if (village == null) {
            try {
                UUID uuid = UUID.fromString(idStr);
                village = VillageManager.getInstance().getVillage(uuid);
            } catch (IllegalArgumentException ignored) {}
        }

        // 2. Поиск по имени.
        if (village == null) {
            for (var v : VillageManager.getInstance().getAllVillages()) {
                if (v.name().equals(idStr)) {
                    village = v;
                    break;
                }
            }
        }

        if (village == null) {
            src.sendFailure(Component.literal("§cДеревня не найдена: " + idStr));
            src.sendSuccess(() -> Component.literal(
                "§7Использование: §f/lm village tp <имя или rawId или UUID>"), false);
            src.sendSuccess(() -> Component.literal(
                "§7Список: §f/lm village list"), false);
            return 0;
        }

        ServerLevel level = (ServerLevel) player.level();

        int x = village.centerX();
        int y = village.centerY();
        int z = village.centerZ();

        // Страховка: если Y низкий — поднять.
        if (y <= level.getMinBuildHeight() + 5) {
            y = level.getHeight(
                net.minecraft.world.level.levelgen.Heightmap.Types.WORLD_SURFACE, x, z);
        }

        final int fx = x;
        final int fy = y;
        final int fz = z;
        final String fname = village.name();

        player.teleportTo(level, x + 0.5, y + 2.0, z + 0.5,
            player.getYRot(), player.getXRot());

        src.sendSuccess(() -> Component.literal(
            "§aТелепорт в §f" + fname + "§a @ §f" + fx + " " + fy + " " + fz), false);
        return 1;
    }

    private static int cmdVillageInfo(CommandContext<CommandSourceStack> ctx) {
        String id = StringArgumentType.getString(ctx, "id");
        VillageData vd = new VillageData(id, ctx.getSource().getLevel());
        if (!vd.exists()) {
            ctx.getSource().sendFailure(Component.literal("§cНе найдена"));
            return 0;
        }
        int x = vd.getCenter() != null ? vd.getCenter().getX() : 0;
        int y = vd.getCenter() != null ? vd.getCenter().getY() : 0;
        int z = vd.getCenter() != null ? vd.getCenter().getZ() : 0;
        final int fx = x, fy = y, fz = z;

        ctx.getSource().sendSuccess(() -> Component.literal("§6=== " + id + " ==="), false);
        ctx.getSource().sendSuccess(() -> Component.literal("§7Население: §f" + vd.getPopulation()), false);
        ctx.getSource().sendSuccess(() -> Component.literal("§7Радиус: §f" + vd.getRadius()), false);
        ctx.getSource().sendSuccess(() -> Component.literal("§7Ресурсы: §f" + String.format("%.1f", vd.getResources())), false);
        ctx.getSource().sendSuccess(() -> Component.literal("§7Хроника: §f" + vd.getChronicle().getEntryCount()), false);
        ctx.getSource().sendSuccess(() -> Component.literal("§7Память: §f" + vd.getMemory().size()), false);

        String tpCmd = "/tp @s " + fx + " " + (fy + 2) + " " + fz;
        ctx.getSource().sendSuccess(() -> Component.literal(
            "§7XYZ: §f" + fx + " " + fy + " " + fz
                + "  §7[§aTP§7] §f" + tpCmd)
            .withStyle(s -> s.withClickEvent(
                new ClickEvent(ClickEvent.Action.RUN_COMMAND, tpCmd))), false);
        return 1;
    }

    private static int cmdVillageCreate(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = ctx.getSource().getPlayer();
        if (player == null) return 0;
        String name = StringArgumentType.getString(ctx, "name");
        VillageManager.getInstance().createVillage(name, player.blockPosition(),
            ctx.getSource().getLevel(), "generic");
        ctx.getSource().sendSuccess(() -> Component.literal("§aСоздана: " + name), true);
        return 1;
    }

    // =========================================================================
    // Debug
    // =========================================================================

    private static int cmdDebugBrain(CommandContext<CommandSourceStack> ctx) {
        try {
            UUID id = UUID.fromString(StringArgumentType.getString(ctx, "uuid"));
            LiveNPCEntity npc = NPCRegistry.getNPC(id);
            if (npc == null) {
                ctx.getSource().sendFailure(Component.literal("§cНе найден"));
                return 0;
            }
            CompoundTag tag = LiveMineSavedData.get(ctx.getSource().getLevel()).loadNPCData(id);
            ctx.getSource().sendSuccess(() -> Component.literal("§6=== Brain Debug ==="), false);
            ctx.getSource().sendSuccess(() -> Component.literal("§7Имя: §f" + npc.getCustomNameTag()), false);
            ctx.getSource().sendSuccess(() -> Component.literal("§7Цель: §f" + npc.getNpcBrain().getCurrentGoalName()), false);
            ctx.getSource().sendSuccess(() -> Component.literal("§7Состояние: §f" + NPCRegistry.getActivityState(id)), false);
            ctx.getSource().sendSuccess(() -> Component.literal("§7Hunger: §f" + tag.getDouble("hunger")), false);
            ctx.getSource().sendSuccess(() -> Component.literal("§7Energy: §f" + tag.getDouble("energy")), false);
            ctx.getSource().sendSuccess(() -> Component.literal("§7Health: §f" + tag.getDouble("health")), false);
            return 1;
        } catch (IllegalArgumentException e) {
            ctx.getSource().sendFailure(Component.literal("§cНеверный UUID"));
            return 0;
        }
    }
}