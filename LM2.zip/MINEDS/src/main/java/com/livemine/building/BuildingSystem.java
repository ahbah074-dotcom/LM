package com.livemine.building;

import com.livemine.LiveMineMod;
import com.livemine.VillageData;
import com.livemine.entity.LiveNPCEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Система строительства.
 *
 * v2.0: пошаговое строительство для NPC через tryBuildNextStep.
 */
public final class BuildingSystem {

    private static BuildingSystem INSTANCE;

    public enum BuildingType {
        HOUSE_SMALL, HOUSE_MEDIUM, HOUSE_LARGE, FARMHOUSE,
        STORAGE, FORGE, BAKERY, BARRACKS, WATCHTOWER,
        WELL, BRIDGE, ROAD, FENCE_GATE, DOCK,
        LIGHTHOUSE, LIBRARY, INFIRMARY, SHRINE
    }

    public static final class BuildingElement {
        public final BlockPos offset;
        public final BlockState block;
        public final String tag;

        public BuildingElement(int x, int y, int z, BlockState block, String tag) {
            this.offset = new BlockPos(x, y, z);
            this.block = block;
            this.tag = tag != null ? tag : "";
        }
    }

    public static final class BuildingPlan {
        public final BuildingType type;
        public final String name;
        public final int width, height, depth;
        public final int requiredSkillLevel;
        public final int estimatedTimeTicks;
        public final List<BuildingElement> elements = new ArrayList<>();

        public BuildingPlan(BuildingType type, String name, int w, int h, int d,
                             int skill, int time) {
            this.type = type;
            this.name = name;
            this.width = w;
            this.height = h;
            this.depth = d;
            this.requiredSkillLevel = skill;
            this.estimatedTimeTicks = time;
        }

        public void add(BuildingElement e) { elements.add(e); }
        public int size() { return elements.size(); }
    }

    private final Map<BuildingType, BuildingPlan> plans = new EnumMap<>(BuildingType.class);

    private BuildingSystem() {
        initPlans();
    }

    public static synchronized BuildingSystem getInstance() {
        if (INSTANCE == null) INSTANCE = new BuildingSystem();
        return INSTANCE;
    }

    // =========================================================================
    // Шаблоны (5 базовых)
    // =========================================================================

    private void initPlans() {

        // HOUSE_SMALL 5×4×5
        BuildingPlan small = new BuildingPlan(BuildingType.HOUSE_SMALL, "Малый дом", 5, 4, 5, 1, 600);
        for (int x = 0; x < 5; x++) {
            for (int z = 0; z < 5; z++) {
                small.add(new BuildingElement(x, 0, z, Blocks.OAK_PLANKS.defaultBlockState(), "floor"));
            }
        }
        for (int y = 1; y <= 3; y++) {
            for (int x = 0; x < 5; x++) {
                small.add(new BuildingElement(x, y, 0, Blocks.OAK_LOG.defaultBlockState(), "wall"));
                small.add(new BuildingElement(x, y, 4, Blocks.OAK_LOG.defaultBlockState(), "wall"));
            }
            for (int z = 1; z < 4; z++) {
                small.add(new BuildingElement(0, y, z, Blocks.OAK_LOG.defaultBlockState(), "wall"));
                small.add(new BuildingElement(4, y, z, Blocks.OAK_LOG.defaultBlockState(), "wall"));
            }
        }
        small.add(new BuildingElement(2, 1, 0, Blocks.OAK_DOOR.defaultBlockState(), "door"));
        small.add(new BuildingElement(2, 2, 0, Blocks.AIR.defaultBlockState(), "door_top"));
        for (int x = 0; x < 5; x++) {
            for (int z = 0; z < 5; z++) {
                small.add(new BuildingElement(x, 4, z, Blocks.OAK_SLAB.defaultBlockState(), "roof"));
            }
        }
        small.add(new BuildingElement(2, 3, 2, Blocks.TORCH.defaultBlockState(), "light"));
        plans.put(BuildingType.HOUSE_SMALL, small);

        // HOUSE_MEDIUM 7×5×7
        BuildingPlan medium = new BuildingPlan(BuildingType.HOUSE_MEDIUM, "Средний дом", 7, 5, 7, 3, 1200);
        for (int x = 0; x < 7; x++) {
            for (int z = 0; z < 7; z++) {
                medium.add(new BuildingElement(x, 0, z, Blocks.OAK_PLANKS.defaultBlockState(), "floor"));
            }
        }
        for (int y = 1; y <= 4; y++) {
            for (int x = 0; x < 7; x++) {
                medium.add(new BuildingElement(x, y, 0, Blocks.OAK_LOG.defaultBlockState(), "wall"));
                medium.add(new BuildingElement(x, y, 6, Blocks.OAK_LOG.defaultBlockState(), "wall"));
            }
            for (int z = 1; z < 6; z++) {
                medium.add(new BuildingElement(0, y, z, Blocks.OAK_LOG.defaultBlockState(), "wall"));
                medium.add(new BuildingElement(6, y, z, Blocks.OAK_LOG.defaultBlockState(), "wall"));
            }
        }
        medium.add(new BuildingElement(3, 1, 0, Blocks.OAK_DOOR.defaultBlockState(), "door"));
        medium.add(new BuildingElement(3, 2, 0, Blocks.AIR.defaultBlockState(), "door_top"));
        for (int y = 2; y <= 3; y++) {
            medium.add(new BuildingElement(2, y, 0, Blocks.GLASS_PANE.defaultBlockState(), "window"));
            medium.add(new BuildingElement(4, y, 0, Blocks.GLASS_PANE.defaultBlockState(), "window"));
        }
        for (int x = 0; x < 7; x++) {
            for (int z = 0; z < 7; z++) {
                medium.add(new BuildingElement(x, 5, z, Blocks.OAK_SLAB.defaultBlockState(), "roof"));
            }
        }
        plans.put(BuildingType.HOUSE_MEDIUM, medium);

        // FORGE 6×5×6
        BuildingPlan forge = new BuildingPlan(BuildingType.FORGE, "Кузница", 6, 5, 6, 3, 1400);
        for (int x = 0; x < 6; x++) {
            for (int z = 0; z < 6; z++) {
                forge.add(new BuildingElement(x, 0, z, Blocks.STONE_BRICKS.defaultBlockState(), "floor"));
            }
        }
        for (int y = 1; y <= 3; y++) {
            for (int x = 0; x < 6; x++) {
                forge.add(new BuildingElement(x, y, 0, Blocks.STONE_BRICKS.defaultBlockState(), "wall"));
                forge.add(new BuildingElement(x, y, 5, Blocks.STONE_BRICKS.defaultBlockState(), "wall"));
            }
            for (int z = 1; z < 5; z++) {
                forge.add(new BuildingElement(0, y, z, Blocks.STONE_BRICKS.defaultBlockState(), "wall"));
                forge.add(new BuildingElement(5, y, z, Blocks.STONE_BRICKS.defaultBlockState(), "wall"));
            }
        }
        forge.add(new BuildingElement(2, 1, 0, Blocks.OAK_DOOR.defaultBlockState(), "door"));
        forge.add(new BuildingElement(2, 2, 0, Blocks.AIR.defaultBlockState(), "door_top"));
        forge.add(new BuildingElement(2, 1, 3, Blocks.FURNACE.defaultBlockState(), "furnace"));
        forge.add(new BuildingElement(3, 1, 3, Blocks.ANVIL.defaultBlockState(), "anvil"));
        for (int x = 0; x < 6; x++) {
            for (int z = 0; z < 6; z++) {
                forge.add(new BuildingElement(x, 4, z, Blocks.STONE_SLAB.defaultBlockState(), "roof"));
            }
        }
        plans.put(BuildingType.FORGE, forge);

        // WELL 3×4×3
        BuildingPlan well = new BuildingPlan(BuildingType.WELL, "Колодец", 3, 4, 3, 1, 300);
        well.add(new BuildingElement(0, 0, 0, Blocks.COBBLESTONE.defaultBlockState(), "base"));
        well.add(new BuildingElement(1, 0, 0, Blocks.COBBLESTONE.defaultBlockState(), "base"));
        well.add(new BuildingElement(2, 0, 0, Blocks.COBBLESTONE.defaultBlockState(), "base"));
        well.add(new BuildingElement(0, 0, 1, Blocks.COBBLESTONE.defaultBlockState(), "base"));
        well.add(new BuildingElement(1, 0, 1, Blocks.WATER.defaultBlockState(), "water"));
        well.add(new BuildingElement(2, 0, 1, Blocks.COBBLESTONE.defaultBlockState(), "base"));
        well.add(new BuildingElement(0, 0, 2, Blocks.COBBLESTONE.defaultBlockState(), "base"));
        well.add(new BuildingElement(1, 0, 2, Blocks.COBBLESTONE.defaultBlockState(), "base"));
        well.add(new BuildingElement(2, 0, 2, Blocks.COBBLESTONE.defaultBlockState(), "base"));
        well.add(new BuildingElement(0, 1, 0, Blocks.OAK_FENCE.defaultBlockState(), "fence"));
        well.add(new BuildingElement(2, 1, 0, Blocks.OAK_FENCE.defaultBlockState(), "fence"));
        well.add(new BuildingElement(0, 1, 2, Blocks.OAK_FENCE.defaultBlockState(), "fence"));
        well.add(new BuildingElement(2, 1, 2, Blocks.OAK_FENCE.defaultBlockState(), "fence"));
        well.add(new BuildingElement(0, 2, 0, Blocks.OAK_SLAB.defaultBlockState(), "roof"));
        well.add(new BuildingElement(2, 2, 2, Blocks.OAK_SLAB.defaultBlockState(), "roof"));
        well.add(new BuildingElement(1, 3, 1, Blocks.OAK_PLANKS.defaultBlockState(), "roof_top"));
        plans.put(BuildingType.WELL, well);

        // WATCHTOWER 3×8×3
        BuildingPlan tower = new BuildingPlan(BuildingType.WATCHTOWER, "Башня", 3, 8, 3, 2, 900);
        for (int y = 0; y <= 6; y++) {
            for (int x = 0; x < 3; x++) {
                for (int z = 0; z < 3; z++) {
                    if (x == 1 && z == 1) continue;
                    tower.add(new BuildingElement(x, y, z, Blocks.STONE_BRICKS.defaultBlockState(), "wall"));
                }
            }
        }
        for (int x = 0; x < 3; x++) {
            for (int z = 0; z < 3; z++) {
                tower.add(new BuildingElement(x, 7, z, Blocks.OAK_PLANKS.defaultBlockState(), "platform"));
            }
        }
        tower.add(new BuildingElement(1, 8, 1, Blocks.TORCH.defaultBlockState(), "light"));
        plans.put(BuildingType.WATCHTOWER, tower);
    }

    // =========================================================================
    // Публичное API
    // =========================================================================

    public BuildingPlan getPlan(BuildingType type) { return plans.get(type); }
    public Set<BuildingType> getAvailableTypes() { return plans.keySet(); }

    public boolean validateLocation(Level level, BlockPos origin, BuildingType type) {
        BuildingPlan plan = plans.get(type);
        if (plan == null) return false;
        for (BuildingElement e : plan.elements) {
            BlockPos pos = origin.offset(e.offset);
            BlockState existing = level.getBlockState(pos);
            if (!existing.canBeReplaced() && !existing.isAir()
                && !(e.block.isAir() && !existing.isAir())) {
                return false;
            }
        }
        return true;
    }

    public boolean build(Level level, BlockPos origin, BuildingType type, int builderSkillLevel) {
        BuildingPlan plan = plans.get(type);
        if (plan == null) return false;
        if (builderSkillLevel < plan.requiredSkillLevel) return false;
        if (!validateLocation(level, origin, type)) return false;

        for (BuildingElement e : plan.elements) {
            level.setBlock(origin.offset(e.offset), e.block, 3);
        }

        LiveMineMod.LOGGER.info("Built {} at {}", plan.name, origin);
        return true;
    }

    // =========================================================================
    // v2.0: Пошаговое строительство для NPC
    // =========================================================================

    /**
     * Ставит один блок из плана по индексу step.
     * NPC вызывает с увеличивающимся step раз в несколько тиков.
     *
     * @return true, если блок установлен, false если нужен другой подход
     */
    public boolean tryBuildNextStep(LiveNPCEntity npc, ServerLevel level,
                                     BlockPos origin, BuildingType type, int step) {
        BuildingPlan plan = plans.get(type);
        if (plan == null) return false;
        if (step < 0 || step >= plan.size()) return false;
        if (npc.getSkills() == null) return false;

        double building = npc.getSkills().getLevel(com.livemine.NPCSkills.SkillType.BUILDING);
        if (building < plan.requiredSkillLevel) return false;

        BuildingElement element = plan.elements.get(step);
        BlockPos pos = origin.offset(element.offset);

        BlockState existing = level.getBlockState(pos);
        if (existing.getBlock() == element.block.getBlock()) return true;
        if (!existing.canBeReplaced() && !existing.isAir()) return false;

        level.setBlock(pos, element.block, 3);

        // Немного XP за каждый блок.
        long day = level.getDayTime() / 24000L;
        npc.getSkills().addXP(com.livemine.NPCSkills.SkillType.BUILDING, 0.005, day);

        // Регистрируем в деревне при первом блоке.
        if (step == 0) {
            try {
                String rawId = npc.getVillageRawId();
                if (!rawId.isEmpty()) {
                    VillageData vd = new VillageData(rawId, level);
                    if (vd.exists()) {
                        vd.addChronicleEntry(com.livemine.Chronicle.EntryType.BUILDING, day,
                            "Начато строительство: " + plan.name + " @ " + origin,
                            npc.getCustomNameTag());
                    }
                }
            } catch (Exception e) {
                LiveMineMod.LOGGER.error("BuildingSystem: chronicle write failed", e);
            }
        }

        return true;
    }

    /**
     * Возвращает true, если план завершён.
     */
    public boolean isComplete(BuildingType type) {
        BuildingPlan plan = plans.get(type);
        return plan != null;
    }

    public int getPlanSize(BuildingType type) {
        BuildingPlan plan = plans.get(type);
        return plan != null ? plan.size() : 0;
    }

    public int getBuildTime(BuildingType type) {
        BuildingPlan plan = plans.get(type);
        return plan != null ? plan.estimatedTimeTicks : 0;
    }

    public int getRequiredSkill(BuildingType type) {
        BuildingPlan plan = plans.get(type);
        return plan != null ? plan.requiredSkillLevel : 1;
    }
}