package com.livemine.building;

import com.livemine.LiveMineMod;
import com.livemine.VillageData;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;

/**
 * Планировщик строительства в деревне.
 *
 * Решает:
 *   - Какое здание строить следующим.
 *   - Где его разместить (свободная площадка).
 *
 * Не управляет процессом постройки — это делает WorkGoal через
 * BuildingSystem.tryBuildNextStep.
 */
public final class VillageBuildingPlanner {

    /** Радиус поиска свободной площадки от центра деревни. */
    private static final int MIN_RADIUS = 12;
    private static final int MAX_RADIUS = 48;

    private VillageBuildingPlanner() {}

    /**
     * Определяет следующее здание для постройки в деревне.
     * @return тип здания или null, если строить нечего.
     */
    public static BuildingSystem.BuildingType decideNextBuilding(VillageData vd, ServerLevel level) {
        if (vd == null || !vd.exists()) return null;

        // 1. Колодец — базовая инфраструктура.
        if (vd.getStructures(com.livemine.blocks.CommunalFirePitBlock.class).isEmpty()
            && vd.getStructures(com.livemine.blocks.VillageCenterBlock.class).size() >= 1) {
            return BuildingSystem.BuildingType.WELL;
        }

        // 2. Кузница — производство.
        if (vd.getStructures(com.livemine.blocks.WorkshopForgeBlock.class).isEmpty()) {
            return BuildingSystem.BuildingType.FORGE;
        }

        // 3. Дозорная башня — защита.
        long countTowers = countBlockEntitiesByClass(level, vd, "WatchtowerBlockEntity");
        if (vd.getStructures(com.livemine.blocks.VillageCenterBlock.class).size() > 1) {
            // Упрощённая эвристика: если населения больше 8 — нужна башня.
            if (vd.getPopulation() >= 8) {
                return BuildingSystem.BuildingType.WATCHTOWER;
            }
        }

        // 4. Средний дом — для роста населения.
        if (vd.getPopulation() >= 6) {
            return BuildingSystem.BuildingType.HOUSE_MEDIUM;
        }

        // 5. Малый дом — базовое жильё.
        return BuildingSystem.BuildingType.HOUSE_SMALL;
    }

    /**
     * Ищет свободную площадку для постройки.
     * Возвращает минимальный угол (origin) или null.
     */
    public static BlockPos findFreeSpot(ServerLevel level, VillageData vd,
                                         BuildingSystem.BuildingType type) {
        if (vd == null || vd.getCenter() == null) return null;

        var plan = BuildingSystem.getInstance().getPlan(type);
        if (plan == null) return null;

        BlockPos center = vd.getCenter();

        // Ищем площадку по спирали.
        for (int radius = MIN_RADIUS; radius <= MAX_RADIUS; radius += 4) {
            for (int attempt = 0; attempt < 16; attempt++) {
                double angle = 2 * Math.PI * (attempt / 16.0) + Math.random() * 0.3;

                int dx = (int) (Math.cos(angle) * radius);
                int dz = (int) (Math.sin(angle) * radius);

                BlockPos candidate = new BlockPos(
                    center.getX() + dx,
                    center.getY(),
                    center.getZ() + dz
                );

                // Находим правильный Y.
                int y = level.getHeight(
                    net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                    candidate.getX(), candidate.getZ());

                BlockPos origin = new BlockPos(candidate.getX(), y, candidate.getZ());

                if (isAreaFree(level, origin, plan.width, plan.height, plan.depth)) {
                    return origin;
                }
            }
        }

        return null;
    }

    /**
     * Проверяет, что прямоугольная область свободна.
     */
    private static boolean isAreaFree(ServerLevel level, BlockPos origin, int w, int h, int d) {
        for (int x = 0; x < w; x++) {
            for (int z = 0; z < d; z++) {
                for (int y = 0; y < h; y++) {
                    BlockPos pos = origin.offset(x, y, z);
                    var state = level.getBlockState(pos);

                    if (!state.isAir() && !state.canBeReplaced()) {
                        return false;
                    }
                }
            }
        }

        // Проверяем, что основание — твёрдое (не вода, не лава).
        for (int x = 0; x < w; x++) {
            for (int z = 0; z < d; z++) {
                BlockPos below = origin.offset(x, -1, z);
                var belowState = level.getBlockState(below);
                if (belowState.isAir() || !belowState.getFluidState().isEmpty()) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Утилита для подсчёта BE по имени класса (без ссылок на несуществующие классы).
     */
    private static long countBlockEntitiesByClass(ServerLevel level, VillageData vd, String className) {
        long count = 0;
        // Пока заглушка — возвращаем 0.
        return count;
    }
}