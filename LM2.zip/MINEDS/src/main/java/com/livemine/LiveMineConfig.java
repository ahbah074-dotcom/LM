package com.livemine;

import net.neoforged.neoforge.common.ModConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

/**
 * Конфигурация LiveMine.
 *
 * Содержит:
 *   - COMMON (сервер + клиент): лимиты, оптимизация, геймплей
 *   - CLIENT: визуал, звуки, UI
 *
 * Hot reload применяется только к безопасным параметрам
 * (СЃРј. isHotReloadable РІ ServerConfig).
 */
public final class LiveMineConfig {

    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec CLIENT_SPEC;

    public static final Common COMMON;
    public static final Client CLIENT;

    static {
        // === COMMON ===
        Pair<Common, ModConfigSpec> commonPair = new ModConfigSpec.Builder().configure(Common::new);
        COMMON = commonPair.getLeft();
        SPEC = commonPair.getRight();

        // === CLIENT ===
        Pair<Client, ModConfigSpec> clientPair = new ModConfigSpec.Builder().configure(Client::new);
        CLIENT = clientPair.getLeft();
        CLIENT_SPEC = clientPair.getRight();
    }

    // =========================================================================
    // COMMON — сервер + клиент
    // =========================================================================
    public static final class Common {

        // --- NPC ---
        public final ModConfigSpec.IntValue maxTotalNpcs;
        public final ModConfigSpec.IntValue maxNpcsPerVillage;
        public final ModConfigSpec.IntValue maxActivePerPlayer;
        public final ModConfigSpec.BooleanValue brainDebug;
        public final ModConfigSpec.BooleanValue showGuideOnFirstJoin;

        // --- Оптимизация ---
        public final ModConfigSpec.BooleanValue adaptiveTickRate;
        public final ModConfigSpec.IntValue simulationInterval;
        public final ModConfigSpec.IntValue batchPerTick;
        public final ModConfigSpec.IntValue activeRadius;
        public final ModConfigSpec.IntValue simulatedRadius;
        public final ModConfigSpec.IntValue dormantRadius;
        public final ModConfigSpec.IntValue resourceCacheTtl;

        // --- Мир и генерация ---
        public final ModConfigSpec.BooleanValue enableVillageGeneration;
        public final ModConfigSpec.IntValue minVillages;
        public final ModConfigSpec.IntValue maxVillages;
        public final ModConfigSpec.IntValue minDistanceFromSpawn;
        public final ModConfigSpec.IntValue maxDistanceFromSpawn;
        public final ModConfigSpec.IntValue minDistanceBetweenVillages;
        public final ModConfigSpec.IntValue npcPerNewVillage;

        // --- Геймплей ---
        public final ModConfigSpec.BooleanValue enableHolidays;
        public final ModConfigSpec.BooleanValue enableVoting;
        public final ModConfigSpec.BooleanValue enableEconomy;
        public final ModConfigSpec.BooleanValue enableMigration;
        public final ModConfigSpec.BooleanValue enableWeatherEffects;
        public final ModConfigSpec.BooleanValue enableDiseases;
        public final ModConfigSpec.BooleanValue enableWanderers;
        public final ModConfigSpec.BooleanValue enableAbandonedVillages;
        public final ModConfigSpec.IntValue villageDecayDays;

        // --- Баланс ---
        public final ModConfigSpec.DoubleValue skillDecayPerDay;
        public final ModConfigSpec.DoubleValue skillRelearnMultiplierHigh;
        public final ModConfigSpec.DoubleValue skillRelearnMultiplierLow;
        public final ModConfigSpec.IntValue minTrustForGroup;
        public final ModConfigSpec.IntValue adultAgeDays;
        public final ModConfigSpec.IntValue elderlyAgeDays;

        // --- Безопасность ---
        public final ModConfigSpec.IntValue maxPacketSizeBytes;
        public final ModConfigSpec.IntValue maxPacketRatePerSecond;
        public final ModConfigSpec.BooleanValue allowClientStateChanges;

        Common(ModConfigSpec.Builder b) {
            // ---------- NPC ----------
            b.comment("Общие лимиты и параметры NPC").push("npc");
            maxTotalNpcs = b
                .comment("Максимум NPC на всём сервере (ACTIVE + SIMULATED + DORMANT).",
                        "При i7-12700K / 16GB: 1000 — комфортно, 10000 — максимум для тестов.")
                .defineInRange("maxTotalNpcs", 1000, 10, 10000);
            maxNpcsPerVillage = b
                .comment("Максимум NPC в одной деревне.")
                .defineInRange("maxNpcsPerVillage", 128, 1, 1000);
            maxActivePerPlayer = b
                .comment("Потолок ACTIVE NPC на одного игрока.",
                        "Остальные NPC в радиусе становятся SIMULATED.")
                .defineInRange("maxActivePerPlayer", 50, 1, 500);
            brainDebug = b
                .comment("Подробный лог Brain (только для администратора).")
                .define("brainDebug", false);
            showGuideOnFirstJoin = b
                .comment("Показывать справочник при первом входе.")
                .define("showGuideOnFirstJoin", true);
            b.pop();

            // ---------- Оптимизация ----------
            b.comment("Параметры производительности").push("optimization");
            adaptiveTickRate = b
                .comment("Адаптивная частота тиков — подстраивается под TPS.")
                .define("adaptiveTickRate", true);
            simulationInterval = b
                .comment("Базовый интервал симуляции в тиках (по умолчанию 200 = 10 сек).")
                .defineInRange("simulationInterval", 200, 20, 24000);
            batchPerTick = b
                .comment("Сколько SIMULATED NPC обрабатывать за один тик.")
                .defineInRange("batchPerTick", 12, 1, 100);
            activeRadius = b
                .comment("Радиус активности в блоках — NPC в радиусе становятся ACTIVE.")
                .defineInRange("activeRadius", 96, 16, 512);
            simulatedRadius = b
                .comment("Радиус симуляции в блоках — NPC становятся SIMULATED.")
                .defineInRange("simulatedRadius", 256, 32, 1024);
            dormantRadius = b
                .comment("Радиус DORMANT — дальше NPC замораживаются.")
                .defineInRange("dormantRadius", 1024, 256, 4096);
            resourceCacheTtl = b
                .comment("TTL кэша ресурсов в тиках (6000 = 5 минут).")
                .defineInRange("resourceCacheTtl", 6000, 200, 24000);
            b.pop();

            // ---------- Мир и генерация ----------
            b.comment("Генерация деревень при создании мира").push("worldgen");
            enableVillageGeneration = b
                .comment("Включить генерацию деревень LiveMine.")
                .define("enableVillageGeneration", true);
            minVillages = b.comment("Минимум деревень на карту.").defineInRange("minVillages", 3, 1, 20);
            maxVillages = b.comment("Максимум деревень на карту.").defineInRange("maxVillages", 5, 1, 20);
            minDistanceFromSpawn = b.comment("Минимальное расстояние от точки спавна игрока.")
                .defineInRange("minDistanceFromSpawn", 500, 100, 5000);
            maxDistanceFromSpawn = b.comment("Максимальное расстояние от точки спавна.")
                .defineInRange("maxDistanceFromSpawn", 1000, 100, 5000);
            minDistanceBetweenVillages = b.comment("Минимум между деревнями.")
                .defineInRange("minDistanceBetweenVillages", 300, 100, 3000);
            npcPerNewVillage = b.comment("Сколько NPC спавнится при генерации деревни.")
                .defineInRange("npcPerNewVillage", 25, 5, 100);
            b.pop();

            // ---------- Геймплей ----------
            b.comment("Игровые системы").push("gameplay");
            enableHolidays = b.comment("Праздники.").define("enableHolidays", true);
            enableVoting = b.comment("Голосования.").define("enableVoting", true);
            enableEconomy = b.comment("Р­РєРѕРЅРѕРјРёРєР°.").define("enableEconomy", true);
            enableMigration = b.comment("Миграция данных.").define("enableMigration", true);
            enableWeatherEffects = b.comment("Эффекты погоды.").define("enableWeatherEffects", true);
            enableDiseases = b.comment("Болезни.").define("enableDiseases", true);
            enableWanderers = b.comment("Странники.").define("enableWanderers", true);
            enableAbandonedVillages = b.comment("Заброшенные деревни.")
                .define("enableAbandonedVillages", true);
            villageDecayDays = b.comment("Дней до разрушения заброшенной деревни.")
                .defineInRange("villageDecayDays", 7, 1, 30);
            b.pop();

            // ---------- Баланс ----------
            b.comment("Баланс навыков и возраста").push("balance");
            skillDecayPerDay = b.comment("Скорость забывания навыка в день (0.10 = 10%).")
                .defineInRange("skillDecayPerDay", 0.10, 0.0, 1.0);
            skillRelearnMultiplierHigh = b.comment("Множитель переобучения для уровня ≥ 3.")
                .defineInRange("skillRelearnMultiplierHigh", 2.0, 1.0, 5.0);
            skillRelearnMultiplierLow = b.comment("Множитель переобучения для уровня 1–2.")
                .defineInRange("skillRelearnMultiplierLow", 1.5, 1.0, 5.0);
            minTrustForGroup = b.comment("Минимальный trust для формирования группы.")
                .defineInRange("minTrustForGroup", 40, 0, 100);
            adultAgeDays = b.comment("Возраст взросления в игровых днях.")
                .defineInRange("adultAgeDays", 7, 1, 100);
            elderlyAgeDays = b.comment("Возраст старости в игровых днях.")
                .defineInRange("elderlyAgeDays", 90, 30, 500);
            b.pop();

            // ---------- Безопасность ----------
            b.comment("Сетевые и серверные ограничения").push("security");
            maxPacketSizeBytes = b.comment("Максимальный размер пакета.")
                .defineInRange("maxPacketSizeBytes", 32768, 256, 1_048_576);
            maxPacketRatePerSecond = b.comment("Максимум пакетов в секунду на игрока.")
                .defineInRange("maxPacketRatePerSecond", 20, 1, 200);
            allowClientStateChanges = b.comment("Разрешить клиенту менять состояние NPC.")
                .define("allowClientStateChanges", false);
            b.pop();
        }
    }

    // =========================================================================
    // CLIENT — только клиент
    // =========================================================================
    public static final class Client {

        public final ModConfigSpec.BooleanValue enableSounds;
        public final ModConfigSpec.DoubleValue soundVolume;
        public final ModConfigSpec.BooleanValue showNpcNames;
        public final ModConfigSpec.BooleanValue showNpcHealthBar;
        public final ModConfigSpec.IntValue npcRenderDistance;
        public final ModConfigSpec.IntValue notificationDuration;
        public final ModConfigSpec.BooleanValue showThoughtBubbles;

        Client(ModConfigSpec.Builder b) {
            b.comment("Клиентские настройки LiveMine").push("client");

            enableSounds = b.comment("Включить звуки мода.").define("enableSounds", true);
            soundVolume = b.comment("Громкость звуков мода (0.0–1.0).")
                .defineInRange("soundVolume", 0.5, 0.0, 1.0);
            showNpcNames = b.comment("Показывать имена NPC.").define("showNpcNames", true);
            showNpcHealthBar = b.comment("Показывать полоску здоровья над NPC.")
                .define("showNpcHealthBar", true);
            npcRenderDistance = b.comment("Дистанция рендера NPC (в блоках).")
                .defineInRange("npcRenderDistance", 80, 16, 256);
            notificationDuration = b.comment("Длительность уведомлений (сек).")
                .defineInRange("notificationDuration", 5, 1, 30);
            showThoughtBubbles = b.comment("Показывать пузыри мыслей над NPC.")
                .define("showThoughtBubbles", true);

            b.pop();
        }
    }

    // =========================================================================
    // Геттеры (для удобства)
    // =========================================================================
    public static int maxTotalNpcs()        { return COMMON.maxTotalNpcs.get(); }
    public static int maxNpcsPerVillage()   { return COMMON.maxNpcsPerVillage.get(); }
    public static int maxActivePerPlayer()  { return COMMON.maxActivePerPlayer.get(); }
    public static boolean brainDebug()      { return COMMON.brainDebug.get(); }

    public static boolean adaptiveTickRate()      { return COMMON.adaptiveTickRate.get(); }
    public static int simulationInterval()        { return COMMON.simulationInterval.get(); }
    public static int batchPerTick()              { return COMMON.batchPerTick.get(); }
    public static int activeRadius()              { return COMMON.activeRadius.get(); }
    public static int simulatedRadius()           { return COMMON.simulatedRadius.get(); }
    public static int dormantRadius()             { return COMMON.dormantRadius.get(); }
    public static int resourceCacheTtl()          { return COMMON.resourceCacheTtl.get(); }

    public static boolean enableVillageGeneration() { return COMMON.enableVillageGeneration.get(); }
    public static int minVillages()                 { return COMMON.minVillages.get(); }
    public static int maxVillages()                 { return COMMON.maxVillages.get(); }
    public static int minDistanceFromSpawn()        { return COMMON.minDistanceFromSpawn.get(); }
    public static int maxDistanceFromSpawn()        { return COMMON.maxDistanceFromSpawn.get(); }
    public static int minDistanceBetweenVillages()  { return COMMON.minDistanceBetweenVillages.get(); }
    public static int npcPerNewVillage()            { return COMMON.npcPerNewVillage.get(); }

    public static boolean enableHolidays()          { return COMMON.enableHolidays.get(); }
    public static boolean enableVoting()            { return COMMON.enableVoting.get(); }
    public static boolean enableEconomy()           { return COMMON.enableEconomy.get(); }
    public static boolean enableMigration()         { return COMMON.enableMigration.get(); }
    public static boolean enableWeatherEffects()    { return COMMON.enableWeatherEffects.get(); }
    public static boolean enableDiseases()          { return COMMON.enableDiseases.get(); }
    public static boolean enableWanderers()         { return COMMON.enableWanderers.get(); }
    public static boolean enableAbandonedVillages() { return COMMON.enableAbandonedVillages.get(); }
    public static int villageDecayDays()            { return COMMON.villageDecayDays.get(); }

    public static double skillDecayPerDay()         { return COMMON.skillDecayPerDay.get(); }
    public static int minTrustForGroup()            { return COMMON.minTrustForGroup.get(); }
    public static int adultAgeDays()                { return COMMON.adultAgeDays.get(); }
    public static int elderlyAgeDays()              { return COMMON.elderlyAgeDays.get(); }

    public static int maxPacketSizeBytes()          { return COMMON.maxPacketSizeBytes.get(); }
    public static int maxPacketRatePerSecond()      { return COMMON.maxPacketRatePerSecond.get(); }

    public static boolean enableSounds()            { return CLIENT.enableSounds.get(); }
    public static double soundVolume()              { return CLIENT.soundVolume.get(); }
    public static boolean showNpcNames()            { return CLIENT.showNpcNames.get(); }
    public static boolean showNpcHealthBar()        { return CLIENT.showNpcHealthBar.get(); }
    public static int npcRenderDistance()           { return CLIENT.npcRenderDistance.get(); }
    public static int notificationDuration()        { return CLIENT.notificationDuration.get(); }
    public static boolean showThoughtBubbles()      { return CLIENT.showThoughtBubbles.get(); }

    private LiveMineConfig() {}
}
