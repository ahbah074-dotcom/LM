package com.livemine;

import com.livemine.domain.VillageRecord;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;

import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Менеджер деревень.
 *
 * Канонический ключ деревни в NBT — "village_" + BlockPos.asLong().
 * VillageRecord.id() — производный UUID от этого ключа.
 *
 * v3.0:
 *   - getBytes(StandardCharsets.UTF_8) — детерминированный UUID.
 *   - saveAll() использует v.rawId() вместо v.id().
 */
public final class VillageManager {

    private static VillageManager INSTANCE;

    private final Map<UUID, VillageRecord> villages = new ConcurrentHashMap<>();
    private final Map<String, UUID> idIndex = new ConcurrentHashMap<>();

    private VillageManager() {}

    public static synchronized VillageManager getInstance() {
        if (INSTANCE == null) INSTANCE = new VillageManager();
        return INSTANCE;
    }

    // === Регистрация ===

    public VillageRecord createVillage(String name, BlockPos center, ServerLevel level, String culture) {
        String idStr = "village_" + center.asLong();
        UUID id = UUID.nameUUIDFromBytes(idStr.getBytes(StandardCharsets.UTF_8));

        if (villages.containsKey(id)) {
            return villages.get(id);
        }

        VillageRecord record = new VillageRecord(
            id,
            level.dimension().location().toString(),
            center.getX(), center.getY(), center.getZ()
        );
        record.setName(name);
        record.setFoundedDay(level.getDayTime() / 24000L);
        record.setCulture(culture);

        villages.put(id, record);
        idIndex.put(idStr, id);

        // Синхронизируем с SavedData (ключ тот же: "village_" + asLong).
        VillageData.createVillage(center, level, name);

        LiveMineMod.LOGGER.info("VillageManager: created village '{}' (id={})", name, idStr);
        return record;
    }

    public VillageRecord getVillage(UUID id) {
        return villages.get(id);
    }

    public VillageRecord getVillageByStringId(String stringId) {
        UUID id = idIndex.get(stringId);
        return id != null ? villages.get(id) : null;
    }

    public Collection<VillageRecord> getAllVillages() {
        return villages.values();
    }

    public int getVillageCount() {
        return villages.size();
    }

    // === Поиск ===

    public VillageRecord getNearestVillage(int x, int z, int maxDistance) {
        VillageRecord nearest = null;
        double minDistSq = maxDistance > 0 ? (double) maxDistance * maxDistance : Double.MAX_VALUE;

        for (VillageRecord v : villages.values()) {
            if (v.isAbandoned()) continue;
            double dx = v.centerX() - x;
            double dz = v.centerZ() - z;
            double distSq = dx * dx + dz * dz;
            if (distSq < minDistSq) {
                minDistSq = distSq;
                nearest = v;
            }
        }
        return nearest;
    }

    public VillageRecord getNearestVillage(int x, int z) {
        return getNearestVillage(x, z, 0);
    }

    // === Изменения ===

    public void removeVillage(UUID id) {
        VillageRecord v = villages.remove(id);
        if (v != null) idIndex.remove(v.rawId());
    }

    public void markAbandoned(UUID id, boolean value) {
        VillageRecord v = villages.get(id);
        if (v != null) v.setAbandoned(value);
    }

    public boolean tryExpand(UUID id) {
        VillageRecord v = villages.get(id);
        if (v == null) return false;

        int currentRadius = v.radius();
        int newRadius;
        if (currentRadius < 64) newRadius = 64;
        else if (currentRadius < 96) newRadius = 96;
        else if (currentRadius < 128) newRadius = 128;
        else return false;

        v.setRadius(newRadius);
        LiveMineMod.LOGGER.info("Village {} expanded to radius {}", v.name(), newRadius);
        return true;
    }

    // === Загрузка из SavedData ===

    public void loadFromSavedData(ServerLevel level) {
        LiveMineSavedData savedData = LiveMineSavedData.get(level);
        villages.clear();
        idIndex.clear();

        for (Map.Entry<String, CompoundTag> entry : savedData.getAllVillageData().entrySet()) {
            String idStr = entry.getKey();
            CompoundTag tag = entry.getValue();

            if (tag.isEmpty()) continue;

            UUID id = UUID.nameUUIDFromBytes(idStr.getBytes(StandardCharsets.UTF_8));

            VillageRecord v = new VillageRecord(
                id,
                level.dimension().location().toString(),
                tag.getInt("center_x"),
                tag.getInt("center_y"),
                tag.getInt("center_z")
            );
            v.setName(tag.getString("village_name"));
            v.setRadius(tag.contains("radius") ? tag.getInt("radius") : 32);
            v.setPopulation(tag.getInt("population"));
            v.setAbandoned(tag.getBoolean("abandoned"));
            v.setFoundedDay(tag.getLong("founded_tick") / 24000L);

            villages.put(id, v);
            idIndex.put(idStr, id);
        }

        LiveMineMod.LOGGER.info("VillageManager: loaded {} villages", villages.size());
    }

    /** Сохраняет все деревни в SavedData (по каноническому rawId). */
    public void saveAll(ServerLevel level) {
        for (VillageRecord v : villages.values()) {
            VillageData vd = new VillageData(v.rawId(), level);
            if (!vd.exists()) continue;
            vd.setRadius(v.radius());
            vd.setPopulation(v.population());
            vd.setAbandoned(v.isAbandoned());
        }
    }

    public void clear() {
        villages.clear();
        idIndex.clear();
    }
}