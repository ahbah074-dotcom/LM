package com.livemine;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Менеджер болезней NPC.
 *
 * 5 встроенных болезней (ТЗ 20.0 §12.1):
 *   - Отравление      (сырое мясо)
 *   - Лихорадка       (укус паука)
 *   - Простуда        (холод)
 *   - Пневмония       (осложнение простуды)
 *   - Гангрена        (раневая инфекция)
 *
 * Иммунитет 30 дней. Повторное заражение — 10%.
 * Медик (Медицина ≥ 3) может вылечить.
 */
public final class DiseaseManager {

    public static final long IMMUNITY_DAYS = 30;
    public static final float REINFECTION_CHANCE = 0.10f;

    private static DiseaseManager INSTANCE;

    public enum Disease {
        NONE,
        POISONING,      // Отравление
        FEVER,          // Лихорадка
        COLD,           // Простуда
        PNEUMONIA,      // Пневмония
        GANGRENE;       // Гангрена

        public String ruName() {
            return switch (this) {
                case NONE -> "Р—РґРѕСЂРѕРІ";
                case POISONING -> "Отравление";
                case FEVER -> "Лихорадка";
                case COLD -> "Простуда";
                case PNEUMONIA -> "Пневмония";
                case GANGRENE -> "Гангрена";
            };
        }
    }

    private final Map<UUID, Disease> activeDiseases = new HashMap<>();
    private final Map<UUID, Integer> diseaseTicks = new HashMap<>();
    private final Map<UUID, Long> immunityUntilDay = new HashMap<>();

    private DiseaseManager() {}

    public static synchronized DiseaseManager getInstance() {
        if (INSTANCE == null) INSTANCE = new DiseaseManager();
        return INSTANCE;
    }

    // =========================================================================
    // РўРёРє
    // =========================================================================

    public void tick(com.livemine.entity.LiveNPCEntity npc) {
        if (npc == null) return;
        if (!(npc.level() instanceof ServerLevel level)) return;

        long currentDay = level.getDayTime() / 24000L;
        UUID id = npc.getUUID();

        Disease disease = activeDiseases.get(id);
        if (disease == null || disease == Disease.NONE) {
            // Проверяем возможность заражения (раз в день)
            if (level.getGameTime() % 24000L == 0) {
                tryRandomInfection(npc, level, currentDay);
            }
            return;
        }

        // Прогресс болезни
        int ticks = diseaseTicks.getOrDefault(id, 0) + 1;
        diseaseTicks.put(id, ticks);

        // Урон раз в игровой день
        if (ticks % 24000 == 0) {
            applyDailyDamage(npc, disease);
        }

        // Выздоровление
        int duration = getDurationTicks(disease);
        if (duration > 0 && ticks >= duration) {
            cure(npc, currentDay);
        }
    }

    private int getDurationTicks(Disease disease) {
        return switch (disease) {
            case NONE -> 0;
            case POISONING -> 24000 * 2;    // 2 РґРЅСЏ
            case FEVER -> 24000 * 5;        // 5 дней
            case COLD -> 24000 * 5;         // 5 дней
            case PNEUMONIA -> 24000 * 3;    // 3 РґРЅСЏ
            case GANGRENE -> 24000 * 3;     // 3 РґРЅСЏ
        };
    }

    private void applyDailyDamage(com.livemine.entity.LiveNPCEntity npc, Disease disease) {
        float damage = switch (disease) {
            case POISONING -> 1.0f;
            case FEVER -> 2.0f;
            case COLD -> 0.5f;
            case PNEUMONIA -> 3.0f;
            case GANGRENE -> 4.0f;
            case NONE -> 0f;
        };
        npc.hurt(npc.damageSources().magic(), damage);
    }

    // =========================================================================
    // Заражение
    // =========================================================================

    private void tryRandomInfection(com.livemine.entity.LiveNPCEntity npc, ServerLevel level, long currentDay) {
        UUID id = npc.getUUID();

        // Иммунитет
        Long immuneUntil = immunityUntilDay.get(id);
        if (immuneUntil != null && currentDay < immuneUntil) return;

        // Шансы
        float health = npc.getHealth();
        float maxHealth = npc.getMaxHealth();
        CompoundTag tag = LiveMineSavedData.get(level).loadNPCData(id);
        double hunger = tag.getDouble("hunger");

        // Отравление от голода
        if (hunger < 20 && level.random.nextFloat() < 0.05f) {
            infect(npc, Disease.POISONING);
            return;
        }

        // Простуда от низкого здоровья
        if (health < maxHealth * 0.5f && level.random.nextFloat() < 0.03f) {
            infect(npc, Disease.COLD);
            return;
        }

        // Осложнение простуды в пневмонию
        Disease current = activeDiseases.get(id);
        if (current == Disease.COLD && level.random.nextFloat() < 0.10f) {
            infect(npc, Disease.PNEUMONIA);
        }
    }

    public void infect(com.livemine.entity.LiveNPCEntity npc, Disease disease) {
        if (npc == null || disease == Disease.NONE) return;

        activeDiseases.put(npc.getUUID(), disease);
        diseaseTicks.put(npc.getUUID(), 0);
        npc.setCurrentDisease(disease.name().toLowerCase());
        LiveMineMod.LOGGER.info("NPC {} infected with {}", npc.getCustomNameTag(), disease.ruName());
    }

    public void cure(com.livemine.entity.LiveNPCEntity npc, long currentDay) {
        if (npc == null) return;

        activeDiseases.remove(npc.getUUID());
        diseaseTicks.remove(npc.getUUID());
        immunityUntilDay.put(npc.getUUID(), currentDay + IMMUNITY_DAYS);
        npc.setCurrentDisease("none");
        LiveMineMod.LOGGER.info("NPC {} cured", npc.getCustomNameTag());
    }

    public void cure(UUID npcUUID) {
        activeDiseases.remove(npcUUID);
        diseaseTicks.remove(npcUUID);
    }

    public Disease getDisease(UUID npcUUID) {
        return activeDiseases.getOrDefault(npcUUID, Disease.NONE);
    }

    public boolean isSick(UUID npcUUID) {
        Disease d = activeDiseases.get(npcUUID);
        return d != null && d != Disease.NONE;
    }

    public boolean canSocialize(UUID npcUUID) {
        // Больные заразными болезнями в карантине
        Disease d = activeDiseases.get(npcUUID);
        return d == null || d == Disease.NONE || d == Disease.GANGRENE;
    }

    // =========================================================================
    // NBT
    // =========================================================================

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        ListTag list = new ListTag();

        for (var e : activeDiseases.entrySet()) {
            CompoundTag et = new CompoundTag();
            et.putUUID("uuid", e.getKey());
            et.putString("disease", e.getValue().name());
            et.putInt("ticks", diseaseTicks.getOrDefault(e.getKey(), 0));
            list.add(et);
        }
        tag.put("diseases", list);

        CompoundTag imm = new CompoundTag();
        immunityUntilDay.forEach((uuid, day) -> imm.putLong(uuid.toString(), day));
        tag.put("immunity", imm);

        return tag;
    }

    public void load(CompoundTag tag) {
        activeDiseases.clear();
        diseaseTicks.clear();
        immunityUntilDay.clear();

        ListTag list = tag.getList("diseases", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag et = list.getCompound(i);
            try {
                UUID id = et.getUUID("uuid");
                Disease d = Disease.valueOf(et.getString("disease"));
                activeDiseases.put(id, d);
                diseaseTicks.put(id, et.getInt("ticks"));
            } catch (IllegalArgumentException ignored) {}
        }

        CompoundTag imm = tag.getCompound("immunity");
        for (String k : imm.getAllKeys()) {
            try { immunityUntilDay.put(UUID.fromString(k), imm.getLong(k)); }
            catch (IllegalArgumentException ignored) {}
        }
    }

    public void clear() {
        activeDiseases.clear();
        diseaseTicks.clear();
        immunityUntilDay.clear();
    }
}
