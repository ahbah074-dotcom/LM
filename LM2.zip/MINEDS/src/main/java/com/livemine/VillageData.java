package com.livemine;

import com.livemine.blocks.CommunalFirePitBlock;
import com.livemine.blocks.FarmPlotBlock;
import com.livemine.blocks.InfirmaryBlock;
import com.livemine.blocks.StorageBlock;
import com.livemine.blocks.StorageWarehouseBlock;
import com.livemine.blocks.VillageCenterBlock;
import com.livemine.blocks.WorkshopForgeBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Данные деревни.
 *
 * v3.0: встроены Chronicle (хроника) и CollectiveMemory (коллективная память).
 * Пишутся/читаются внутри того же CompoundTag, что и population/resources.
 */
public class VillageData {

    private static final long CACHE_TTL_TICKS = 200;

    private final String villageId;
    private final ServerLevel level;

    private CompoundTag data;
    private boolean exists = false;

    private BlockPos center;
    private int radius = 32;
    private double resources = 0;
    private int population = 0;
    private boolean abandoned = false;
    private long foundedTick = 0;

    private final Map<Class<?>, List<BlockPos>> structureCache = new HashMap<>();
    private long lastCacheUpdate = -1;

    // Ленивые обёртки.
    private Chronicle chronicle;
    private CollectiveMemory memory;

    public VillageData(String villageId, ServerLevel level) {
        this.villageId = villageId;
        this.level = level;
        this.data = LiveMineSavedData.get(level).loadVillageData(villageId);

        if (data != null && !data.isEmpty()) {
            this.exists = true;
            this.abandoned = data.getBoolean("abandoned");
            this.resources = data.getDouble("resources");
            this.population = data.getInt("population");
            this.radius = data.contains("radius") ? data.getInt("radius") : 32;
            this.foundedTick = data.getLong("founded_tick");
            if (data.contains("center_x")) {
                this.center = new BlockPos(
                    data.getInt("center_x"),
                    data.getInt("center_y"),
                    data.getInt("center_z")
                );
            }
        }
    }

    public boolean exists() { return exists; }
    public boolean isAbandoned() { return abandoned; }
    public BlockPos getCenter() { return center; }
    public double getResources() { return resources; }
    public int getPopulation() { return population; }
    public int getRadius() { return radius; }
    public String getId() { return villageId; }
    public long getFoundedTick() { return foundedTick; }

    // =========================================================================
    // Простые сеттеры
    // =========================================================================

    public void setResources(double v) {
        this.resources = v;
        data.putDouble("resources", v);
        save();
    }

    public void setAbandoned(boolean v) {
        this.abandoned = v;
        data.putBoolean("abandoned", v);
        save();
    }

    public void setPopulation(int p) {
        this.population = p;
        data.putInt("population", p);
        save();
    }

    public void setRadius(int r) {
        this.radius = r;
        data.putInt("radius", r);
        save();
    }

    public int refreshPopulation() {
        int count = getResidentNpcIds().size();
        if (count != this.population) {
            setPopulation(count);
        }
        return count;
    }

    // =========================================================================
    // Потребности
    // =========================================================================

    public double getNeedFood()     { return data.getDouble("need_food"); }
    public double getNeedWood()     { return data.getDouble("need_wood"); }
    public double getNeedOre()      { return data.getDouble("need_ore"); }
    public double getNeedHealing()  { return data.getDouble("need_healing"); }

    public void setNeed(String type, double value) {
        data.putDouble("need_" + type, Math.max(0, Math.min(100, value)));
        save();
    }

    public void addNeed(String type, double delta) {
        double current = data.getDouble("need_" + type);
        setNeed(type, current + delta);
    }

    // =========================================================================
    // Постройки
    // =========================================================================

    @SuppressWarnings("unchecked")
    public List<BlockPos> getStructures(Class<?> blockClass) {
        if (level.getGameTime() - lastCacheUpdate > CACHE_TTL_TICKS || lastCacheUpdate < 0) {
            refreshStructureCache();
        }
        return structureCache.getOrDefault(blockClass, Collections.emptyList());
    }

    private void refreshStructureCache() {
        structureCache.clear();
        if (data == null || data.isEmpty()) return;

        ListTag list = data.getList("structures", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            String className = entry.getString("type");
            BlockPos pos = new BlockPos(
                entry.getInt("x"),
                entry.getInt("y"),
                entry.getInt("z")
            );
            try {
                Class<?> clazz = Class.forName(className);
                structureCache.computeIfAbsent(clazz, k -> new ArrayList<>()).add(pos);
            } catch (ClassNotFoundException ignored) {}
        }
        lastCacheUpdate = level.getGameTime();
    }

    public void registerStructure(BlockPos pos, Class<?> blockClass) {
        ListTag list = data.getList("structures", Tag.TAG_COMPOUND);

        CompoundTag entry = new CompoundTag();
        entry.putString("type", blockClass.getName());
        entry.putInt("x", pos.getX());
        entry.putInt("y", pos.getY());
        entry.putInt("z", pos.getZ());
        list.add(entry);

        data.put("structures", list);
        save();
        lastCacheUpdate = -1;
    }

    public boolean hasRequiredStructures() {
        return !getStructures(VillageCenterBlock.class).isEmpty()
            && !getStructures(CommunalFirePitBlock.class).isEmpty()
            && !getStructures(StorageBlock.class).isEmpty();
    }

    public boolean hasAdvancedStructures() {
        return !getStructures(WorkshopForgeBlock.class).isEmpty()
            && !getStructures(FarmPlotBlock.class).isEmpty()
            && !getStructures(InfirmaryBlock.class).isEmpty();
    }

    // =========================================================================
    // v3.0: Хроника
    // =========================================================================

    public Chronicle getChronicle() {
        if (chronicle == null) {
            chronicle = new Chronicle(villageId);
            if (data != null && data.contains("chronicle")) {
                chronicle.load(data.getCompound("chronicle"));
            }
        }
        return chronicle;
    }

    public void saveChronicle() {
        if (chronicle != null) {
            data.put("chronicle", chronicle.save());
            save();
        }
    }

    /**
     * Удобный метод: добавить запись в хронику и сохранить.
     */
    public void addChronicleEntry(Chronicle.EntryType type, long day, String description) {
        getChronicle().addEntry(type, day, description);
        saveChronicle();
    }

    public void addChronicleEntry(Chronicle.EntryType type, long day, String description, String actor) {
        getChronicle().addEntry(type, day, description, actor);
        saveChronicle();
    }

    // =========================================================================
    // v3.0: Коллективная память
    // =========================================================================

    public CollectiveMemory getMemory() {
        if (memory == null) {
            memory = new CollectiveMemory(villageId);
            if (data != null && data.contains("memory")) {
                memory.load(data.getCompound("memory"));
            }
        }
        return memory;
    }

    public void saveMemory() {
        if (memory != null) {
            data.put("memory", memory.save());
            save();
        }
    }

    /**
     * Запомнить факт (упрощённый вариант).
     */
    public void remember(String key, String value, CollectiveMemory.Category category, long day) {
        getMemory().remember(key, value, category, day, "");
        saveMemory();
    }

    // =========================================================================
    // Общие методы
    // =========================================================================

    private void save() {
        LiveMineSavedData.get(level).saveVillageData(villageId, data);
    }

    public static String createVillage(BlockPos center, ServerLevel level, String name) {
        String id = "village_" + center.asLong();
        LiveMineSavedData savedData = LiveMineSavedData.get(level);

        CompoundTag tag = new CompoundTag();
        tag.putInt("center_x", center.getX());
        tag.putInt("center_y", center.getY());
        tag.putInt("center_z", center.getZ());
        tag.putInt("radius", 32);
        tag.putDouble("resources", 50.0);
        tag.putDouble("need_food", 50.0);
        tag.putDouble("need_wood", 50.0);
        tag.putDouble("need_ore", 50.0);
        tag.putDouble("need_healing", 0.0);
        tag.putInt("population", 0);
        tag.putBoolean("abandoned", false);
        tag.putLong("founded_tick", level.getGameTime());
        tag.putString("village_name", name);

        savedData.saveVillageData(id, tag);

        // Первая запись в хронику.
        try {
            VillageData vd = new VillageData(id, level);
            vd.addChronicleEntry(Chronicle.EntryType.FOUNDING,
                level.getDayTime() / 24000L,
                "Основана деревня " + name);
        } catch (Exception ignored) {}

        return id;
    }

    public List<UUID> getResidentNpcIds() {
        List<UUID> result = new ArrayList<>();
        for (Map.Entry<UUID, CompoundTag> entry :
                LiveMineSavedData.get(level).getAllNpcData().entrySet()) {
            CompoundTag npcTag = entry.getValue();
            if (npcTag.getBoolean("dead")) continue;
            if (villageId.equals(npcTag.getString("village_id"))) {
                result.add(entry.getKey());
            }
        }
        return result;
    }

    @Override
    public String toString() {
        return "VillageData{" + villageId + ", pop=" + population + ", r=" + radius + "}";
    }
}