package com.livemine;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Менеджер праздников (ТЗ 20.0 §15).
 *
 * 12 календарных + 1 конкурс мастерства.
 * NBT-ключи: "startDay", "duration", "active", "repeats" — канонические.
 */
public final class HolidayManager {

    private static HolidayManager INSTANCE;

    public enum HolidayType {
        FOUNDING_DAY        (0,   "День основания",     "Пир на главной площади"),
        HARVEST_FESTIVAL    (30,  "Праздник урожая",    "Ярмарка и застолье"),
        SPRING_CELEBRATION  (60,  "Весеннее торжество", "Посадка деревьев"),
        WINTER_SOLSTICE     (90,  "Зимнее солнцестояние","Костры и песни"),
        REMEMBRANCE_DAY     (120, "День памяти",        "У могил предков"),
        CRAFTSMAN_FAIR      (150, "Ярмарка ремесленников","Конкурс изделий"),
        HUNTERS_FEAST       (180, "Пир охотников",      "Демонстрация трофеев"),
        BUILDERS_PRIDE      (210, "Гордость строителей","Осмотр новых зданий"),
        MINERS_DAY          (240, "День рудокопа",      "Выставка руды"),
        FISHERMANS_JOY      (270, "Радость рыбака",     "Соревнование по рыбалке"),
        HEALERS_VIGIL       (300, "Бдение целителей",   "Лечение больных"),
        MASTERS_CONTEST     (-1,  "Конкурс мастерства", "Состязание мастеров");

        public final int dayOfYear;
        public final String ruName;
        public final String tradition;

        HolidayType(int day, String ru, String tradition) {
            this.dayOfYear = day;
            this.ruName = ru;
            this.tradition = tradition;
        }
    }

    public static final class Holiday {
        public HolidayType type;
        public long startDay;
        public int durationDays;
        public boolean active;
        public int repeatCount;

        public Holiday(HolidayType type, long startDay, int duration) {
            this.type = type;
            this.startDay = startDay;
            this.durationDays = duration;
            this.active = true;
            this.repeatCount = 1;
        }

        public CompoundTag save() {
            CompoundTag tag = new CompoundTag();
            tag.putString("type", type.name());
            tag.putLong("startDay", startDay);
            tag.putInt("duration", durationDays);
            tag.putBoolean("active", active);
            tag.putInt("repeats", repeatCount);
            return tag;
        }

        public static Holiday load(CompoundTag tag) {
            Holiday h = new Holiday(
                HolidayType.valueOf(tag.getString("type")),
                tag.getLong("startDay"),
                tag.getInt("duration")
            );
            h.active = tag.getBoolean("active");
            h.repeatCount = tag.getInt("repeats");
            return h;
        }
    }

    private final List<Holiday> history = new ArrayList<>();
    private Holiday activeHoliday;
    private long lastContestDay = -999;

    private static final long CONTEST_INTERVAL = 100;

    private HolidayManager() {}

    public static synchronized HolidayManager getInstance() {
        if (INSTANCE == null) INSTANCE = new HolidayManager();
        return INSTANCE;
    }

    // =========================================================================
    // РўРёРє
    // =========================================================================

    public void tick(ServerLevel level) {
        if (!LiveMineConfig.enableHolidays()) return;

        long day = level.getDayTime() / 24000L;
        long yearDay = day % 365;

        if (activeHoliday != null) {
            if (day - activeHoliday.startDay >= activeHoliday.durationDays) {
                activeHoliday.active = false;
                history.add(activeHoliday);
                activeHoliday = null;
            }
            return;
        }

        for (HolidayType type : HolidayType.values()) {
            if (type.dayOfYear < 0) continue;
            if (type.dayOfYear == yearDay) {
                startHoliday(type, day, 3);
                return;
            }
        }

        if (day - lastContestDay >= CONTEST_INTERVAL) {
            startHoliday(HolidayType.MASTERS_CONTEST, day, 2);
            lastContestDay = day;
        }
    }

    public void startHoliday(HolidayType type, long day, int duration) {
        activeHoliday = new Holiday(type, day, duration);
        int repeats = 0;
        for (Holiday h : history) if (h.type == type) repeats++;
        activeHoliday.repeatCount = repeats + 1;
        LiveMineMod.LOGGER.info("Holiday started: {} (day {}, repeats {})",
            type.ruName, day, activeHoliday.repeatCount);
    }

    public void stopHoliday() {
        if (activeHoliday != null) {
            activeHoliday.active = false;
            history.add(activeHoliday);
            activeHoliday = null;
        }
    }

    // =========================================================================
    // Чтение
    // =========================================================================

    public Holiday getActiveHoliday() { return activeHoliday; }
    public boolean isHolidayActive() { return activeHoliday != null; }

    public boolean isTradition(HolidayType type) {
        int repeats = 0;
        for (Holiday h : history) if (h.type == type) repeats++;
        return repeats >= 3;
    }

    public List<Holiday> getHistory() {
        return Collections.unmodifiableList(history);
    }

    public float getMoodMultiplier() {
        return activeHoliday != null ? 1.5f : 1.0f;
    }

    // =========================================================================
    // NBT
    // =========================================================================

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        ListTag list = new ListTag();
        for (Holiday h : history) list.add(h.save());
        tag.put("history", list);
        tag.putLong("lastContest", lastContestDay);
        if (activeHoliday != null) tag.put("active", activeHoliday.save());
        return tag;
    }

    public void load(CompoundTag tag) {
        history.clear();
        ListTag list = tag.getList("history", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            history.add(Holiday.load(list.getCompound(i)));
        }
        lastContestDay = tag.getLong("lastContest");
        if (tag.contains("active")) activeHoliday = Holiday.load(tag.getCompound("active"));
        else activeHoliday = null;
    }

    public void clear() {
        history.clear();
        activeHoliday = null;
        lastContestDay = -999;
    }
}
