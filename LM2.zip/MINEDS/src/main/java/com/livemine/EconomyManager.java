package com.livemine;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Менеджер экономики деревни.
 *
 * Хранит 10 базовых товаров с динамическими ценами.
 * Цена = basePrice × коэффициент спроса/предложения.
 *
 * Тик: раз в игровой день — supply и demand уменьшаются.
 * NPC-торговцы пополняют supply через свои действия.
 */
public final class EconomyManager {

    public static final int MAX_COMMODITIES = 64;

    private static EconomyManager INSTANCE;

    public static final class Commodity {
        public final String id;
        public final float basePrice;
        public float currentPrice;
        public int supply;
        public int demand;

        public Commodity(String id, float basePrice) {
            this.id = id;
            this.basePrice = basePrice;
            this.currentPrice = basePrice;
            this.supply = 0;
            this.demand = 0;
        }

        public void updatePrice() {
            if (supply == 0 && demand == 0) {
                currentPrice = basePrice;
                return;
            }
            float ratio = demand > 0 ? (float) supply / demand : 10.0f;
            if (ratio < 0.5f) currentPrice = basePrice * 1.5f;
            else if (ratio < 1.0f) currentPrice = basePrice * 1.2f;
            else if (ratio > 3.0f) currentPrice = basePrice * 0.6f;
            else if (ratio > 1.5f) currentPrice = basePrice * 0.8f;
            else currentPrice = basePrice;
        }

        public CompoundTag save() {
            CompoundTag tag = new CompoundTag();
            tag.putString("id", id);
            tag.putFloat("base", basePrice);
            tag.putFloat("price", currentPrice);
            tag.putInt("supply", supply);
            tag.putInt("demand", demand);
            return tag;
        }

        public static Commodity load(CompoundTag tag) {
            Commodity c = new Commodity(tag.getString("id"), tag.getFloat("base"));
            c.currentPrice = tag.getFloat("price");
            c.supply = tag.getInt("supply");
            c.demand = tag.getInt("demand");
            return c;
        }
    }

    private final Map<String, Commodity> commodities = new LinkedHashMap<>();

    private EconomyManager() {
        // Базовый список 10 товаров (расширяется до 64)
        commodities.put("wheat", new Commodity("wheat", 1.0f));
        commodities.put("iron_ingot", new Commodity("iron_ingot", 4.0f));
        commodities.put("coal", new Commodity("coal", 2.0f));
        commodities.put("wood", new Commodity("wood", 1.5f));
        commodities.put("stone", new Commodity("stone", 1.0f));
        commodities.put("leather", new Commodity("leather", 3.0f));
        commodities.put("diamond", new Commodity("diamond", 50.0f));
        commodities.put("gold_ingot", new Commodity("gold_ingot", 20.0f));
        commodities.put("bread", new Commodity("bread", 2.0f));
        commodities.put("potion", new Commodity("potion", 15.0f));
    }

    public static synchronized EconomyManager getInstance() {
        if (INSTANCE == null) INSTANCE = new EconomyManager();
        return INSTANCE;
    }

    // =========================================================================
    // Дневное обновление
    // =========================================================================

    public void dailyUpdate() {
        for (Commodity c : commodities.values()) {
            c.updatePrice();
            c.supply = Math.max(0, c.supply - 1);
            c.demand = Math.max(0, c.demand - 1);
        }
    }

    // =========================================================================
    // Геттеры / изменение
    // =========================================================================

    public float getPrice(String commodityId) {
        Commodity c = commodities.get(commodityId);
        return c != null ? c.currentPrice : 1.0f;
    }

    public Commodity getCommodity(String id) {
        return commodities.get(id);
    }

    public void addSupply(String commodityId, int amount) {
        Commodity c = commodities.get(commodityId);
        if (c != null) {
            c.supply += amount;
            c.updatePrice();
        }
    }

    public void addDemand(String commodityId, int amount) {
        Commodity c = commodities.get(commodityId);
        if (c != null) {
            c.demand += amount;
            c.updatePrice();
        }
    }

    public Collection<Commodity> getAllCommodities() {
        return commodities.values();
    }

    public int size() { return commodities.size(); }

    // =========================================================================
    // NBT
    // =========================================================================

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        ListTag list = new ListTag();
        for (Commodity c : commodities.values()) list.add(c.save());
        tag.put("commodities", list);
        return tag;
    }

    public void load(CompoundTag tag) {
        ListTag list = tag.getList("commodities", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            Commodity c = Commodity.load(list.getCompound(i));
            if (commodities.containsKey(c.id)) {
                commodities.put(c.id, c);
            }
        }
    }

    public void clear() {
        for (Commodity c : commodities.values()) {
            c.supply = 0;
            c.demand = 0;
            c.currentPrice = c.basePrice;
        }
    }
}
